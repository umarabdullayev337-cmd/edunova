const express = require('express');
const db = require('../db');
const { optionalAuthenticate } = require('../middleware/auth');
const { wrap } = require('../utils/helpers');
const { RANKS, rankOf } = require('../rank');
const L = require('../lessons');

const router = express.Router();

router.get('/', optionalAuthenticate, wrap(async (req, res) => {
  const all = db.data.users
    .filter((u) => u.role === 'user' && u.verified && (u.xp || 0) > 0)
    .sort((a, b) => (b.xp || 0) - (a.xp || 0) || a.createdAt - b.createdAt);
  const view = (u, i) => ({
    place: i + 1, id: u.id, name: u.name, avatar: u.avatar || null, frame: u.frame || null,
    xp: u.xp || 0, rank: rankOf(u.xp || 0),
    lessons: L.lessonsDoneCount(u.id),
    courses: db.data.enrollments.filter((e) => e.userId === u.id && e.completed).length,
  });
  const top = all.slice(0, 50).map(view);
  let me = null;
  if (req.user) {
    const idx = all.findIndex((u) => u.id === req.user.id);
    me = { xp: req.user.xp || 0, rank: rankOf(req.user.xp || 0), place: idx >= 0 ? idx + 1 : null, total: all.length,
      lessons: L.lessonsDoneCount(req.user.id) };
  }
  res.json({ top, me, ranks: RANKS });
}));

module.exports = router;
