const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const config = require('../config');
const db = require('../db');

const COOKIE = 'refresh_token';

// Refresh token faqat /auth/* yo'llariga yuboriladi, JavaScript o'qiy olmaydi (httpOnly),
// boshqa saytlardan yuborilmaydi (sameSite=strict).
const cookieOptions = {
  httpOnly: true,
  secure: config.isProd,
  sameSite: 'strict',
  path: '/auth',
  maxAge: config.refreshTtlMs,
};

function signAccess(user) {
  return jwt.sign({ sub: user.id, role: user.role }, config.accessSecret, {
    expiresIn: config.accessTtl,
  });
}

// Yangi sessiya: access token (JSON orqali) + refresh token (httpOnly cookie).
function issueSession(res, user) {
  const jti = crypto.randomUUID();
  const refresh = jwt.sign({ sub: user.id, jti }, config.refreshSecret, {
    expiresIn: config.refreshTtl,
  });

  const now = Date.now();
  // Muddati o'tgan yozuvlarni tozalaymiz
  db.data.refreshTokens = db.data.refreshTokens.filter((t) => t.expiresAt > now);
  db.data.refreshTokens.push({
    jti,
    userId: user.id,
    createdAt: now,
    expiresAt: now + config.refreshTtlMs,
    revoked: false,
    revokedAt: null,
  });
  db.save();

  res.cookie(COOKIE, refresh, cookieOptions);
  return { accessToken: signAccess(user), expiresIn: config.accessTtlSeconds };
}

function clearRefreshCookie(res) {
  const { maxAge, ...opts } = cookieOptions;
  res.clearCookie(COOKIE, opts);
}

module.exports = { COOKIE, signAccess, issueSession, clearRefreshCookie };
