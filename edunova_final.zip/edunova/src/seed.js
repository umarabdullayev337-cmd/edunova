const bcrypt = require('bcryptjs');
const config = require('./config');
const db = require('./db');

const MENTORS = [
  { key: 'jasur', name: 'Jasur Karimov', email: 'jasur.karimov@edunova.uz', avatarKey: 'm-jasur',
    title: 'Backend arxitektor', specialty: 'Node.js va tarqoq tizimlar',
    bio: "10 yildan ortiq backend tajribasiga ega. Bir nechta yuqori yuklamali tizimlarni noldan qurgan va jamoalarni yetaklagan.",
    achievements: ["10+ yillik sanoat tajribasi", "3 ta startupda bosh backend muhandis", "500+ talaba o'qitgan", "Har yili konferensiyalarda ma'ruzachi"] },
  { key: 'dilnoza', name: 'Dilnoza Rahimova', email: 'dilnoza.rahimova@edunova.uz', avatarKey: 'm-dilnoza',
    title: 'Xavfsizlik muhandisi', specialty: 'Autentifikatsiya va veb-xavfsizlik',
    bio: "Kiberxavfsizlik sohasida sertifikatlangan mutaxassis. Bank va fintech loyihalarida xavfsizlik auditlarini olib borgan.",
    achievements: ["OSCP sertifikati", "Fintech kompaniyasida xavfsizlik boshlig'i", "50+ zaiflikni aniqlagan", "Bug bounty dasturlarida faol ishtirokchi"] },
  { key: 'sardor', name: 'Sardor Aliyev', email: 'sardor.aliyev@edunova.uz', avatarKey: 'm-sardor',
    title: 'Frontend muhandis', specialty: 'JavaScript va zamonaviy veb',
    bio: "Frontend olamida 7 yillik tajriba. Ko'plab startaplarga foydalanuvchi interfeysini noldan qurishda yordam bergan.",
    achievements: ["7 yillik frontend tajriba", "20+ tijorat loyihasi", "Ochiq kodli kutubxona muallifi", "Google Developer Expert nomzodi"] },
  { key: 'madina', name: 'Madina Yusupova', email: 'madina.yusupova@edunova.uz', avatarKey: 'm-madina',
    title: 'React mutaxassisi', specialty: 'React va zamonaviy UI arxitektura',
    bio: "Yirik e-commerce platformalarida React asosida frontend arxitekturasini yaratgan. Komponentlar dizayni bo'yicha ekspert.",
    achievements: ["Meta React sertifikati", "5 ta yirik loyihada texnik yetakchi", "UI kutubxonasi 10k+ marta yuklab olingan"] },
  { key: 'bekzod', name: 'Bekzod Tursunov', email: 'bekzod.tursunov@edunova.uz', avatarKey: 'm-bekzod',
    title: "Ma'lumotlar olimi", specialty: 'Python va ma\'lumotlar tahlili',
    bio: "Ma'lumotlar tahlili va mashinaviy o'rganish sohasida tadqiqotchi. Xalqaro loyihalarda ma'lumotlar bo'yicha maslahatchi.",
    achievements: ["PhD nomzodi, Data Science", "15+ ilmiy maqola muallifi", "Kaggle Expert darajasi", "3 ta xalqaro grant g'olibi"] },
  { key: 'nigora', name: 'Nigora Abdullayeva', email: 'nigora.abdullayeva@edunova.uz', avatarKey: 'm-nigora',
    title: 'Dizayn yetakchisi', specialty: 'UI/UX va mahsulot dizayni',
    bio: "8 yildan buyon raqamli mahsulotlar dizayni bilan shug'ullanadi. Uning dizaynlari millionlab foydalanuvchiga xizmat qilgan.",
    achievements: ["8 yillik dizayn tajribasi", "Behance'da tanlangan ish", "Xalqaro dizayn tanlovi g'olibi", "40+ mahsulot uchun dizayn tizimi yaratgan"] },
  { key: 'otabek', name: 'Otabek Nazarov', email: 'otabek.nazarov@edunova.uz', avatarKey: 'm-otabek',
    title: 'Mobil ilovalar muhandisi', specialty: 'Flutter va cross-platform',
    bio: "Flutter bo'yicha Google tan olgan mutaxassis. Play Market va App Store'da millionlab yuklab olishga ega ilovalar yaratgan.",
    achievements: ["Google Developer Expert (Flutter)", "10+ nashr etilgan ilova", "2M+ umumiy yuklab olishlar"] },
  { key: 'malika', name: 'Malika Ergasheva', email: 'malika.ergasheva@edunova.uz', avatarKey: 'm-malika',
    title: 'Ingliz tili instruktori', specialty: 'IELTS va akademik yozuv',
    bio: "IELTS bo'yicha sertifikatlangan trener, o'quvchilarining o'rtacha balli 7.5 dan yuqori. Xalqaro universitetlarga kirishga yordam bergan.",
    achievements: ["CELTA sertifikati", "IELTS 8.5", "300+ o'quvchi xalqaro universitetga kirgan", "9 yillik o'qituvchilik tajribasi"] },
  { key: 'sherzod', name: 'Sherzod Xolmatov', email: 'sherzod.xolmatov@edunova.uz', avatarKey: 'm-sherzod',
    title: 'Bosh xavfsizlik tadqiqotchisi', specialty: 'Penetratsion testlash',
    bio: "Penetratsion test va zaifliklarni tekshirish bo'yicha mutaxassis. Yirik kompaniyalarning infratuzilmasini himoya qilishga yordam bergan.",
    achievements: ["CEH va OSCP sertifikatlari", "100+ penetratsion test o'tkazgan", "OWASP hamjamiyati a'zosi"] },
  { key: 'aziza', name: 'Aziza Nematova', email: 'aziza.nematova@edunova.uz', avatarKey: 'm-aziza',
    title: 'DevOps muhandisi', specialty: 'CI/CD va bulutli infratuzilma',
    bio: "Bulutli infratuzilma va avtomatlashtirish bo'yicha ekspert. Kompaniyalarga deploy jarayonlarini soatlab emas, daqiqalab qilishga yordam bergan.",
    achievements: ["AWS Solutions Architect sertifikati", "Kubernetes CKA sertifikati", "30+ kompaniyaga CI/CD joriy qilgan"] },
];

const COURSES = [
  { m: 'jasur', title: 'Node.js va Express: professional backend', category: 'Backend', level: "O'rta", price: 890000, durationHours: 48, lessons: 64, premium: false,
    description: "REST API, middleware, xatolarni boshqarish, ma'lumotlar bazasi va deploy. Kurs oxirida to'liq ishlaydigan backend loyihangiz bo'ladi.",
    tags: ['nodejs', 'express', 'api', 'backend'],
    whatYouWillLearn: ['Express asosida REST API qurish', "Ma'lumotlar bazasi bilan ishlash", 'Middleware yozish va xatolarni boshqarish', 'Loyihani serverga joylashtirish'],
    requirements: ['JavaScript asoslarini bilish', 'Terminal bilan ishlay olish'],
    syllabus: [{ week: 1, title: 'Node.js asoslari', topics: ['Event loop', 'Modullar', 'NPM'] }, { week: 2, title: 'Express bilan API', topics: ['Routing', 'Middleware', 'Xatolarni boshqarish'] }, { week: 3, title: "Ma'lumotlar bazasi", topics: ['MongoDB', 'Mongoose', 'Validatsiya'] }, { week: 4, title: 'Deploy va yakuniy loyiha', topics: ['Environment sozlash', 'Render/VPS ga chiqarish'] }] },
  { m: 'dilnoza', title: 'JWT va xavfsiz autentifikatsiya', category: 'Xavfsizlik', level: 'Yuqori', price: 690000, durationHours: 24, lessons: 32, premium: true,
    description: "Access va refresh token arxitekturasi, httpOnly cookie, bcrypt, rol asosidagi ruxsatlar va rate limiting — amaliy loyiha bilan.",
    tags: ['jwt', 'xavfsizlik', 'auth', 'cookie'],
    whatYouWillLearn: ['Access/refresh token arxitekturasi', 'Parollarni xavfsiz saqlash', 'Rol asosidagi ruxsatlar', 'Rate limiting va DDoS himoya'],
    requirements: ['Backend asoslarini bilish (Express tavsiya etiladi)'],
    syllabus: [{ week: 1, title: 'Autentifikatsiya asoslari', topics: ['Sessiya vs token', 'bcrypt'] }, { week: 2, title: 'JWT chuqur', topics: ['Access/refresh', 'Rotation'] }, { week: 3, title: 'Himoya qatlamlari', topics: ['Helmet', 'CORS', 'Rate limiting'] }] },
  { m: 'sardor', title: 'Zamonaviy JavaScript asoslari', category: 'Frontend', level: "Boshlang'ich", price: 490000, durationHours: 36, lessons: 48, premium: false,
    description: "O'zgaruvchilardan asinxron dasturlashgacha. ES2024 imkoniyatlari, DOM bilan ishlash va birinchi mini-ilovangiz.",
    tags: ['javascript', 'frontend', 'dom'],
    whatYouWillLearn: ["JavaScript sintaksisi va tipi", 'DOM manipulyatsiyasi', 'Asinxron dasturlash (Promise, async/await)', 'Birinchi mini-ilovani yaratish'],
    requirements: ['HTML va CSS asoslari'],
    syllabus: [{ week: 1, title: 'Asoslar', topics: ["O'zgaruvchilar", 'Funksiyalar'] }, { week: 2, title: 'DOM', topics: ['Elementlar bilan ishlash', 'Hodisalar'] }, { week: 3, title: 'Asinxron JS', topics: ['Promise', 'async/await', 'Fetch API'] }] },
  { m: 'madina', title: 'React bilan real loyihalar', category: 'Frontend', level: "O'rta", price: 790000, durationHours: 52, lessons: 70, premium: true,
    description: "Komponentlar, hook'lar, holat boshqaruvi va API bilan ishlash. Portfolioga qo'yishga arziydigan uchta loyiha yaratasiz.",
    tags: ['react', 'frontend', 'hooks'],
    whatYouWillLearn: ['Komponent asosida arxitektura', "Hook'lar (useState, useEffect va h.k.)", 'Holatni global boshqarish', 'API bilan integratsiya'],
    requirements: ['JavaScript asoslarini yaxshi bilish'],
    syllabus: [{ week: 1, title: 'React asoslari', topics: ['JSX', 'Komponentlar'] }, { week: 2, title: "Hook'lar", topics: ['useState', 'useEffect'] }, { week: 3, title: 'Holat boshqaruvi', topics: ['Context', 'Custom hooklar'] }, { week: 4, title: 'Yakuniy loyihalar', topics: ['API integratsiya', 'Deploy'] }] },
  { m: 'bekzod', title: "Python: noldan ma'lumotlar tahliligacha", category: "Ma'lumotlar", level: "Boshlang'ich", price: 590000, durationHours: 40, lessons: 55, premium: false,
    description: "Python asoslari, pandas bilan jadvallar tahlili va matplotlib orqali vizualizatsiya. Real dataset ustida ishlaymiz.",
    tags: ['python', 'pandas', 'data'],
    whatYouWillLearn: ['Python sintaksisi', "Ma'lumotlarni pandas bilan tozalash", 'Vizualizatsiya (matplotlib)', 'Real loyiha: hisobot tayyorlash'],
    requirements: ["Dasturlashda tajriba shart emas"],
    syllabus: [{ week: 1, title: 'Python asoslari', topics: ['Sintaksis', 'Kutubxonalar'] }, { week: 2, title: 'Pandas', topics: ['DataFrame', 'Tozalash'] }, { week: 3, title: 'Vizualizatsiya', topics: ['Matplotlib', 'Hisobot'] }] },
  { m: 'bekzod', title: "Machine Learning asoslari", category: "Ma'lumotlar", level: 'Yuqori', price: 1290000, durationHours: 60, lessons: 72, premium: true,
    description: "Nazorat ostidagi o'qitish, regressiya, klassifikatsiya va scikit-learn bilan amaliy loyihalar. Matematik asoslar sodda tilda tushuntiriladi.",
    tags: ['machine learning', 'python', "ma'lumotlar"],
    whatYouWillLearn: ['Regressiya va klassifikatsiya', 'Model baholash usullari', 'scikit-learn bilan ishlash', 'Real dataset asosida loyiha'],
    requirements: ['Python va statistikadan asosiy bilim'],
    syllabus: [{ week: 1, title: 'Kirish', topics: ['ML turlari', 'Matematik asos'] }, { week: 2, title: 'Regressiya', topics: ['Linear regression'] }, { week: 3, title: 'Klassifikatsiya', topics: ['Logistic regression', 'Decision tree'] }, { week: 4, title: 'Yakuniy loyiha', topics: ['Model deploy qilish'] }] },
  { m: 'nigora', title: 'UI/UX dizayn: Figma bilan', category: 'Dizayn', level: "Boshlang'ich", price: 540000, durationHours: 30, lessons: 40, premium: false,
    description: "Foydalanuvchi tadqiqoti, wireframe, dizayn tizimi va prototip. Kurs oxirida mobil ilova dizaynini himoya qilasiz.",
    tags: ['figma', 'ui', 'ux', 'dizayn'],
    whatYouWillLearn: ['Foydalanuvchi tadqiqoti', 'Wireframe va prototip yaratish', 'Dizayn tizimi qurish', "Figma'da professional ishlash"],
    requirements: ['Talab qilinmaydi'],
    syllabus: [{ week: 1, title: 'UX asoslari', topics: ['Tadqiqot', 'Persona'] }, { week: 2, title: 'Figma', topics: ['Komponentlar', 'Auto layout'] }, { week: 3, title: 'Prototip', topics: ['Interaktivlik', 'Himoya'] }] },
  { m: 'nigora', title: 'Mahsulot dizayni: 0 dan 1 gacha', category: 'Dizayn', level: 'Yuqori', price: 990000, durationHours: 38, lessons: 46, premium: true,
    description: "G'oyadan tayyor mahsulotgacha: dizayn tizimi, foydalanuvchi testlari va jamoaviy ishlash jarayoni. Amaliyot sanoat standartlarida.",
    tags: ['product design', 'dizayn tizimi', 'ux'],
    whatYouWillLearn: ["G'oyani mahsulotga aylantirish", 'Dizayn tizimi arxitekturasi', 'Foydalanuvchi testlarini o\'tkazish', 'Dizaynerlar jamoasida ishlash'],
    requirements: ['UI/UX asoslarini bilish tavsiya etiladi'],
    syllabus: [{ week: 1, title: 'Strategiya', topics: ['Muammoni aniqlash'] }, { week: 2, title: 'Dizayn tizimi', topics: ['Komponentlar kutubxonasi'] }, { week: 3, title: 'Test va yakun', topics: ['Foydalanuvchi testi', 'Taqdimot'] }] },
  { m: 'otabek', title: 'Flutter: mobil ilovalar yaratish', category: 'Mobil', level: "O'rta", price: 840000, durationHours: 45, lessons: 58, premium: false,
    description: "Bitta kod bilan Android va iOS ilova. Vidjetlar, navigatsiya, API va Firebase bilan ishlash.",
    tags: ['flutter', 'mobil', 'dart'],
    whatYouWillLearn: ['Flutter vidjetlari', 'Navigatsiya va holat boshqaruvi', 'API va Firebase integratsiyasi', 'Ilovani do\'konlarga chiqarish'],
    requirements: ['Har qanday dasturlash tilini bilish foydali'],
    syllabus: [{ week: 1, title: 'Dart va Flutter', topics: ['Sintaksis', 'Vidjetlar'] }, { week: 2, title: 'Navigatsiya', topics: ['Routing', 'Holat boshqaruvi'] }, { week: 3, title: 'Backend bilan aloqa', topics: ['API', 'Firebase'] }, { week: 4, title: 'Nashr etish', topics: ['Play Market', 'App Store'] }] },
  { m: 'malika', title: 'IELTS 7+ intensiv kursi', category: 'Tillar', level: "O'rta", price: 650000, durationHours: 60, lessons: 45, premium: false,
    description: "Listening, Reading, Writing va Speaking bo'yicha strategiyalar, haftalik mock testlar va shaxsiy fikr-mulohaza.",
    tags: ['ielts', 'ingliz tili', 'universitet'],
    whatYouWillLearn: ['4 ta bo\'lim bo\'yicha strategiyalar', 'Akademik yozuv (Writing Task 1 va 2)', 'Speaking uchun ishonch va ravonlik', 'Mock testlar orqali progress'],
    requirements: ['Ingliz tili B1 darajasi'],
    syllabus: [{ week: 1, title: 'Listening & Reading', topics: ['Strategiyalar', 'Vaqtni boshqarish'] }, { week: 2, title: 'Writing', topics: ['Task 1', 'Task 2'] }, { week: 3, title: 'Speaking', topics: ['Fluency', 'Mock intervyu'] }] },
  { m: 'sherzod', title: 'Veb xavfsizlik: OWASP Top 10', category: 'Xavfsizlik', level: 'Yuqori', price: 760000, durationHours: 28, lessons: 36, premium: true,
    description: "XSS, CSRF, SQL injection va boshqa zaifliklarni amalda topish hamda ularga qarshi himoya usullari.",
    tags: ['owasp', 'xavfsizlik', 'pentest'],
    whatYouWillLearn: ['OWASP Top 10 zaifliklari', 'Zaifliklarni topish usullari', 'Himoya choralarini joriy qilish', "Xavfsizlik auditi o'tkazish"],
    requirements: ['Veb dasturlash asoslarini bilish'],
    syllabus: [{ week: 1, title: 'Kirish', topics: ['OWASP Top 10 sharh'] }, { week: 2, title: 'Amaliy hujumlar', topics: ['XSS', 'SQL injection'] }, { week: 3, title: 'Himoya', topics: ['Sanitizatsiya', 'CSP'] }] },
  { m: 'aziza', title: 'DevOps asoslari: Docker va CI/CD', category: 'Backend', level: 'Yuqori', price: 950000, durationHours: 34, lessons: 42, premium: true,
    description: "Konteynerlash, avtomatik test va deploy jarayonlarini sozlash. GitHub Actions bilan CI/CD quvurini quramiz.",
    tags: ['docker', 'devops', 'ci/cd'],
    whatYouWillLearn: ['Docker bilan konteynerlash', 'CI/CD quvurini qurish', 'Avtomatik test integratsiyasi', 'Production\'ga xavfsiz deploy'],
    requirements: ['Backend asoslarini bilish'],
    syllabus: [{ week: 1, title: 'Docker', topics: ['Image', 'Container'] }, { week: 2, title: 'CI/CD', topics: ['GitHub Actions'] }, { week: 3, title: 'Deploy', topics: ['Production strategiyalar'] }] },
  { m: 'sardor', title: 'TypeScript amaliyotda', category: 'Frontend', level: "O'rta", price: 620000, durationHours: 26, lessons: 34, premium: false,
    description: "Turlar tizimi, interfeyslar, generiklar va katta loyihalarni TypeScript bilan boshqarish.",
    tags: ['typescript', 'frontend'],
    whatYouWillLearn: ['TypeScript turlari va interfeyslar', 'Generiklar', 'Katta loyihani tuzish', 'React bilan TypeScript'],
    requirements: ['JavaScript bilimi'],
    syllabus: [{ week: 1, title: 'Turlar tizimi', topics: ['Asosiy turlar', 'Interfeyslar'] }, { week: 2, title: 'Ilg\'or mavzular', topics: ['Generiklar', 'Utility types'] }] },
  { m: 'madina', title: 'Vue.js bilan zamonaviy interfeyslar', category: 'Frontend', level: "Boshlang'ich", price: 460000, durationHours: 30, lessons: 38, premium: false,
    description: "Vue 3, Composition API va Pinia yordamida tezkor va tushunarli veb-ilovalar yaratish.",
    tags: ['vue', 'frontend'],
    whatYouWillLearn: ['Vue 3 asoslari', 'Composition API', 'Pinia bilan holat boshqaruvi', 'Component dizayni'],
    requirements: ['JavaScript va HTML/CSS asoslari'],
    syllabus: [{ week: 1, title: 'Vue asoslari', topics: ['Direktivalar', 'Komponentlar'] }, { week: 2, title: 'Composition API', topics: ['Reactivity', 'Pinia'] }] },
  { m: 'otabek', title: 'Kotlin bilan Android dasturlash', category: 'Mobil', level: "O'rta", price: 780000, durationHours: 42, lessons: 50, premium: false,
    description: "Android Studio, Jetpack Compose va Room bazasi bilan zamonaviy Android ilovalar yaratish.",
    tags: ['android', 'kotlin', 'mobil'],
    whatYouWillLearn: ['Kotlin tili asoslari', 'Jetpack Compose bilan UI', "Room ma'lumotlar bazasi", 'Play Market\'ga chiqarish'],
    requirements: ['Dasturlash asoslari'],
    syllabus: [{ week: 1, title: 'Kotlin', topics: ['Sintaksis'] }, { week: 2, title: 'Compose UI', topics: ['Layout', 'State'] }, { week: 3, title: "Ma'lumotlar bazasi", topics: ['Room', 'API'] }] },
  { m: 'bekzod', title: "SQL va ma'lumotlar bazalari", category: "Ma'lumotlar", level: "Boshlang'ich", price: 420000, durationHours: 22, lessons: 30, premium: false,
    description: "Jadval dizayni, murakkab so'rovlar, indekslash va optimallashtirish — PostgreSQL misolida.",
    tags: ['sql', 'database', "ma'lumotlar"],
    whatYouWillLearn: ["Ma'lumotlar bazasi dizayni", "SQL so'rovlari", 'Indekslash va optimallashtirish', 'PostgreSQL bilan amaliyot'],
    requirements: ['Talab qilinmaydi'],
    syllabus: [{ week: 1, title: 'Asoslar', topics: ['SELECT', 'JOIN'] }, { week: 2, title: 'Ilg\'or SQL', topics: ['Indekslar', 'Optimallashtirish'] }] },
  { m: 'dilnoza', title: 'Tarmoq xavfsizligi asoslari', category: 'Xavfsizlik', level: "Boshlang'ich", price: 390000, durationHours: 20, lessons: 26, premium: false,
    description: "Firewall, VPN, shifrlash va tarmoq monitoringi asoslari — amaliy laboratoriya mashqlari bilan.",
    tags: ['tarmoq', 'xavfsizlik'],
    whatYouWillLearn: ['Tarmoq protokollari', 'Firewall va VPN sozlash', 'Shifrlash asoslari', 'Monitoring vositalari'],
    requirements: ['Kompyuter tarmoqlari haqida umumiy tushuncha'],
    syllabus: [{ week: 1, title: 'Asoslar', topics: ['Protokollar'] }, { week: 2, title: 'Himoya', topics: ['Firewall', 'VPN'] }] },
  { m: 'malika', title: "IELTS Speaking master klassi", category: 'Tillar', level: 'Yuqori', price: 1150000, durationHours: 18, lessons: 20, premium: true,
    description: "Faqat Speaking bo'yicha chuqur amaliyot: haftalik shaxsiy mock intervyu va batafsil fikr-mulohaza 8.0+ maqsadidagilar uchun.",
    tags: ['ielts', 'speaking', 'ingliz tili'],
    whatYouWillLearn: ['Yuqori ball uchun leksika', 'Tabiiy va ravon nutq', 'Shaxsiy zaif tomonlarni tuzatish', 'Haqiqiy imtihon formatida mashq'],
    requirements: ["IELTS 6.5+ yoki shunga teng daraja"],
    syllabus: [{ week: 1, title: 'Diagnostika', topics: ['Boshlang\'ich mock test'] }, { week: 2, title: 'Amaliyot', topics: ['Haftalik intervyu'] }, { week: 3, title: 'Yakuniy tayyorgarlik', topics: ['Imtihon strategiyasi'] }] },
];

function pastDay(daysAgo) {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - daysAgo);
  return d.getTime();
}

function seed() {
  const { users, courses, reviews } = db.data;

  if (!users.some((u) => u.role === 'admin')) {
    users.push({
      id: db.id(),
      name: config.admin.name,
      email: config.admin.email,
      passwordHash: bcrypt.hashSync(config.admin.password, config.bcryptRounds),
      role: 'admin',
      verified: true,
      createdAt: Date.now(),
    });
    console.log(`[seed] Admin yaratildi: ${config.admin.email}  /  ${config.admin.password}`);
  }

  // ADMIN_EMAIL berilgan bo'lsa, admin hisobi shu (haqiqiy) emailga o'tkaziladi — kirish kodi shu yerga boradi
  if (process.env.ADMIN_EMAIL) {
    const adm = users.find((u) => u.role === 'admin');
    if (adm && adm.email !== config.admin.email) {
      adm.email = config.admin.email;
      adm.verified = true;
      console.log(`[seed] Admin emaili yangilandi: ${config.admin.email}`);
    }
  }

  const mentorIdByKey = {};
  if (!users.some((u) => u.role === 'mentor')) {
    MENTORS.forEach((m, i) => {
      const user = {
        id: db.id(),
        name: m.name,
        email: m.email,
        passwordHash: bcrypt.hashSync('Mentor12345', config.bcryptRounds),
        role: 'mentor',
        verified: true,
        mTitle: m.title,
        mBio: m.bio,
        mSpecialty: m.specialty,
        mAvatarKey: m.avatarKey,
        mAchievements: m.achievements,
        createdAt: pastDay(400 - i * 10),
      };
      users.push(user);
      mentorIdByKey[m.key] = user.id;
    });
    console.log(`[seed] ${MENTORS.length} ta mentor yaratildi (parol: Mentor12345)`);
  } else {
    users.filter((u) => u.role === 'mentor').forEach((u) => {
      const found = MENTORS.find((m) => m.email === u.email);
      if (found) mentorIdByKey[found.key] = u.id;
    });
  }

  if (courses.length === 0) {
    COURSES.forEach((c, i) => {
      const { m, ...rest } = c;
      courses.push({ id: db.id(), ...rest, mentorId: mentorIdByKey[m] || null, createdAt: pastDay(300 - i * 6) });
    });
    console.log(`[seed] ${COURSES.length} ta kurs qo'shildi (${COURSES.filter((c) => c.premium).length} tasi premium)`);
  }

  // Namunaviy o'quvchilar, yozilishlar va sharhlar — faqat birinchi marta, real ko'rinish uchun
  const DEMO = [
    { name: 'Aziza Karimova', email: 'aziza.demo@example.uz', title: 'Node.js va Express: professional backend', rating: 5, text: "Kurs juda tushunarli va amaliy. Mentorning tushuntirishlari aniq, har bir modulda real loyiha bor edi." },
    { name: 'Jahongir Yoqubov', email: 'jahongir.demo@example.uz', title: 'React bilan real loyihalar', rating: 5, text: "Portfoliomga 3 ta loyiha qo'sha oldim. Mentor har bir savolga tez javob berdi." },
    { name: 'Shahnoza Mirzayeva', email: 'shahnoza.demo@example.uz', title: 'UI/UX dizayn: Figma bilan', rating: 5, text: "Nazariya kam, amaliyot ko'p — aynan shuni yoqtirdim. Figma'ni endi ishonch bilan ishlataman." },
    { name: 'Diyorbek Saidov', email: 'diyorbek.demo@example.uz', title: 'IELTS 7+ intensiv kursi', rating: 5, text: "Mock testlar juda foydali bo'ldi, natijada 7.5 ball oldim." },
    { name: 'Kamronbek Raxmonov', email: 'kamron.demo@example.uz', title: 'JWT va xavfsiz autentifikatsiya', rating: 4, text: "Chuqur va texnik kurs. Backend asoslarini bilganlar uchun juda mos." },
    { name: "Zilola To'lqinova", email: 'zilola.demo@example.uz', title: "Python: noldan ma'lumotlar tahliligacha", rating: 5, text: "O'qituvchi juda sabrli, har bir savolimga batafsil javob berdi. Real dataset bilan ishlash ayniqsa foydali bo'ldi." },
    { name: 'Sanjarbek Ismoilov', email: 'sanjar.demo@example.uz', title: 'Flutter: mobil ilovalar yaratish', rating: 4, text: "Ilovamni Play Market'ga chiqara oldim, bu men uchun katta yutuq. Ba'zi darslarni qayta ko'rishga to'g'ri keldi." },
  ];
  if (reviews.length === 0 && courses.length) {
    DEMO.forEach((d, i) => {
      const course = courses.find((c) => c.title === d.title);
      if (!course) return;
      let demo = users.find((u) => u.email === d.email);
      if (!demo) {
        demo = { id: db.id(), name: d.name, email: d.email, passwordHash: bcrypt.hashSync('Demo12345', config.bcryptRounds), role: 'user', verified: true, createdAt: pastDay(150 - i * 8) };
        users.push(demo);
      }
      db.data.enrollments.push({ id: db.id(), userId: demo.id, courseId: course.id, completed: true, completedAt: pastDay(90 - i * 6), createdAt: pastDay(130 - i * 6) });
      reviews.push({ id: db.id(), userId: demo.id, courseId: course.id, rating: d.rating, text: d.text, createdAt: pastDay(85 - i * 6) });
    });
    console.log(`[seed] ${reviews.length} ta namunaviy sharh va yozilish qo'shildi`);
  }

  db.save();
}

module.exports = { seed };
