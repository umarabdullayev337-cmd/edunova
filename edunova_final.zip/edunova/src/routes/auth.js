const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db');
const { sendCodeEmail, MailError } = require('../utils/mailer');
const { issueSession, clearRefreshCookie, COOKIE } = require('../utils/tokens');
const { wrap, sha, publicUser } = require('../utils/helpers');
const { loginLimiter, sensitiveLimiter } = require('../middleware/security');

const router = express.Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const CODE_TTL = 10 * 60 * 1000;
const RESEND_COOLDOWN = 60 * 1000;
const MAX_ATTEMPTS = 5;
const REUSE_GRACE = 10 * 1000; // bir vaqtda ikki tab refresh qilsa, xato deb hisoblamaslik uchun

// Vaqt bo'yicha farqni yashirish uchun (foydalanuvchi topilmasa ham bcrypt ishlaydi)
const DUMMY_HASH = bcrypt.hashSync('edunova-dummy-password', config.bcryptRounds);

const normEmail = (v) => String(v || '').trim().toLowerCase();

function newCode(user) {
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0'); // random 6 digit
  user.verifyCodeHash = sha(code + user.id);
  user.verifyExpires = Date.now() + CODE_TTL;
  user.verifyAttempts = 0;
  user.verifySentAt = Date.now();
  return code;
}

// Kirish (login) uchun alohida kod: parol to'g'ri bo'lgandan keyin emailga yuboriladi
function newLoginCode(user) {
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  user.loginCodeHash = sha(code + user.id + 'login');
  user.loginExpires = Date.now() + CODE_TTL;
  user.loginAttempts = 0;
  user.loginSentAt = Date.now();
  return code;
}

function validateRegistration(body) {
  const errors = [];
  const name = String(body?.name || '').trim().replace(/\s+/g, ' ');
  const email = normEmail(body?.email);
  const password = String(body?.password || '');
  if (name.length < 2 || name.length > 60) errors.push("Ism 2–60 ta belgidan iborat bo'lishi kerak");
  if (!EMAIL_RE.test(email) || email.length > 120) errors.push("Email manzil noto'g'ri");
  if (password.length < 8 || password.length > 72 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    errors.push("Parol kamida 8 ta belgi bo'lib, harf va raqamni o'z ichiga olishi kerak");
  }
  return { errors, name, email, password };
}

// ---------- 1) Register ----------
router.post('/register', sensitiveLimiter, wrap(async (req, res) => {
  const { errors, name, email, password } = validateRegistration(req.body);
  if (errors.length) return res.status(400).json({ error: errors[0], errors });

  let user = db.findUserByEmail(email);
  if (user && user.verified) {
    return res.status(409).json({ error: "Bu email bilan hisob allaqachon mavjud. Tizimga kiring.", code: 'EMAIL_TAKEN' });
  }

  const passwordHash = await bcrypt.hash(password, config.bcryptRounds); // bcrypt bilan hashlangan parol
  if (user) {
    // Tasdiqlanmagan hisob: ma'lumotlarni yangilab, yangi kod yuboramiz
    user.name = name;
    user.passwordHash = passwordHash;
  } else {
    user = {
      id: db.id(),
      name,
      email,
      passwordHash,
      role: 'user', // ro'yxatdan o'tganda doim "user" — admin bo'lish faqat admin tomonidan
      verified: false,
      createdAt: Date.now(),
    };
    db.data.users.push(user);
  }

  const code = newCode(user);
  db.save();
  await sendCodeEmail(email, name, code, 'register');

  res.status(201).json({ message: `Tasdiqlash kodi ${email} manziliga yuborildi`, email });
}));

// ---------- 5) Email verification ----------
router.post('/verify', sensitiveLimiter, wrap(async (req, res) => {
  const email = normEmail(req.body?.email);
  const code = String(req.body?.code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(code)) return res.status(400).json({ error: "Kod 6 ta raqamdan iborat bo'lishi kerak" });

  const user = db.findUserByEmail(email);
  const generic = { error: "Kod noto'g'ri yoki muddati o'tgan", code: 'BAD_CODE' };
  if (!user) return res.status(400).json(generic);
  if (user.verified) return res.status(400).json({ error: 'Email allaqachon tasdiqlangan. Tizimga kiring.', code: 'ALREADY_VERIFIED' });
  if (!user.verifyCodeHash || Date.now() > user.verifyExpires) {
    return res.status(400).json({ error: "Kod muddati tugagan. Yangi kod so'rang.", code: 'CODE_EXPIRED' });
  }
  if (user.verifyAttempts >= MAX_ATTEMPTS) {
    return res.status(429).json({ error: "Urinishlar limiti tugadi. Yangi kod so'rang.", code: 'TOO_MANY_ATTEMPTS' });
  }

  user.verifyAttempts += 1;
  const given = Buffer.from(sha(code + user.id));
  const real = Buffer.from(user.verifyCodeHash);
  const ok = given.length === real.length && crypto.timingSafeEqual(given, real);
  if (!ok) {
    db.save();
    const left = MAX_ATTEMPTS - user.verifyAttempts;
    return res.status(400).json({ error: `Kod noto'g'ri. Qolgan urinishlar: ${left}`, code: 'BAD_CODE' });
  }

  user.verified = true;
  delete user.verifyCodeHash;
  delete user.verifyExpires;
  delete user.verifyAttempts;
  delete user.verifySentAt;
  db.save();

  const session = issueSession(res, user);
  res.json({ message: 'Email muvaffaqiyatli tasdiqlandi', ...session, user: publicUser(user) });
}));

router.post('/resend', sensitiveLimiter, wrap(async (req, res) => {
  const email = normEmail(req.body?.email);
  const user = db.findUserByEmail(email);
  const reply = { message: 'Agar bu email ro\'yxatdan o\'tgan bo\'lsa, yangi kod yuborildi' };

  if (!user || user.verified) return res.json(reply); // email mavjudligini oshkor qilmaymiz
  const wait = RESEND_COOLDOWN - (Date.now() - (user.verifySentAt || 0));
  if (wait > 0) {
    return res.status(429).json({ error: `Yangi kodni ${Math.ceil(wait / 1000)} soniyadan keyin so'rang`, code: 'COOLDOWN' });
  }
  const code = newCode(user);
  db.save();
  await sendCodeEmail(email, user.name, code, 'register');
  res.json(reply);
}));

// ---------- 1) Login: 1-bosqich — parol; 2-bosqich — emailga kelgan kod ----------
router.post('/login', loginLimiter, wrap(async (req, res) => {
  const email = normEmail(req.body?.email);
  const password = String(req.body?.password || '');
  if (!email || !password) return res.status(400).json({ error: 'Email va parolni kiriting' });

  const user = db.findUserByEmail(email);
  const match = await bcrypt.compare(password, user ? user.passwordHash : DUMMY_HASH);
  if (!user || !match) {
    return res.status(401).json({ error: "Email yoki parol noto'g'ri", code: 'BAD_CREDENTIALS' });
  }
  if (!user.verified) {
    const code = newCode(user);
    db.save();
    await sendCodeEmail(user.email, user.name, code, 'register');
    return res.status(403).json({ error: `Avval emailingizni tasdiqlang. Kod ${user.email} manziliga yuborildi`, code: 'EMAIL_NOT_VERIFIED' });
  }

  // Admin: parol to'g'ri bo'lsa, kod so'ralmasdan darhol kiradi
  if (user.role === 'admin') {
    const session = issueSession(res, user);
    return res.json({ ...session, user: publicUser(user) });
  }

  // Oddiy foydalanuvchi: parol to'g'ri — kod aynan shu hisobning emailiga yuboriladi
  const code = newLoginCode(user);
  db.save();
  await sendCodeEmail(user.email, user.name, code, 'login');
  res.json({ needsCode: true, email: user.email, message: `Kirish kodi ${user.email} manziliga yuborildi` });
}));

router.post('/login/verify', sensitiveLimiter, wrap(async (req, res) => {
  const email = normEmail(req.body?.email);
  const code = String(req.body?.code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(code)) return res.status(400).json({ error: "Kod 6 ta raqamdan iborat bo'lishi kerak" });
  const user = db.findUserByEmail(email);
  const generic = { error: "Kod noto'g'ri yoki muddati o'tgan", code: 'BAD_CODE' };
  if (!user || !user.verified || !user.loginCodeHash) return res.status(400).json(generic);
  if (Date.now() > user.loginExpires) return res.status(400).json({ error: "Kod muddati tugagan. Qayta kiring.", code: 'CODE_EXPIRED' });
  if (user.loginAttempts >= MAX_ATTEMPTS) return res.status(429).json({ error: "Urinishlar limiti tugadi. Qaytadan kirishni boshlang.", code: 'TOO_MANY_ATTEMPTS' });

  user.loginAttempts += 1;
  const given = Buffer.from(sha(code + user.id + 'login'));
  const real = Buffer.from(user.loginCodeHash);
  const ok = given.length === real.length && crypto.timingSafeEqual(given, real);
  if (!ok) {
    db.save();
    return res.status(400).json({ error: `Kod noto'g'ri. Qolgan urinishlar: ${MAX_ATTEMPTS - user.loginAttempts}`, code: 'BAD_CODE' });
  }
  delete user.loginCodeHash; delete user.loginExpires; delete user.loginAttempts; delete user.loginSentAt;
  db.save();
  const session = issueSession(res, user);
  res.json({ ...session, user: publicUser(user) });
}));

router.post('/login/resend', sensitiveLimiter, wrap(async (req, res) => {
  const email = normEmail(req.body?.email);
  const user = db.findUserByEmail(email);
  const reply = { message: "Agar bu hisob mavjud bo'lsa, yangi kod yuborildi" };
  if (!user || !user.verified || !user.loginCodeHash) return res.json(reply); // faqat kirish boshlangan bo'lsa
  const wait = RESEND_COOLDOWN - (Date.now() - (user.loginSentAt || 0));
  if (wait > 0) return res.status(429).json({ error: `Yangi kodni ${Math.ceil(wait / 1000)} soniyadan keyin so'rang`, code: 'COOLDOWN' });
  const code = newLoginCode(user);
  db.save();
  await sendCodeEmail(user.email, user.name, code, 'login');
  res.json(reply);
}));

// ---------- 3) Refresh (cookie orqali yangi access token) ----------
router.post('/refresh', wrap(async (req, res) => {
  const token = req.cookies?.[COOKIE];
  if (!token) return res.status(401).json({ error: 'Sessiya topilmadi', code: 'NO_REFRESH' });

  let payload;
  try {
    payload = jwt.verify(token, config.refreshSecret);
  } catch {
    clearRefreshCookie(res);
    return res.status(401).json({ error: 'Sessiya muddati tugagan. Qayta kiring.', code: 'REFRESH_INVALID' });
  }

  const record = db.data.refreshTokens.find((t) => t.jti === payload.jti);
  if (!record) {
    clearRefreshCookie(res);
    return res.status(401).json({ error: 'Sessiya yaroqsiz. Qayta kiring.', code: 'REFRESH_INVALID' });
  }

  const now = Date.now();
  if (record.revoked) {
    // Eski token qayta ishlatilsa — o'g'irlangan bo'lishi mumkin: foydalanuvchining barcha sessiyalari bekor qilinadi
    if (now - (record.revokedAt || 0) > REUSE_GRACE) {
      db.data.refreshTokens.forEach((t) => {
        if (t.userId === record.userId) { t.revoked = true; t.revokedAt = t.revokedAt || now; }
      });
      db.save();
      clearRefreshCookie(res);
      return res.status(401).json({ error: 'Xavfsizlik uchun barcha sessiyalar yopildi. Qayta kiring.', code: 'REFRESH_REUSED' });
    }
  } else {
    record.revoked = true; // rotation: har safar yangi refresh token beriladi
    record.revokedAt = now;
  }

  const user = db.findUser(record.userId);
  if (!user || !user.verified) {
    clearRefreshCookie(res);
    return res.status(401).json({ error: 'Foydalanuvchi topilmadi', code: 'REFRESH_INVALID' });
  }

  const session = issueSession(res, user);
  res.json({ ...session, user: publicUser(user) });
}));

router.post('/logout', wrap(async (req, res) => {
  const token = req.cookies?.[COOKIE];
  if (token) {
    const payload = jwt.decode(token);
    const record = payload && db.data.refreshTokens.find((t) => t.jti === payload.jti);
    if (record && !record.revoked) {
      record.revoked = true;
      record.revokedAt = Date.now();
      db.save();
    }
  }
  clearRefreshCookie(res);
  res.json({ message: 'Tizimdan chiqildi' });
}));

module.exports = router;
module.exports.MailError = MailError;
