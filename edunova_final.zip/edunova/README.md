# EduNova — IT ta'lim platformasi

Express.js backend + premium frontend. Ro'yxatdan o'tish, email tasdiqlash, JWT (access + refresh), rollar (user/mentor/admin), kurslar, mentorlar, sharhlar, onlayn sertifikat, shaxsiy tavsiya va haftalik reja, premium status, tug'ilgan kun bonusi, admin panel.

## Ishga tushirish

```bash
npm install
cp .env.example .env      # ixtiyoriy — .env bo'lmasa ham ishlaydi
npm start
```

Brauzerda oching: **http://localhost:3000** (127.0.0.1 emas, CORS faqat `localhost:3000` ga ruxsat beradi).

Birinchi ishga tushishda avtomatik yaratiladi:
- **Admin:** `admin@edunova.uz` / `Admin12345` (`.env` da o'zgartiriladi)
- **13 ta mentor** (parol: `Mentor12345`), har biri o'z bio, mutaxassislik va yutuqlari bilan
- **18 ta kurs** (shundan 6 tasi premium), har biri dastur (syllabus), nimalarni o'rganish, talablar bilan
- Bir nechta **namunaviy o'quvchi, yakunlangan kurs va sharh** — platforma bo'sh ko'rinmasligi uchun

**Email:** `.env` da SMTP sozlanmasa, 6 xonali kod terminalga chiqadi va (dev rejimida) tasdiqlash sahifasida ham ko'rinadi.

## Asosiy imkoniyatlar

### Autentifikatsiya va xavfsizlik
- Ro'yxatdan o'tish/kirish, bcrypt bilan parol, access token 15 daqiqa (JSON), refresh token 7 kun (httpOnly cookie, rotation bilan)
- Email tasdiqlash: random 6 xonali kod, 10 daqiqa amal qiladi, 5 urinish limiti
- Helmet, qat'iy CSP, CORS, `/auth/login` ga 1 daqiqada 5 so'rov, umumiy DDoS himoyasi (rate-limit + slow-down)
- Rollar: **user**, **mentor**, **admin** — har biri alohida huquqlarga ega

### Kurslar
- To'liq kurs sahifasi: dastur (haftalik syllabus), nimalarni o'rganasiz, talablar, mentor profili, sharhlar
- **Premium kurslar** — kamroq, lekin chuqurroq va qimmatroq dasturlar; faqat premium statusli foydalanuvchilar yoziladi
- Sharhlar (otzivlar): faqat kursni **yakunlagan** foydalanuvchi baho va fikr qoldira oladi

### Mentorlar
- Alohida `mentor` roli — `user` yoki `admin`dan farqli. Har bir mentorning ommaviy profili (`/mentors/:id`): bio, mutaxassislik, yutuqlar, kurslari va reytingi
- Admin panel orqali yangi mentor yaratish yoki mavjudini tahrirlash mumkin

### Shaxsiylashtirish
- Ro'yxatdan o'tgach qisqa so'rovnoma (`/onboarding`): qiziqishlar, maqsad (universitet / ish / frilanser / startap / hobbi), daraja, haftalik vaqt
- Shu asosida **shaxsiy kurs tavsiyalari** va **haftalik o'quv rejasi** avtomatik tuziladi (`GET /profile/recommendations`)

### Profil rasmi
- Ikki xil usulda qo'yiladi: **URL orqali** yoki **kompyuterdan yuklab** (base64, 190 KB gacha, server tomonida ham tekshiriladi)

### Sertifikat
- Kursni yakunlagan foydalanuvchi ism-familiyasini kiritib onlayn sertifikat oladi
- Har bir sertifikat noyob kod bilan (`EDU-XXXX-XXXX`) va `/#/certificate/:code` orqali **hamma uchun tekshiriladi** (ish beruvchilar uchun)
- Chop etish/PDF saqlash tugmasi bilan

### Murojaatlar (Yordam)
- `/help` sahifasida har qanday foydalanuvchi (yoki mehmon) adminga xabar yuboradi
- Admin panelda barcha murojaatlar ko'rinadi, javob yoziladi, holati kuzatiladi

### Tug'ilgan kun bonusi
- Foydalanuvchi profilida tug'ilgan sanasini kiritsa, o'sha kuni tizimga kirganda **avtomatik 1 kunlik premium** beriladi (yiliga bir marta)

### Admin panel
- Statistika: foydalanuvchilar, mentorlar, kurslar, yozilishlar, sertifikatlar, sharhlar, ochiq murojaatlar, premium foydalanuvchilar, umumiy summasi
- **Kurslar**: to'liq CRUD — mentor biriktirish, premium belgisi, teglar, syllabus, talablar
- **Foydalanuvchilar**: rolni o'zgartirish (user/mentor/admin), o'chirish
- **Mentorlar**: yangi mentor yaratish (vaqtinchalik parol bilan), tahrirlash, avatar tanlash
- **Murojaatlar**: ko'rish, filtrlash, javob yozish, o'chirish

## API (qisqacha)

| Metod | Yo'l | Kirish |
|-------|------|--------|
| POST | `/auth/register`, `/auth/verify`, `/auth/resend`, `/auth/login` | ochiq |
| POST | `/auth/refresh`, `/auth/logout` | cookie |
| GET/PATCH | `/profile` | access token |
| PUT | `/profile/avatar`, `/profile/onboarding` | access token |
| GET | `/profile/recommendations` | access token |
| GET | `/courses`, `/courses/:id`, `/courses/:id/reviews`, `/courses/reviews/recent` | ochiq |
| POST/PUT/DELETE | `/courses`, `/courses/:id` | admin |
| POST/DELETE | `/courses/:id/enroll` | access token |
| POST | `/courses/:id/enroll/complete` | access token |
| POST | `/courses/:id/reviews` | access token (kurs yakunlangan bo'lishi kerak) |
| GET | `/mentors`, `/mentors/:id` | ochiq |
| POST | `/messages` | ochiq (ixtiyoriy token) |
| GET | `/certificates/mine` | access token |
| POST | `/certificates` | access token (kurs yakunlangan bo'lishi kerak) |
| GET | `/certificates/verify/:code` | ochiq |
| GET | `/admin/dashboard`, `/admin/users`, `/admin/mentors`, `/admin/messages` | admin |
| POST/PATCH/DELETE | `/admin/mentors`, `/admin/users/:id/...`, `/admin/messages/:id` | admin |

## Productionga chiqarish

`NODE_ENV=production`, `JWT_ACCESS_SECRET` va `JWT_REFRESH_SECRET` (kamida 32 belgi), `CLIENT_ORIGIN` (haqiqiy domen), SMTP sozlamalari, HTTPS. Ma'lumotlar hozircha `data/db.json` da; katta yuklama uchun `src/db.js` ni MongoDB yoki PostgreSQL ga almashtiring.

## Struktura

```
server.js
src/  config.js  db.js  seed.js
      middleware/  auth.js  security.js
      routes/      auth.js  profile.js  courses.js  mentors.js  messages.js  certificates.js  admin.js
      utils/       tokens.js  mailer.js  helpers.js
public/  index.html  favicon.svg  css/styles.css  js/api.js  js/app.js  img/avatars/*.svg
tools/   make-avatars.py   (multfilm uslubidagi avatarlarni qayta generatsiya qilish uchun)
```

## Darslar, almazlar va do'kon (yangi)

- **Darslar**: `src/lessons/*.js` — 18 kurs, jami 90 ta dars (har kursda 5 ta slayd dars) + har kursga 1 ta amaliy ish. Yangi dars qo'shish uchun tegishli fayldagi `lessons` massiviga `[sarlavha, matn, [savollar]]` qo'shing. Savol: `[matn, [variantlar], to'g'ri_indeks, qiyin(1)/oddiy(0), izoh]`.
- **Almaz**: oddiy savol +10, qiyin +15, amaliy ish yakuni +100. Hamma narx `src/shop.js` da (premium kurs 3000, premium avatar 2000).
- **Do'kon**: `#/shop` — ramkalar, effektli premium avatarlar, premium kursni almazga ochish.
- Javoblar serverda tekshiriladi; to'g'ri javob faqat javob berilgandan keyin yuboriladi.


## Email orqali kirish kodi (MUHIM)

Kirishda parol to'g'ri bo'lgach, 6 xonali kod **hisob emailiga** yuboriladi. Kodsiz kirib bo'lmaydi. Kod sahifada ko'rsatilmaydi.
Kod haqiqiy emailga borishi uchun SMTP sozlang:

1. `.env.example` ni `.env` ga nusxalang.
2. `SMTP_USER` va `SMTP_PASS` ni to'ldiring. Gmail uchun: Google hisob → Xavfsizlik → 2 bosqichli tekshiruv → **Ilova parollari** (oddiy parol ishlamaydi).
3. `ADMIN_EMAIL` ga o'zingizning HAQIQIY emailingizni yozing — admin kodi shu yerga keladi. (Demo mentorlarning `@edunova.uz` emaillari soxta, ularga kod bormaydi.)
4. `npm start`. Konsolda `[mail] SMTP tayyor` chiqsa, hammasi joyida.

SMTP sozlanmasa: lokal rejimda kod faqat server konsoliga yoziladi (sahifada ko'rinmaydi), production rejimda esa xizmat 503 qaytaradi.

## Ball va rank

Ball (XP) almazdan alohida, shuning uchun almaz sarflasangiz rank tushmaydi. To'g'ri javob: +10/+15, dars yakuni +20, 100% to'g'ri uy ishi +10, amaliy ish +100, kurs yakuni +50.
Ranklar: Yangi (0), Shogird (150), Tajribali (500), Usta (1200), Ekspert (2500), Afsona (4500). Hammasi `src/rank.js` da. Reyting sahifasi: `#/ranks`.

## MongoDB + Compass (ixtiyoriy)

`.env` ga `MONGODB_URI=mongodb://localhost:27017` qo'shsangiz, ma'lumotlar MongoDB'da (baza: `edunova`) saqlanadi va Compass'da ko'rinadi. Birinchi ishga tushishda `data/db.json` dagi ma'lumot avtomatik ko'chadi. `MONGODB_URI` bo'lmasa, sayt avvalgidek faqat `data/db.json` bilan ishlaydi. Kod: `src/mongo.js`.

## Admin va VIP

- Admin parol bilan darhol kiradi (email kodi so'ralmaydi). Oddiy foydalanuvchilarga kod emailga yuboriladi.
- Admin va faol premium statusli foydalanuvchilarga do'kondagi hamma ramka, avatar va premium kurslar bepul ochiq (`src/routes/shop.js`, `src/utils/helpers.js`).
