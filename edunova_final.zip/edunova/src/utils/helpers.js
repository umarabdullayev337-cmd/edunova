const crypto = require('crypto');
const db = require('../db');
const lessonsLib = require('../lessons');
const { rankOf } = require('../rank');

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const DAY = 24 * 60 * 60 * 1000;

// ---------- Tug'ilgan kun bonusi: har yili faqat bir marta 1 kunlik premium ----------
function applyBirthdayBonus(user) {
  if (!user.birthday) return;
  const today = new Date();
  const parts = String(user.birthday).split('-'); // "YYYY-MM-DD"
  const mm = Number(parts[1]);
  const dd = Number(parts[2]);
  const isToday = mm === today.getMonth() + 1 && dd === today.getDate();
  const thisYear = today.getFullYear();
  if (isToday && user.lastBirthdayBonusYear !== thisYear) {
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999);
    user.premiumUntil = Math.max(user.premiumUntil || 0, endOfDay.getTime());
    user.lastBirthdayBonusYear = thisYear;
    user.birthdayBonusActive = true;
    db.save();
  }
}

// Admin doim VIP (premium); oddiy foydalanuvchi uchun premium muddati tekshiriladi
const isPremiumActive = (user) => user.role === 'admin' || !!(user.premiumUntil && user.premiumUntil > Date.now());

const publicUser = (u) => {
  applyBirthdayBonus(u);
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    verified: !!u.verified,
    avatar: u.avatar || null,
    birthday: u.birthday || null,
    interests: u.interests || [],
    goal: u.goal || null,
    level: u.level || null,
    onboarded: !!u.onboarded,
    diamonds: u.diamonds || 0,
    xp: u.xp || 0,
    rank: rankOf(u.xp || 0),
    frame: u.frame || null,
    unlockedCourses: u.unlockedCourses || [],
    isPremium: isPremiumActive(u),
    premiumUntil: u.premiumUntil || null,
    birthdayBonusActive: !!(u.birthdayBonusActive && isPremiumActive(u)),
    createdAt: u.createdAt,
    ...(u.role === 'mentor' ? { mentor: mentorProfile(u) } : {}),
  };
};

const mentorProfile = (u) => ({
  title: u.mTitle || '',
  bio: u.mBio || '',
  avatarKey: u.mAvatarKey || 'm-jasur',
  specialty: u.mSpecialty || '',
  achievements: u.mAchievements || [],
  mentorSince: u.createdAt,
});

const mentorView = (u) => {
  const courses = db.data.courses.filter((c) => c.mentorId === u.id);
  const reviews = db.data.reviews.filter((r) => courses.some((c) => c.id === r.courseId));
  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : null;
  return {
    id: u.id,
    name: u.name,
    ...mentorProfile(u),
    courseCount: courses.length,
    studentCount: db.data.enrollments.filter((e) => courses.some((c) => c.id === e.courseId)).length,
    rating: avg ? Math.round(avg * 10) / 10 : null,
    reviewCount: reviews.length,
  };
};

const mentorBrief = (mentorId) => {
  const m = db.findMentor(mentorId);
  if (!m) return null;
  return { id: m.id, name: m.name, title: m.mTitle || '', avatarKey: m.mAvatarKey || 'm-jasur' };
};

function reviewsFor(courseId) {
  return db.data.reviews.filter((r) => r.courseId === courseId);
}

function ratingOf(courseId) {
  const rs = reviewsFor(courseId);
  if (!rs.length) return { rating: null, reviewCount: 0 };
  return { rating: Math.round((rs.reduce((s, r) => s + r.rating, 0) / rs.length) * 10) / 10, reviewCount: rs.length };
}

const curriculumOf = (c) => {
  const content = lessonsLib.getContent(c);
  if (!content) return null;
  return {
    lessons: content.lessons.map((l) => ({ title: l.title, questions: l.qs.length })),
    practical: content.practical ? { title: content.practical.title, questions: content.practical.qs.length } : null,
  };
};

const courseView = (c) => {
  const { rating, reviewCount } = ratingOf(c.id);
  return {
    id: c.id,
    title: c.title,
    description: c.description,
    category: c.category,
    level: c.level,
    price: c.price,
    premium: !!c.premium,
    durationHours: c.durationHours,
    lessons: c.lessons,
    tags: c.tags || [],
    whatYouWillLearn: c.whatYouWillLearn || [],
    requirements: c.requirements || [],
    syllabus: c.syllabus || [],
    curriculum: curriculumOf(c),
    instructor: c.instructor,
    mentor: mentorBrief(c.mentorId),
    createdAt: c.createdAt,
    students: db.data.enrollments.filter((e) => e.courseId === c.id).length,
    rating,
    reviewCount,
  };
};

const reviewView = (r) => {
  const u = db.findUser(r.userId);
  return {
    id: r.id,
    courseId: r.courseId,
    userId: r.userId,
    rating: r.rating,
    text: r.text,
    createdAt: r.createdAt,
    user: u ? { name: u.name, avatar: u.avatar || null, frame: u.frame || null, rank: rankOf(u.xp || 0).level } : { name: "O'chirilgan foydalanuvchi", avatar: null },
  };
};

const messageView = (m) => ({
  id: m.id,
  name: m.name,
  email: m.email,
  subject: m.subject,
  text: m.text,
  userId: m.userId || null,
  status: m.status,
  reply: m.reply || null,
  repliedAt: m.repliedAt || null,
  createdAt: m.createdAt,
});

const certificateView = (c) => {
  const course = db.findCourse(c.courseId);
  return {
    id: c.id,
    code: c.code,
    fullName: c.fullName,
    courseId: c.courseId,
    courseTitle: course ? course.title : c.courseTitleSnapshot,
    durationHours: course ? course.durationHours : c.durationHoursSnapshot,
    mentor: course ? mentorBrief(course.mentorId) : null,
    issuedAt: c.issuedAt,
  };
};

module.exports = {
  wrap, sha, publicUser, courseView, mentorView, mentorBrief, mentorProfile,
  reviewView, reviewsFor, ratingOf, messageView, certificateView,
  isPremiumActive, applyBirthdayBonus, DAY,
};
