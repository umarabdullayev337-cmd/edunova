// Xavfsizlik kurslari: OWASP Top 10, Tarmoq xavfsizligi
module.exports = {
'Veb xavfsizlik: OWASP Top 10': { lessons: [
['OWASP Top 10 va xavfsizlik fikrlash tarzi', `OWASP — veb xavfsizligi bo'yicha nodavlat hamjamiyat. Top 10 — veb ilovalardagi eng keng tarqalgan va xavfli zaifliklar ro'yxati; u davriy yangilanadi.

Xavfsizlikning asosiy tamoyillari: eng kam huquq (least privilege), chuqur himoya (defense in depth — bir necha qatlam), "hech kimga ishonma" (kiruvchi har bir ma'lumotni tekshir) va oddiylik. Bu kurs faqat himoya maqsadida: o'z ilovangiz yoki ruxsat berilgan muhitda sinang. Ruxsatsiz tizimga hujum qilish jinoyat.`,
 [['OWASP Top 10 nima?', ['Eng keng tarqalgan veb zaifliklar ro\'yxati','Dasturlash tili','Antivirus','Parol menejeri'],0,0,'Xabardorlik hujjati.'],
  ['"Eng kam huquq" tamoyili nima?', ['Foydalanuvchi/jarayonga faqat zarur ruxsatlarni berish','Hammaga admin berish','Parolsiz kirish','Ruxsatni olib tashlamaslik'],0,0,'Zararni cheklaydi.'],
  ['Ruxsatsiz begona saytni "sinab ko\'rish" nima hisoblanadi?', ['Jinoyat bo\'lishi mumkin','Odatiy amaliyot','Ruxsat etilgan','Mashq'],0,1,'Faqat ruxsat berilgan muhitda.']]],
['Broken Access Control', `Eng keng tarqalgan zaiflik: foydalanuvchi o'ziga tegishli bo'lmagan narsaga kira oladi. IDOR (Insecure Direct Object Reference): /orders/105 ni /orders/106 ga almashtirib, boshqaning buyurtmasini ko'rish.

~~~
// Xavfli
const order = await Order.findById(req.params.id);
// To'g'ri: egalikni tekshirish
const order = await Order.findOne({ _id: req.params.id, userId: req.user.id });
~~~

Qoidalar: ruxsatni har so'rovda serverda tekshiring, standart holatda "taqiqlash", ID'ni emas, egalikni tekshirish. Frontend tugmasini yashirish himoya emas.`,
 [['IDOR nima?', ['Boshqa obyekt ID\'sini almashtirib unga kirish','SQL buyrug\'i','Parol turi','Xat turi'],0,0,'Egalik tekshirilmaydi.'],
  ['Ruxsat tekshiruvi qayerda majburiy?', ['Serverda','Faqat brauzerda','Faqat CSS\'da','Hech qayerda'],0,0,'Server.'],
  ['/orders/106 so\'rovida eng to\'g\'ri himoya?', ['Buyurtma shu foydalanuvchiga tegishliligini tekshirish','ID\'ni murakkab ko\'rsatish yetarli deb hisoblash','Tugmani yashirish','Hech narsa'],0,1,'Murakkab ID ham egalik tekshiruvini almashtirmaydi.']]],
['Kriptografik xatolar', `Sezgir ma'lumot (parol, token, shaxsiy ma'lumot) himoyasiz saqlansa yoki uzatilsa, u oshkor bo'ladi. Qoidalar:
- Uzatishda HTTPS (TLS) majburiy.
- Parollar bcrypt/Argon2 bilan hashlanadi — MD5 yoki SHA-1 emas.
- Kalitlarni kodga yozmang; muhit o'zgaruvchilari yoki maxfiy menejer ishlating.
- O'zingiz shifrlash algoritmini o'ylab topmang; tayyor, tekshirilgan kutubxonadan foydalaning.
- Keraksiz sezgir ma'lumotni umuman saqlamang.`,
 [['Parollar uchun qaysi yondashuv to\'g\'ri?', ['bcrypt/Argon2 hash','MD5','Ochiq matn','Base64'],0,0,'Sekin, salt\'li hash.'],
  ['Ma\'lumot uzatishda nima ishlatiladi?', ['HTTPS','HTTP','FTP','Telnet'],0,0,'TLS.'],
  ['O\'zi o\'ylab topilgan shifrlash algoritmi nega xavfli?', ['Mutaxassislar tomonidan tekshirilmagan, zaifliklar bo\'lish ehtimoli yuqori','Sekin','Qimmat','Xavfsiz'],0,1,'Kriptografiyada tayyor kutubxonadan foydalaning.']]],
['Injection: SQL va buyruq in\'ektsiyasi', `Injection — foydalanuvchi kiritgan matn so'rov yoki buyruqning bir qismiga aylanishi.

~~~
// XAVFLI
db.query("SELECT * FROM users WHERE name = '" + name + "'");
// name = ' OR '1'='1  -> hamma qatorlar

// XAVFSIZ: parametrli so'rov
db.query('SELECT * FROM users WHERE name = ?', [name]);
~~~

Himoya: parametrli so'rovlar (prepared statements), ORM'ning xavfsiz metodlari, kiruvchi ma'lumotni validatsiya qilish (ruxsat ro'yxati), baza foydalanuvchisiga minimal huquq. OS buyruqlarini foydalanuvchi matni bilan yig'masdan, xavfsiz API ishlating.`,
 [['SQL injection\'ga qarshi asosiy himoya?', ['Parametrli so\'rovlar','Matnni birlashtirish','Katta harf','Tirnoqlarni olib tashlash'],0,0,'Prepared statements.'],
  ['Injection nima?', ['Kiritilgan matn buyruq sifatida bajarilishi','Fayl yuklash','Rasm','Cookie turi'],0,0,'Ma\'lumot va kod aralashishi.'],
  ['Faqat tirnoq belgilarini o\'chirish nega ishonchsiz?', ['Boshqa usullar bilan aylanib o\'tish mumkin — parametrli so\'rov kerak','Sekin','Hech qachon ishlamaydi','Yetarli'],0,1,'Qora ro\'yxat zaif.']]],
['XSS: Cross-Site Scripting', `XSS — hujumchi zararli skriptni sahifaga joylashtirib, boshqa foydalanuvchi brauzerida ishlatishi. Natija: cookie/token o'g'irlash, sahifani o'zgartirish.

~~~
// Xavfli
el.innerHTML = userComment;
// Xavfsiz
el.textContent = userComment;
~~~

Himoya: chiqishda kodlash (escape), textContent yoki freymvork avtomatik escape'idan foydalanish, Content-Security-Policy (CSP) sarlavhasi, tokenlarni httpOnly cookie'da saqlash. Foydalanuvchi HTML'iga ruxsat berilsa — ishonchli sanitizatsiya kutubxonasi ishlating.`,
 [['XSS\'ga qarshi xavfsiz usul?', ['textContent / escape','innerHTML bilan matn qo\'yish','eval','document.write'],0,0,'Matn sifatida qo\'yish.'],
  ['CSP nima qiladi?', ['Qaysi manbalardan skript ishlashiga ruxsat berishni cheklaydi','Parolni hashlaydi','Rasm siqadi','Jadval yaratadi'],0,0,'Qo\'shimcha himoya.'],
  ['Token httpOnly cookie\'da bo\'lsa XSS orqali nima o\'zgaradi?', ['JS uni o\'qiy olmaydi, o\'g\'irlash qiyinlashadi','Hech narsa','Token ochiladi','Xavfi oshadi'],0,1,'Lekin XSS o\'zi baribir xavfli.']]],
['Xavfsiz dizayn va noto\'g\'ri sozlamalar', `Xavfsizlik dizayn bosqichidan boshlanadi. Xavflarni modellashtiring ("Bu funksiyani qanday suiiste'mol qilish mumkin?"). Noto'g'ri sozlamalar (Security Misconfiguration) — juda ko'p uchraydigan muammo:
- Standart parol va akkauntlarni o'zgartirmaslik
- Productionda debug rejimi va batafsil xato xabarlari
- Keraksiz portlar, xizmatlar va papkalar ochiq
- Bulut xotirasi (bucket) hammaga ochiq
- Xavfsizlik sarlavhalari yo'q

Yechim: qattiqlashtirilgan (hardened) takrorlanadigan sozlama, keraksizni o'chirish, muntazam tekshiruv.`,
 [['Productionda debug rejimini yoqib qo\'yish nega xavfli?', ['Ichki ma\'lumotni sizdiradi','Tezlashtiradi','Xavfsiz','Hech qanday'],0,0,'Batafsil xatolar hujumchiga yordam beradi.'],
  ['Standart admin parolini o\'zgartirmaslik qaysi toifaga kiradi?', ['Noto\'g\'ri sozlama','Xotira xatosi','Tarmoq tezligi','Dizayn'],0,0,'Security Misconfiguration.'],
  ['Threat modeling nima?', ['Tizimga qanday hujum qilinishi mumkinligini oldindan tahlil qilish','Kod yozish','Dizayn chizish','Test'],0,1,'Proaktiv yondashuv.']]],
['Eskirgan komponentlar va autentifikatsiya xatolari', `Eskirgan kutubxona — ma'lum zaiflikka ega bo'lishi mumkin. Himoya: bog'liqliklar ro'yxatini yuritish, npm audit kabi vositalar bilan tekshirish, yangilab turish, keraksiz paketlarni olib tashlash.

Autentifikatsiya xatolari: zaif parollarga ruxsat, brute-force'dan himoyasizlik, uzoq muddatli sessiya, parolni tiklash havolasi taxmin qilinadigan bo'lishi. Yechim: parol siyosati, rate limiting, ikki bosqichli autentifikatsiya (2FA), tasodifiy va qisqa muddatli tiklash tokenlari, logout'da sessiyani bekor qilish.`,
 [['Bog\'liqliklardagi zaifliklarni tekshirish buyrug\'i?', ['npm audit','npm start','npm init','npm pack'],0,0,'audit.'],
  ['2FA nima?', ['Ikkinchi tasdiqlash bosqichi','Ikkita parol yozish','Ikki marta kirish','Faqat SMS'],0,0,'Qo\'shimcha omil.'],
  ['Parolni tiklash tokeni qanday bo\'lishi kerak?', ['Tasodifiy, taxmin qilib bo\'lmaydigan, qisqa muddatli','Foydalanuvchi id\'si','Ketma-ket raqam','Doimiy'],0,1,'Taxmin qilinadigan token xavfli.']]],
['Logging, monitoring va SSRF', `Hujumni kuzatmasangiz, uni sezmaysiz. Muhim hodisalarni (login muvaffaqiyatsizligi, ruxsat rad etilishi) loglang, lekin parol va tokenni loglamang. Anomaliyalar uchun alert o'rnating.

SSRF (Server-Side Request Forgery) — server foydalanuvchi bergan URL'ga so'rov yuborganda, hujumchi uni ichki tarmoqqa (masalan, cloud metadata) yo'naltirishi.

~~~
// Himoya: ruxsat etilgan domenlar ro'yxati
const ALLOWED = ['api.example.com'];
const host = new URL(userUrl).hostname;
if (!ALLOWED.includes(host)) throw new Error('Taqiqlangan manzil');
~~~`,
 [['Loglarga nima yozilmasligi kerak?', ['Parol va tokenlar','Login urinishlari','Xato kodlari','Vaqt'],0,0,'Maxfiy ma\'lumot.'],
  ['SSRF\'ni qisqacha tushuntiring.', ['Server hujumchi tanlagan manzilga so\'rov yuboradi','Brauzer virusi','Parol almashtirish','Kesh xatosi'],0,0,'Server vosita bo\'lib qoladi.'],
  ['SSRF\'dan himoyada qaysi usul eng ishonchli?', ['Ruxsat etilgan manzillar ro\'yxati (allowlist)','Qora ro\'yxat','Hech narsa','Matnni kichik harfga o\'tkazish'],0,1,'Allowlist.']]],
], practical: ['Amaliy ish: Ilovani xavfsizlik auditi', `O'z loyihangiz yoki ruxsat berilgan namunaviy ilova uchun checklist bo'yicha audit qiling:
1) Barcha endpointlarda egalik/rol tekshiruvi bormi?
2) Barcha DB so'rovlari parametrlimi?
3) Foydalanuvchi matni qayerda sahifaga qo'yiladi (textContent/escape)?
4) npm audit natijasi, helmet, rate limit, HTTPS.
5) Topilgan 5 ta muammoni jiddiyligi bo'yicha tartiblab, tuzatish rejasini yozing.
Tayyor bo'lgach savollarga javob bering.`,
 [['Audit natijasida zaifliklarni qanday tartiblash to\'g\'ri?', ['Ta\'siri va ekspluatatsiya osonligi bo\'yicha','Alfavit bo\'yicha','Tasodifiy','Kod hajmi bo\'yicha'],0,1,'Risk ustuvorligi.'],
  ['/users/:id endpoint\'i parolsiz hamma ma\'lumotni qaytaryapti. Bu qaysi toifa?', ['Broken Access Control','XSS','Eskirgan kutubxona','SSRF'],0,1,'Ruxsat tekshiruvi yo\'q.'],
  ['Tuzatishdan keyin nima qilinadi?', ['Qayta tekshirish (retest) va regressiya testi','Hech narsa','Hisobotni o\'chirish','Faqat e\'lon'],0,1,'Tuzatish ishlaganini tasdiqlash.']] ] },

'Tarmoq xavfsizligi asoslari': { lessons: [
['Tarmoq asoslari: IP, port, DNS', `Tarmoqdagi har bir qurilmaning IP manzili bor (IPv4: 192.168.1.10). Port — qurilmadagi xizmatning "eshigi": 80 (HTTP), 443 (HTTPS), 22 (SSH), 53 (DNS). DNS domen nomini (example.com) IP manzilga aylantiradi.

Ma'lumot paketlar ko'rinishida yuboriladi. Lokal tarmoqda IP'lar odatda shaxsiy diapazonlardan (192.168.x.x, 10.x.x.x) beriladi; internetga NAT orqali chiqiladi.`,
 [['HTTPS standart porti?', ['443','80','22','25'],0,0,'443.'],
  ['DNS vazifasi?', ['Domen nomini IP manzilga aylantirish','Fayl yuborish','Parol saqlash','Antivirus'],0,0,'Nomlar tizimi.'],
  ['192.168.1.10 qanday manzil?', ['Shaxsiy (lokal) IP','Global IP','Domen','MAC'],0,1,'Shaxsiy diapazon.']]],
['OSI va TCP/IP modeli', `OSI modeli tarmoq vazifalarini 7 qatlamga ajratadi: Fizik, Kanal, Tarmoq (IP), Transport (TCP/UDP), Sessiya, Taqdimot, Ilova (HTTP, DNS).

TCP — ishonchli: aloqa o'rnatadi (3-bosqichli qo'l siqish), paketlar yetkazilishini va tartibini ta'minlaydi (veb, email). UDP — tez, lekin kafolatsiz (video qo'ng'iroq, o'yinlar). Modelni bilish muammoni qaysi qatlamda izlashni tushunishga yordam beradi: kabel uzilganmi (fizik), IP noto'g'rimi (tarmoq), port yopiqmi (transport).`,
 [['TCP va UDP\'dan qaysi biri ishonchli yetkazishni kafolatlaydi?', ['TCP','UDP','Ikkalasi','Hech biri'],0,0,'TCP.'],
  ['IP manzillar qaysi qatlamda ishlaydi?', ['Tarmoq','Fizik','Ilova','Sessiya'],0,0,'Tarmoq qatlami.'],
  ['Video qo\'ng\'iroqda odatda nega UDP afzal?', ['Tezlik muhim, ba\'zi paket yo\'qolishi kechiktirishdan yaxshiroq','U xavfsizroq','U arzon','Farqi yo\'q'],0,1,'Real vaqt.']]],
['Xavf turlari: hujum va zararli dastur', `Asosiy tahdidlar: zararli dastur (virus, troyan, ransomware — fayllarni shifrlab to'lov talab qiladi), fishing (soxta xat/sayt orqali ma'lumot olish), DoS/DDoS (xizmatni ortiqcha so'rov bilan to'xtatish), Man-in-the-Middle (aloqani oraliqda tinglash), ijtimoiy muhandislik (odamni aldash).

Eng ko'p muvaffaqiyatli hujumlar insonga qaratilgan. Himoya: ishonchsiz havolani bosmaslik, ilovalarni yangilab turish, ishonchli manbadan yuklash, zaxira nusxa.`,
 [['Fishing nima?', ['Soxta xat/sayt orqali ma\'lumotni aldab olish','Tarmoq kabeli','Antivirus','Parol menejeri'],0,0,'Aldov.'],
  ['Ransomware nima qiladi?', ['Fayllarni shifrlab to\'lov talab qiladi','Tezlashtiradi','Rasm qo\'shadi','Hech narsa'],0,0,'To\'lov talab qilish.'],
  ['Ransomware\'dan eng samarali himoya choralaridan biri?', ['Muntazam zaxira nusxa (tarmoqdan alohida)','Hech narsa','Antivirusni o\'chirish','Havolalarni bosish'],0,1,'Zaxira tiklash imkonini beradi.']]],
['Parollar va autentifikatsiya', `Yaxshi parol: uzun (kamida 12 belgi), noyob (har sayt uchun alohida), taxmin qilinmaydigan. Parol menejeri har sayt uchun kuchli parol yaratadi va saqlaydi — o'zingiz yodlashingiz shart emas. Parol frazalari (bir nechta tasodifiy so'z) uzun va eslab qolish oson.

2FA parol o'g'irlansa ham himoya beradi: ilova (TOTP) yoki apparat kalit (SMS'dan ishonchli). Parollarni qayta ishlatmang: bitta sayt sizib chiqsa, hujumchi boshqalarida sinaydi (credential stuffing).`,
 [['Eng yaxshi amaliyot?', ['Har sayt uchun noyob uzun parol (menejer bilan)','Bitta parol hamma joyda','Ismingiz + yil','123456'],0,0,'Noyoblik.'],
  ['2FA nima uchun foydali?', ['Parol sizsa ham qo\'shimcha to\'siq bo\'ladi','Parolni o\'chiradi','Tezlashtiradi','Foydasi yo\'q'],0,0,'Qo\'shimcha omil.'],
  ['Credential stuffing nima?', ['Sizib chiqqan login/parollarni boshqa saytlarda sinash','Parolni uzaytirish','Yangi akkaunt','SQL buyrug\'i'],0,1,'Parol qayta ishlatilsa xavfli.']]],
['Xavfsizlik devori (firewall) va VPN', `Firewall tarmoq trafigini qoidalar bo'yicha filtrlaydi: ruxsat berilgan portlar/manzillarga o'tkazadi, qolganini to'sadi. Eng yaxshi amaliyot: standart holatda hammasini taqiqlash, faqat zarurini ochish ("default deny").

VPN trafikni shifrlangan tunnel orqali o'tkazadi: ommaviy Wi-Fi'da tinglashdan himoya qiladi va IP manzilni yashiradi. Lekin VPN barcha muammoni hal qilmaydi: u zararli saytdan yoki fishingdan himoya qilmaydi, VPN provayderiga esa ishonish kerak bo'ladi.`,
 [['"Default deny" nimani bildiradi?', ['Hamma narsa taqiqlanadi, faqat zarurisi ochiladi','Hamma narsa ruxsat','Faqat rasm','Hech narsa'],0,0,'Qat\'iy yondashuv.'],
  ['VPN nimani ta\'minlaydi?', ['Trafikni shifrlangan tunnel orqali o\'tkazadi','Kompyuterni tezlashtiradi','Virusni o\'chiradi','Parol yaratadi'],0,0,'Shifrlash.'],
  ['VPN yoqilgan bo\'lsa ham fishing saytiga parol kiritish xavfli bo\'ladimi?', ['Ha, VPN fishingdan himoya qilmaydi','Yo\'q','Faqat kechasi','Hech qachon'],0,1,'VPN ≠ to\'liq xavfsizlik.']]],
['Wi-Fi va HTTPS xavfsizligi', `Uy Wi-Fi: WPA2/WPA3 shifrlashni yoqing, kuchli parol qo'ying, router standart admin parolini o'zgartiring, WPS'ni o'chiring, proshivkani yangilang. Ochiq (parolsiz) Wi-Fi'da trafikni boshqalar tinglashi mumkin — u yerda muhim kirishlarni qilmang yoki VPN ishlating.

HTTPS: brauzer qulf belgisi va to'g'ri domen. Sertifikat haqida ogohlantirish chiqsa — davom etmang. HTTP saytlarda parol kiritmang.`,
 [['Hozirgi tavsiya etiladigan Wi-Fi shifrlash?', ['WPA2/WPA3','WEP','Ochiq','Shifrsiz'],0,0,'WEP eskirgan.'],
  ['Router standart admin parolini nega o\'zgartirish kerak?', ['Standart parollar hammaga ma\'lum','Tezlashadi','Majburiy emas','Dizayn'],0,0,'Hujum osonlashadi.'],
  ['Brauzer sertifikat xatosi haqida ogohlantirsa nima qilinadi?', ['Davom etmaslik va sababini aniqlash','Rozi bo\'lib davom etish','Parol kiritish','Ogohlantirishni o\'chirish'],0,1,'MITM belgisi bo\'lishi mumkin.']]],
['Monitoring va hodisaga javob', `Himoyalanish uchun nimani himoya qilayotganingizni biling. Tarmoq trafigi va loglarni kuzatish g'ayritabiiy faollikni ochib beradi: ko'p muvaffaqiyatsiz login, noodatiy vaqtdagi trafik, ommaviy chiquvchi ulanish.

Hodisaga javob bosqichlari: tayyorgarlik → aniqlash → cheklash (zararlangan qurilmani tarmoqdan uzish) → yo'q qilish → tiklash → xulosa chiqarish. Rejani oldindan yozib qo'ying: kim kimga xabar beradi, zaxira qayerda. Panika bilan harakat qilsangiz, dalillar yo'qolishi mumkin.`,
 [['Zararlangan qurilma aniqlansa birinchi navbatda?', ['Tarmoqdan uzib cheklash','Qayta yoqish','Hech narsa','Ma\'lumotni o\'chirish'],0,0,'Tarqalishni to\'xtatish.'],
  ['Hodisadan keyingi "xulosa" bosqichi nima uchun?', ['Kelajakda takrorlanmasligi uchun o\'rganish','Jazolash','Ahamiyatsiz','Reklama'],0,0,'Darslar olish.'],
  ['Hodisaga javob rejasi nima uchun oldindan yoziladi?', ['Favqulodda vaziyatda tez va tartibli harakat qilish uchun','Qog\'oz to\'ldirish','Majburiy emas','Chiroy'],0,1,'Panikasiz harakat.']]],
], practical: ['Amaliy ish: Uy/ofis tarmog\'i himoya rejasi', `Kichik ofis tarmog'i uchun himoya rejasi tuzing:
1) Qurilmalar ro'yxati (kompyuter, telefon, router, printer) va ular xavfi.
2) Router sozlamalari: WPA3/WPA2, admin parol, WPS, proshivka.
3) Firewall qoidalari (default deny), ochiq portlar ro'yxati.
4) Hodimlar uchun parol/2FA siyosati va fishing bo'yicha qisqa yo'riqnoma.
5) Zaxira va hodisaga javob rejasi.
Tayyor bo'lgach savollarga javob bering.`,
 [['Mehmonlar uchun Wi-Fi nima uchun ish tarmog\'idan alohida bo\'lishi kerak?', ['Mehmon qurilmalari ish resurslariga kira olmasligi uchun','Chiroy','Tezlik','Majburiy emas'],0,1,'Tarmoqni segmentlash.'],
  ['Zaxira nusxa qoidasi (3-2-1)?', ['3 nusxa, 2 xil muhit, 1 tasi tashqarida','1 nusxa','2 nusxa bir joyda','3 nusxa bir diskda'],0,1,'Ishonchli zaxira.'],
  ['Hodim shubhali xat olsa nima qiladi?', ['Havolani bosmay, mas\'ulga xabar beradi','Bosib ko\'radi','Do\'stlarga yuboradi','E\'tibor bermaydi'],0,1,'Hisobot berish madaniyati.']] ] },
};
