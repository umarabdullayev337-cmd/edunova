// Ball (XP) va 6 ta rank. XP almazdan alohida: almaz sarflansa ham rank tushmaydi.
const RANKS = [
  { level: 1, name: 'Yangi', icon: '🌱', min: 0 },
  { level: 2, name: 'Shogird', icon: '📘', min: 150 },
  { level: 3, name: 'Tajribali', icon: '⚡', min: 500 },
  { level: 4, name: 'Usta', icon: '🔥', min: 1200 },
  { level: 5, name: 'Ekspert', icon: '💎', min: 2500 },
  { level: 6, name: 'Afsona', icon: '👑', min: 4500 },
];
// To'g'ri javob uchun ball = savol mukofoti (10/15). Qo'shimcha ballar:
const XP = { lessonDone: 20, perfectBonus: 10, practicalDone: 100, courseDone: 50 };

function rankOf(xp = 0) {
  let r = RANKS[0];
  for (const x of RANKS) if (xp >= x.min) r = x;
  const next = RANKS[r.level] || null;
  return { level: r.level, name: r.name, icon: r.icon, min: r.min, next: next ? { name: next.name, min: next.min } : null };
}
module.exports = { RANKS, XP, rankOf };
