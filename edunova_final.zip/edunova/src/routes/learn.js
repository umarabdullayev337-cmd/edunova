const express = require('express');
const db = require('../db');
const { authenticate } = require('../middleware/auth');
const { wrap, courseView } = require('../utils/helpers');
const L = require('../lessons');
const { REWARD } = require('../shop');
const { XP, rankOf } = require('../rank');

const router = express.Router();
router.use(authenticate);

function load(req, res) {
  const course = db.findCourse(req.params.courseId);
  if (!course) { res.status(404).json({ error: 'Kurs topilmadi' }); return null; }
  const content = L.getContent(course);
  if (!content) { res.status(404).json({ error: "Bu kursda hali darslar yo'q", code: 'NO_LESSONS' }); return null; }
  const enrollment = db.findEnrollment(req.user.id, course.id);
  if (!enrollment) { res.status(403).json({ error: 'Darslarni ko\'rish uchun avval kursga yoziling', code: 'NOT_ENROLLED' }); return null; }
  return { course, content, enrollment, prog: L.getProgress(req.user.id, course.id) };
}

// Dars ochiqmi? (oldingi dars bajarilgan bo'lishi kerak; yakunlangan kursda hammasi ochiq)
function unlocked(ctx, key) {
  if (ctx.enrollment.completed) return true;
  const { content, prog } = ctx;
  if (key === 'p') return content.lessons.every((l, i) => L.lessonDone(prog, i, l.qs));
  const n = Number(key);
  return n === 0 || L.lessonDone(prog, n - 1, content.lessons[n - 1].qs);
}

function parseKey(ctx, raw) {
  if (raw === 'p') return ctx.content.practical ? { key: 'p', item: ctx.content.practical } : null;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 0 || n >= ctx.content.lessons.length) return null;
  return { key: n, item: ctx.content.lessons[n] };
}

const earnedIn = (prog, key, qs) => qs.reduce((s, q, i) => s + (prog?.answers[`${key}:${i}`]?.ok ? L.rewardOf(q) : 0), 0);

router.get('/:courseId', wrap(async (req, res) => {
  const ctx = load(req, res); if (!ctx) return;
  const { content, prog, enrollment } = ctx;
  const lessons = content.lessons.map((l, i) => ({
    n: i, title: l.title, total: l.qs.length, answered: L.answeredCount(prog, i, l.qs),
    done: L.lessonDone(prog, i, l.qs), locked: !unlocked(ctx, i), earned: earnedIn(prog, i, l.qs),
  }));
  const pr = content.practical;
  res.json({
    course: courseView(ctx.course),
    lessons,
    practical: pr ? {
      title: pr.title, total: pr.qs.length, answered: L.answeredCount(prog, 'p', pr.qs),
      done: L.lessonDone(prog, 'p', pr.qs), locked: !unlocked(ctx, 'p'), earned: earnedIn(prog, 'p', pr.qs),
    } : null,
    completed: enrollment.completed,
    progress: L.progressPercent(req.user.id, ctx.course, enrollment),
    diamonds: req.user.diamonds || 0,
  });
}));

router.get('/:courseId/lessons/:n', wrap(async (req, res) => {
  const ctx = load(req, res); if (!ctx) return;
  const t = parseKey(ctx, req.params.n);
  if (!t) return res.status(404).json({ error: 'Dars topilmadi' });
  if (!unlocked(ctx, t.key)) return res.status(403).json({ error: 'Avval oldingi darsning uy ishini bajaring', code: 'LOCKED' });
  const { prog } = ctx;
  const questions = t.item.qs.map((q, i) => {
    const a = prog?.answers[`${t.key}:${i}`];
    const base = { i, q: q.q, options: q.o, hard: q.h, reward: L.rewardOf(q) };
    // To'g'ri javob faqat javob berilgandan keyin ochiladi
    return a ? { ...base, answered: true, choice: a.c, correct: a.ok, answer: q.a, explain: q.e } : base;
  });
  const total = ctx.content.lessons.length;
  res.json({
    lesson: { n: t.key, isPractical: t.key === 'p', title: t.item.title, text: t.item.slides ? '' : t.item.text, slides: t.item.slides || null, questions },
    nav: { prev: t.key === 'p' ? total - 1 : (t.key > 0 ? t.key - 1 : null), next: t.key === 'p' ? null : (t.key + 1 < total ? t.key + 1 : (ctx.content.practical ? 'p' : null)), total },
    done: L.lessonDone(prog, t.key, t.item.qs),
    diamonds: req.user.diamonds || 0,
  });
}));

router.post('/:courseId/lessons/:n/answer', wrap(async (req, res) => {
  const ctx = load(req, res); if (!ctx) return;
  const t = parseKey(ctx, req.params.n);
  if (!t) return res.status(404).json({ error: 'Dars topilmadi' });
  if (!unlocked(ctx, t.key)) return res.status(403).json({ error: 'Bu dars hali yopiq', code: 'LOCKED' });
  const qi = Number(req.body?.q), choice = Number(req.body?.choice);
  const q = t.item.qs[qi];
  if (!Number.isInteger(qi) || !q) return res.status(400).json({ error: "Savol topilmadi" });
  if (!Number.isInteger(choice) || choice < 0 || choice >= q.o.length) return res.status(400).json({ error: "Variant noto'g'ri" });

  const prog = L.getProgress(req.user.id, ctx.course.id, true);
  const k = `${t.key}:${qi}`;
  if (prog.answers[k]) return res.status(409).json({ error: 'Bu savolga allaqachon javob bergansiz' });

  const rankBefore = rankOf(req.user.xp || 0);
  const ok = choice === q.a;
  prog.answers[k] = { c: choice, ok, at: Date.now() };
  let gained = 0;
  if (ok) { gained = L.rewardOf(q); req.user.diamonds = (req.user.diamonds || 0) + gained; }

  const done = L.lessonDone(prog, t.key, t.item.qs);
  let bonus = 0, courseCompleted = false;
  if (done && t.key === 'p') {
    const passed = L.correctCount(prog, 'p', t.item.qs) * 2 >= t.item.qs.length;
    if (!ctx.enrollment.completed) {
      ctx.enrollment.completed = true; ctx.enrollment.completedAt = Date.now(); courseCompleted = true;
      if (passed) { bonus = REWARD.practicalBonus; req.user.diamonds += bonus; }
    }
  }
  // Amaliy ishsiz kurs bo'lsa, oxirgi dars tugagach kurs yakunlanadi
  if (done && t.key !== 'p' && !ctx.content.practical && t.key === ctx.content.lessons.length - 1 && !ctx.enrollment.completed) {
    ctx.enrollment.completed = true; ctx.enrollment.completedAt = Date.now(); courseCompleted = true;
  }
  // Ball (XP): to'g'ri javob + dars/amaliy ish/kurs yakunlari uchun
  let xp = ok ? gained : 0;
  if (done) {
    const allOk = L.correctCount(prog, t.key, t.item.qs) === t.item.qs.length;
    if (t.key === 'p') { if (L.correctCount(prog, 'p', t.item.qs) * 2 >= t.item.qs.length) xp += XP.practicalDone; }
    else xp += XP.lessonDone;
    if (allOk) xp += XP.perfectBonus;
  }
  if (courseCompleted) xp += XP.courseDone;
  req.user.xp = (req.user.xp || 0) + xp;
  const rankNow = rankOf(req.user.xp);
  db.save();
  res.json({ correct: ok, answer: q.a, explain: q.e, gained, bonus, done, courseCompleted, diamonds: req.user.diamonds || 0,
    xp, totalXp: req.user.xp, rank: rankNow, rankUp: rankNow.level > rankBefore.level ? rankNow : null });
}));

module.exports = router;
