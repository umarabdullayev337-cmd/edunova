// Mobil kurslar: Flutter, Kotlin
module.exports = {
'Flutter: mobil ilovalar yaratish': { lessons: [
['Flutter va Dart bilan tanishuv', `Flutter — Google'ning bitta kod bazasidan Android, iOS, veb va desktop ilovalar yaratish freymvorki. U Dart tilidan foydalanadi. Flutter'da hamma narsa widget: tugma, matn, hatto hizalash ham.

~~~
void main() {
  var ism = 'Ali';      // tur avtomatik
  final yosh = 20;      // bir marta tayinlanadi
  const pi = 3.14;      // kompilyatsiya vaqtida o'zgarmas
  print('Salom, $ism');
}
~~~

Dart statik turli til, null safety bilan: String? — null bo'lishi mumkin, String — bo'lmaydi.`,
 [['Flutter qaysi tilda yoziladi?', ['Dart','Java','Swift','PHP'],0,0,'Dart.'],
  ['Flutter\'da interfeys nimalardan quriladi?', ['Widget\'lardan','Faqat XML','Faqat HTML','Jadval'],0,0,'Everything is a widget.'],
  ['Dart\'da String? turi nimani bildiradi?', ['String yoki null bo\'lishi mumkin','Faqat bo\'sh satr','Xato','Raqam'],0,1,'Null safety.']]],
['Widget daraxti va asosiy widgetlar', `Interfeys widget daraxti ko'rinishida quriladi.

~~~
Scaffold(
  appBar: AppBar(title: Text('Bosh sahifa')),
  body: Column(
    children: [
      Text('Salom'),
      ElevatedButton(onPressed: () {}, child: Text('Bos')),
    ],
  ),
)
~~~

Column — vertikal, Row — gorizontal joylashtiradi. Container — o'lcham, rang, chegara. Padding, Center, SizedBox — bo'shliq va hizalash. Scaffold — ekranning asosiy tuzilmasi.`,
 [['Elementlarni vertikal joylashtiruvchi widget?', ['Column','Row','Stack faqat','Center'],0,0,'Column.'],
  ['Ekranning asosiy tuzilmasi (appBar + body) uchun widget?', ['Scaffold','Container','Text','Padding'],0,0,'Scaffold.'],
  ['Elementlarni bir-birining ustiga qo\'yish uchun?', ['Stack','Column','Row','ListView'],0,1,'Stack.']]],
['StatelessWidget va StatefulWidget', `StatelessWidget — o'zgarmaydigan holat; StatefulWidget — o'zgaradigan holat (hisoblagich, forma). Holat o'zgarganda setState() chaqirilib, interfeys qayta chiziladi.

~~~
class Hisob extends StatefulWidget {
  @override State<Hisob> createState() => _HisobState();
}
class _HisobState extends State<Hisob> {
  int son = 0;
  @override
  Widget build(BuildContext context) => ElevatedButton(
    onPressed: () => setState(() => son++),
    child: Text('Bosildi: $son'),
  );
}
~~~

setState'siz o'zgaruvchini o'zgartirsangiz, ekran yangilanmaydi.`,
 [['Holat o\'zgarganda ekranni yangilash uchun nima chaqiriladi?', ['setState()','refresh()','update()','redraw()'],0,0,'setState.'],
  ['O\'zgarmaydigan interfeys uchun qaysi widget?', ['StatelessWidget','StatefulWidget','State','Provider'],0,0,'Stateless.'],
  ['setState chaqirilmasdan son++ qilinsa nima bo\'ladi?', ['Qiymat o\'zgaradi, lekin ekran yangilanmaydi','Ekran yangilanadi','Xato','Ilova yopiladi'],0,1,'Qayta chizish ishga tushmaydi.']]],
['Ro\'yxatlar va navigatsiya', `Uzun ro'yxat uchun ListView.builder — faqat ko'rinib turgan elementlarni yaratadi (samarali).

~~~
ListView.builder(
  itemCount: kurslar.length,
  itemBuilder: (context, i) => ListTile(
    title: Text(kurslar[i]),
    onTap: () => Navigator.push(context,
      MaterialPageRoute(builder: (_) => Tafsilot(kurslar[i]))),
  ),
)
~~~

Navigator.push yangi ekranni ochadi, Navigator.pop ortga qaytaradi. Katta ilovalarda nomlangan yo'llar yoki go_router kutubxonasi qulay.`,
 [['Uzun ro\'yxat uchun eng samarali widget?', ['ListView.builder','Column ichida 1000 ta widget','Row','Stack'],0,0,'Lazy yaratadi.'],
  ['Yangi ekranni ochish?', ['Navigator.push','Navigator.pop','setState','runApp'],0,0,'push.'],
  ['Nega ListView.builder Column\'dan yaxshi (uzun ro\'yxatda)?', ['Faqat ko\'rinadigan elementlarni yaratadi — xotira va tezlik','Chiroyliroq','Qisqaroq kod','Hech nima'],0,1,'Lazy rendering.']]],
['Forma va validatsiya', `Form widgeti maydonlarni birgalikda tekshirish imkonini beradi.

~~~
final _key = GlobalKey<FormState>();
Form(
  key: _key,
  child: Column(children: [
    TextFormField(
      validator: (v) => (v == null || !v.contains('@')) ? 'Email noto\\'g\\'ri' : null,
    ),
    ElevatedButton(
      onPressed: () { if (_key.currentState!.validate()) { /* yuborish */ } },
      child: Text('Yuborish'),
    ),
  ]),
)
~~~

validator xato matnini yoki null (to'g'ri) qaytaradi. TextEditingController maydon qiymatini o'qishga yordam beradi; uni dispose() da tozalang.`,
 [['Validator to\'g\'ri qiymatda nima qaytaradi?', ['null','true','"ok"','0'],0,0,'null — xato yo\'q.'],
  ['Formani tekshirish uchun?', ['_key.currentState!.validate()','form.check()','setState','Navigator'],0,0,'validate().'],
  ['TextEditingController nega dispose() qilinadi?', ['Xotira oqishining oldini olish uchun','Chiroy uchun','Majburiy emas','Rang uchun'],0,1,'Resurslarni bo\'shatish.']]],
['HTTP so\'rovlar va async', `Server bilan ishlash uchun http paketi va async/await ishlatiladi.

~~~
import 'dart:convert';
import 'package:http/http.dart' as http;

Future<List<dynamic>> kurslar() async {
  final r = await http.get(Uri.parse('https://api.example.com/courses'));
  if (r.statusCode != 200) throw Exception('Xato: \${r.statusCode}');
  return jsonDecode(r.body);
}
~~~

Future — kelajakda keladigan natija. UI'da FutureBuilder yuklanmoqda, xato va tayyor holatlarini ko'rsatadi. pubspec.yaml'ga paket qo'shishni unutmang.`,
 [['Kelajakda keladigan natija Dart\'da qanday tur?', ['Future','Stream faqat','Widget','State'],0,0,'Future.'],
  ['JSON matnni ob\'ektga aylantirish?', ['jsonDecode','jsonSend','parseHtml','toJson faqat'],0,0,'jsonDecode.'],
  ['FutureBuilder nima qiladi?', ['Future holatiga qarab (yuklanmoqda/xato/tayyor) UI chizadi','Server yaratadi','Rasm yuklaydi','Animatsiya'],0,1,'Asinxron UI.']]],
['Holatni boshqarish: Provider', `Ko'p ekranlar bir xil ma'lumotni ishlatsa, setState yetarli emas. Provider holatni daraxt yuqorisida saqlaydi va kerakli joyda o'qiydi.

~~~
class Savat extends ChangeNotifier {
  final List<String> _items = [];
  List<String> get items => List.unmodifiable(_items);
  void qosh(String x) { _items.add(x); notifyListeners(); }
}
// o'qish:
final savat = context.watch<Savat>();
~~~

notifyListeners() tinglovchi widgetlarni qayta chizadi. context.watch o'zgarishni kuzatadi, context.read esa faqat bir marta o'qiydi (tugma bosilganda). Boshqa yechimlar: Riverpod, Bloc.`,
 [['Provider\'da tinglovchilarga xabar berish?', ['notifyListeners()','setState()','emit()','update()'],0,0,'notifyListeners.'],
  ['Hodisa handler\'ida (tugma bosilganda) qiymatni o\'qish uchun?', ['context.read','context.watch','setState','Navigator'],0,0,'read — kuzatmaydi.'],
  ['Provider\'ning setState\'dan afzalligi?', ['Holatni ekranlar orasida ulashish oson','Tezroq','Kod qisqa','Farqi yo\'q'],0,1,'Umumiy holat.']]],
['Build va e\'lon qilish', `Chiqarishdan oldin: ilova nomi va ikonka, versiya (pubspec.yaml'dagi version), imzolash kaliti. Android uchun appbundle yig'iladi:

~~~
flutter build appbundle --release
~~~

Google Play Console'ga yuklanadi (bir martalik ro'yxatdan o'tish to'lovi bor). iOS uchun Mac, Xcode va Apple Developer hisobi kerak. Maxfiy kalit (keystore) faylini yo'qotmang va Git'ga qo'shmang. Release rejimida debug ma'lumotlari o'chadi, ilova tezroq ishlaydi. Chiqarishdan oldin haqiqiy qurilmada sinang.`,
 [['Android uchun release build buyrug\'i?', ['flutter build appbundle --release','flutter run','flutter clean','flutter doctor'],0,0,'AAB yig\'iladi.'],
  ['Keystore fayli bilan nima qilinadi?', ['Xavfsiz saqlanadi, Git\'ga qo\'shilmaydi','Ochiq e\'lon qilinadi','O\'chiriladi','Emailga yuboriladi'],0,0,'Yo\'qolsa yangilash chiqarib bo\'lmaydi.'],
  ['iOS uchun nima talab qilinadi?', ['Mac, Xcode va Apple Developer hisobi','Faqat Windows','Hech narsa','Faqat Android Studio'],0,1,'Apple talablari.']]],
], practical: ['Amaliy ish: Vazifalar ilovasi', `Flutter'da Vazifalar ilovasini yarating:
1) Asosiy ekran: ListView.builder bilan vazifalar ro'yxati.
2) Yangi vazifa qo'shish ekrani (Form va validator, bo'sh matnga ruxsat yo'q).
3) Provider (ChangeNotifier) bilan holat boshqaruvi.
4) Vazifani belgilash va o'chirish.
5) Release APK/AAB yig'ib, qurilmada sinang.
Tayyor bo'lgach savollarga javob bering.`,
 [['Vazifalar ro\'yxatini ikki ekran o\'rtasida ulashish uchun nima mos?', ['Provider (umumiy holat)','Global matn','Alohida nusxa','setState faqat'],0,1,'Umumiy holat.'],
  ['Bo\'sh vazifa qo\'shilmasligi uchun?', ['Validatorda bo\'sh matn uchun xato qaytarish','Hech narsa','try/catch','Navigator.pop'],0,1,'validator.'],
  ['Ro\'yxat elementi o\'chirilgach UI yangilanishi uchun?', ['notifyListeners() chaqirish','Ilovani qayta ochish','print()','dispose()'],0,1,'Tinglovchilarni xabardor qilish.']] ] },

'Kotlin bilan Android dasturlash': { lessons: [
['Kotlin asoslari', `Kotlin — Android uchun Google tavsiya qilgan zamonaviy til. Qisqa, xavfsiz va Java bilan mos.

~~~
val ism = "Ali"        // o'zgarmas
var yosh = 20          // o'zgaruvchan
val matn: String? = null   // null bo'lishi mumkin
println("Salom, $ism, \${yosh + 1}")
val uzunlik = matn?.length ?: 0
~~~

val — bir marta tayinlanadi, var — o'zgaradi. Null safety: ? bilan null bo'lishi mumkin turlar belgilanadi, ?. xavfsiz chaqiruv, ?: (Elvis) standart qiymat beradi. Bu NullPointerException xatolarining katta qismini yo'qotadi.`,
 [['O\'zgarmas o\'zgaruvchi kalit so\'zi?', ['val','var','const var','let'],0,0,'val.'],
  ['"?:" operatori nima?', ['Elvis: null bo\'lsa standart qiymat','Taqqoslash','Tarmoqlanish','Izoh'],0,0,'Standart qiymat.'],
  ['matn?.length matn null bo\'lsa nima beradi?', ['null','Xato (crash)','0','""'],0,1,'Xavfsiz chaqiruv null qaytaradi.']]],
['Funksiyalar, sinflar va data class', `~~~
fun qosh(a: Int, b: Int = 0): Int = a + b

data class Kurs(val id: Int, val nom: String, val narx: Int)

class Hisob {
    private var son = 0
    fun oshir() { son++ }
    fun qiymat() = son
}
val k = Kurs(1, "Kotlin", 500000)
val k2 = k.copy(narx = 450000)
~~~

data class avtomatik toString, equals, copy yaratadi — ma'lumot saqlash uchun ideal. Standart parametrlar va nomlangan argumentlar kodni qisqa qiladi.`,
 [['Ma\'lumot saqlovchi sinf uchun qulay kalit so\'z?', ['data class','class data','record','struct'],0,0,'data class.'],
  ['k.copy(narx = 450000) nima qiladi?', ['k\'ni o\'zgartiradi','Narxi boshqa yangi nusxa yaratadi','Xato','O\'chiradi'],1,0,'Nusxa, asl o\'zgarmaydi.'],
  ['Funksiya parametriga standart qiymat berishning foydasi?', ['Argument berilmasa ham chaqirish mumkin','Tezroq','Xavfsizroq','Hech'],0,1,'Ixtiyoriy parametr.']]],
['Kolleksiyalar va lambda', `~~~
val sonlar = listOf(1, 2, 3, 4, 5)
val juft = sonlar.filter { it % 2 == 0 }
val kvadrat = sonlar.map { it * it }
val jami = sonlar.sum()
val ism = sonlar.firstOrNull { it > 3 }
~~~

listOf — o'zgarmas ro'yxat, mutableListOf — o'zgaruvchan. Lambda { it ... } — qisqa funksiya; it bitta parametr uchun standart nom. filter, map, any, all, groupBy kabi funksiyalar kodni ixcham qiladi. when ifodasi switch o'rniga ishlatiladi.`,
 [['O\'zgaruvchan ro\'yxat yaratish?', ['mutableListOf','listOf','arrayOfNull','varList'],0,0,'mutableListOf.'],
  ['listOf(1,2,3).map { it * 2 } natijasi?', ['[2, 4, 6]','[1, 2, 3]','6','[3, 4, 5]'],0,0,'Har biri ikki barobar.'],
  ['"it" nima?', ['Lambdaning yagona parametri uchun standart nom','Kalit so\'z — sinf','Operator','Izoh'],0,1,'Implicit parameter.']]],
['Android loyihasi: Activity va hayotiy sikl', `Activity — foydalanuvchiga ekran ko'rsatadigan komponent. Hayotiy sikl metodlari: onCreate (yaratilganda — interfeysni sozlash), onStart, onResume (ko'rinadigan va faol), onPause, onStop, onDestroy.

~~~
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
~~~

Ekranni burganda Activity qayta yaratiladi, shuning uchun holatni yo'qotmaslik uchun ViewModel yoki savedInstanceState ishlating. AndroidManifest.xml ilova komponentlari va ruxsatlarni e'lon qiladi.`,
 [['Interfeys odatda qaysi metodda sozlanadi?', ['onCreate','onDestroy','onPause','onStop'],0,0,'onCreate.'],
  ['Ilova ruxsatlari qaysi faylda e\'lon qilinadi?', ['AndroidManifest.xml','build.gradle faqat','strings.xml','MainActivity.kt faqat'],0,0,'Manifest.'],
  ['Ekran burilganda Activity ma\'lumotini saqlab qolish uchun?', ['ViewModel','Hech narsa','Global var','Toast'],0,1,'ViewModel konfiguratsiya o\'zgarishida saqlanadi.']]],
['Interfeys: Jetpack Compose', `Jetpack Compose — deklarativ interfeys vositasi: UI holatning funksiyasi.

~~~
@Composable
fun Hisob() {
    var son by remember { mutableStateOf(0) }
    Column {
        Text("Bosildi: $son")
        Button(onClick = { son++ }) { Text("Bos") }
    }
}
~~~

@Composable funksiyalar interfeysni tasvirlaydi. mutableStateOf holat yaratadi, o'zgarsa interfeys qayta chiziladi (recomposition). remember qiymatni qayta chizilishlar orasida saqlaydi. Modifier o'lcham, bo'shliq, rang beradi. Ro'yxat uchun LazyColumn.`,
 [['Compose\'da funksiya interfeys ekanini bildiruvchi annotatsiya?', ['@Composable','@UI','@View','@Screen'],0,0,'@Composable.'],
  ['Holat o\'zgarganda interfeys nima bo\'ladi?', ['Qayta chiziladi (recomposition)','O\'zgarmaydi','Ilova yopiladi','Xato'],0,0,'Avtomatik.'],
  ['remember nima uchun?', ['Qiymatni recomposition\'lar orasida saqlash','Fayl saqlash','Xotirani tozalash','Rang berish'],0,1,'Aks holda har chizilishda qayta tiklanadi.']]],
['Coroutine va tarmoq', `Tarmoq so'rovini asosiy (UI) oqimda bajarish ilovani qotiradi. Coroutine'lar asinxron ishni oddiy kod kabi yozish imkonini beradi.

~~~
viewModelScope.launch {
    val kurslar = withContext(Dispatchers.IO) { api.getCourses() }
    holat.value = kurslar
}
~~~

Dispatchers.IO — tarmoq/fayl uchun, Main — UI uchun. suspend funksiyalar to'xtatilishi mumkin. Retrofit kutubxonasi REST API bilan ishlashni osonlashtiradi. Internet ruxsatini manifestga qo'shing: INTERNET.`,
 [['Tarmoq ishi qaysi dispatcher\'da bajariladi?', ['Dispatchers.IO','Dispatchers.Main','Hech qaysi','UI oqimida'],0,0,'IO.'],
  ['Retrofit nima uchun?', ['REST API bilan ishlash','Rasm chizish','Animatsiya','Ma\'lumotni shifrlash'],0,0,'HTTP klient.'],
  ['Tarmoq so\'rovini UI oqimida bajarish nimaga olib keladi?', ['Ilova qotadi/ANR yoki xato beradi','Tezlashadi','Hech narsa','Xotira tejaydi'],0,1,'UI bloklanadi.']]],
['Ma\'lumotni saqlash: Room va e\'lon qilish', `Room — SQLite ustidagi qulay qatlam: Entity (jadval), Dao (so'rovlar), Database.

~~~
@Entity data class Vazifa(@PrimaryKey(autoGenerate = true) val id: Int = 0, val nom: String)
@Dao interface VazifaDao {
    @Query("SELECT * FROM Vazifa") fun hammasi(): Flow<List<Vazifa>>
    @Insert suspend fun qosh(v: Vazifa)
}
~~~

Flow ma'lumot o'zgarganda UI'ni avtomatik yangilaydi. E'lon qilish: release AAB yig'iladi, imzolanadi va Google Play Console'ga yuklanadi. Kichik sozlamalar uchun DataStore ishlating. Maxfiy kalitlarni kodga yozmang.`,
 [['Room\'da jadval qaysi annotatsiya bilan belgilanadi?', ['@Entity','@Dao','@Query','@Insert'],0,0,'@Entity.'],
  ['Dao nima?', ['Ma\'lumotlar bazasiga murojaat metodlari interfeysi','Jadval','Ekran','Rang'],0,0,'Data Access Object.'],
  ['Room so\'rovida Flow qaytarishning foydasi?', ['Ma\'lumot o\'zgarganda UI avtomatik yangilanadi','Tezroq saqlaydi','Xotira tejaydi','Hech'],0,1,'Reaktiv oqim.']]],
], practical: ['Amaliy ish: Eslatmalar ilovasi', `Kotlin + Compose bilan Eslatmalar ilovasi:
1) Eslatmalar ro'yxati (LazyColumn).
2) Yangi eslatma qo'shish (bo'sh sarlavhaga ruxsat yo'q).
3) Room bilan saqlash, qayta ochganda yo'qolmasin.
4) ViewModel + Flow orqali UI yangilansin.
5) O'chirish va tahrirlash.
Tayyor bo'lgach savollarga javob bering.`,
 [['Ilova yopilib qayta ochilganda eslatmalar saqlanib qolishi uchun?', ['Room (doimiy baza)','Faqat o\'zgaruvchi','remember','Toast'],0,1,'Doimiy saqlash.'],
  ['UI Room o\'zgarishlarini avtomatik ko\'rsatishi uchun?', ['Flow va collectAsState','Qo\'lda refresh','Ilovani qayta yuklash','print'],0,1,'Reaktiv oqim.'],
  ['Baza amallarini qayerda bajarish kerak?', ['Asosiy oqimdan tashqarida (suspend/IO)','UI oqimida','Hech qayerda','Manifestda'],0,1,'UI qotmasligi uchun.']] ] },
};
