const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');

const config = require('./src/config');
const db = require('./src/db');
const { seed } = require('./src/seed');
const sec = require('./src/middleware/security');
const lessons = require('./src/lessons');
const mongo = require('./src/mongo');

db.init();

// Ishga tushirish: (ixtiyoriy) MongoDB'dan o'qish -> seed -> MongoDB'ga yozishni yoqish
async function boot() {
  if (mongo.enabled) {
    await mongo.connect();
    await mongo.loadInto(db.data);
  }
  seed();
  lessons.syncAll();
  lessons.backfillXp();
  if (mongo.enabled) await mongo.attach(db);
}

const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);

// Xavfsizlik middleware'lari
app.use(sec.helmetMw);
app.use(sec.corsMw);
app.use(express.json({ limit: '350kb' })); // profil rasmini yuklash (base64) uchun kattaroq limit
app.use(cookieParser());

// Frontend (statik fayllar)
app.use(express.static(path.join(__dirname, 'public'), { maxAge: config.isProd ? '1h' : 0 }));

// API: umumiy limit + sekinlashtirish (DDoS ga qarshi asosiy himoya)
const guard = [sec.globalLimiter, sec.speedLimiter];
app.use('/auth', guard, require('./src/routes/auth'));
app.use('/profile', guard, require('./src/routes/profile'));
app.use('/courses', guard, require('./src/routes/courses'));
app.use('/learn', guard, require('./src/routes/learn'));
app.use('/ranks', guard, require('./src/routes/ranks'));
app.use('/shop', guard, require('./src/routes/shop'));
app.use('/mentors', guard, require('./src/routes/mentors'));
app.use('/messages', guard, require('./src/routes/messages'));
app.use('/certificates', guard, require('./src/routes/certificates'));
app.use('/admin', guard, require('./src/routes/admin'));

app.get('/health', (req, res) => res.json({ ok: true }));

// 404
app.use((req, res) => {
  if (req.method === 'GET' && req.accepts('html') && !path.extname(req.path)) {
    return res.sendFile(path.join(__dirname, 'public', 'index.html'));
  }
  res.status(404).json({ error: 'Topilmadi' });
});

// Xatolarni ushlash
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err.message && err.message.startsWith('CORS')) return res.status(403).json({ error: err.message, code: 'CORS' });
  if (err.name === 'Error' && err.constructor && err.constructor.name === 'MailError') return res.status(503).json({ error: err.message, code: 'MAIL_FAILED' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: "JSON formati noto'g'ri" });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: "So'rov hajmi juda katta" });
  console.error(err);
  res.status(500).json({ error: 'Serverda ichki xatolik yuz berdi' });
});

boot().then(() => {
  app.listen(config.port, () => {
    console.log(`\n  EduNova ishga tushdi:  http://localhost:${config.port}\n`);
  });
}).catch((e) => { console.error('Ishga tushmadi:', e); process.exit(1); });
