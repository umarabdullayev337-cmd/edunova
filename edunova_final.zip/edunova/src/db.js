// Oddiy, ishonchli JSON-fayl ombori (data/db.json). Node.js bir oqimli bo'lgani uchun
// sinxron yozish poyga holatlarini yuzaga keltirmaydi. Katta loyihada MongoDB/PostgreSQL ga
// almashtirish uchun faqat shu fayl va routes ichidagi db.data chaqiruvlarini o'zgartirish kifoya.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DIR = path.join(__dirname, '..', 'data');
const FILE = path.join(DIR, 'db.json');

const data = { users: [], courses: [], enrollments: [], refreshTokens: [], reviews: [], messages: [], certificates: [], progress: [] };

function save() {
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, FILE);
}

function init() {
  fs.mkdirSync(DIR, { recursive: true });
  if (fs.existsSync(FILE)) {
    try {
      Object.assign(data, JSON.parse(fs.readFileSync(FILE, 'utf8')));
    } catch (e) {
      throw new Error('data/db.json buzilgan: ' + e.message);
    }
  }
  for (const k of ['users', 'courses', 'enrollments', 'refreshTokens', 'reviews', 'messages', 'certificates', 'progress']) data[k] = data[k] || [];
  save();
}

module.exports = {
  data,
  init,
  save,
  id: () => crypto.randomUUID(),
  findUserByEmail: (email) => data.users.find((u) => u.email === email),
  findUser: (id) => data.users.find((u) => u.id === id),
  findCourse: (id) => data.courses.find((c) => c.id === id),
  findMentor: (id) => data.users.find((u) => u.id === id && u.role === 'mentor'),
  findEnrollment: (userId, courseId) => data.enrollments.find((e) => e.userId === userId && e.courseId === courseId),
};
