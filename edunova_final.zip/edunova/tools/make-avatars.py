# Multfilm uslubidagi avatarlarni (SVG) yaratadi: python3 tools/make-avatars.py
import os
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'img', 'avatars')
os.makedirs(OUT, exist_ok=True)

SKIN = {'a': ('#F6D3B3', '#E3B893'), 'b': ('#EBBB90', '#D49E72'), 'c': ('#D9A374', '#BD8558'),
        'd': ('#B9825A', '#9A6742'), 'e': ('#8F5D3E', '#734830')}

def darken(hexc, k=0.78):
    h = hexc.lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    r, g, b = [int(h[i:i+2], 16) for i in (0, 2, 4)]
    return '#%02x%02x%02x' % (int(r*k), int(g*k), int(b*k))

def hair_front(style, c):
    if style == 'short':
        return f'<path d="M55 92C51 46 78 31 100 31C124 31 149 46 145 92C140 74 128 64 100 62C72 64 60 74 55 92Z" fill="{c}"/>'
    if style == 'side':
        return f'<path d="M54 90C49 44 80 29 105 31C131 33 150 52 146 90C139 66 118 58 94 65C75 70 64 76 54 90Z" fill="{c}"/>'
    if style == 'spiky':
        return (f'<path d="M54 90L50 56L69 66L73 38L90 55L100 30L112 55L128 38L131 66L150 56L146 90C140 72 126 63 100 63C74 63 60 72 54 90Z" fill="{c}"/>')
    if style == 'curly':
        cs = ''.join(f'<circle cx="{x}" cy="{y}" r="15" fill="{c}"/>' for x, y in
                     [(62, 66), (76, 48), (96, 42), (116, 44), (134, 52), (142, 70), (56, 84), (146, 88)])
        return cs + f'<path d="M58 84C60 66 76 62 100 62C124 62 140 66 142 84C130 74 116 72 100 72C84 72 70 74 58 84Z" fill="{c}"/>'
    if style == 'bun':
        return (f'<circle cx="100" cy="24" r="15" fill="{c}"/>'
                f'<path d="M54 92C50 46 76 32 100 32C126 32 150 46 146 92C140 68 120 58 96 62C74 64 60 76 54 92Z" fill="{c}"/>')
    if style == 'long':
        return f'<path d="M52 96C46 46 76 30 102 32C130 34 154 50 148 96C142 68 120 56 94 62C72 66 58 78 52 96Z" fill="{c}"/>'
    return ''

def hair_back(style, c):
    if style == 'long':
        return f'<path d="M48 98C40 44 72 28 100 28C128 28 160 44 152 98L158 172C130 188 70 188 42 172Z" fill="{c}"/>'
    return ''

def av(name, bg, skin, hair, style, shirt, kind='shirt', glasses=False, phones=False, doppi=False,
       mouth='smile', beard=None, eyes='dots'):
    s, sd = SKIN[skin]
    hd = darken(hair, .8)
    p = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" role="img" aria-label="{name}">',
         f'<defs><clipPath id="c"><circle cx="100" cy="100" r="100"/></clipPath></defs>',
         f'<g clip-path="url(#c)"><rect width="200" height="200" fill="{bg}"/>',
         f'<circle cx="160" cy="34" r="46" fill="#fff" opacity=".13"/>']
    p.append(hair_back(style, hair))
    sh_d = darken(shirt)
    p.append(f'<path d="M20 205C20 152 60 142 100 142C140 142 180 152 180 205Z" fill="{shirt}"/>')
    if kind == 'hoodie':
        p.append(f'<path d="M60 152C68 130 132 130 140 152C128 162 72 162 60 152Z" fill="{sh_d}"/>')
        p.append('<path d="M91 156v24M109 156v24" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".85"/>')
    elif kind == 'blazer':
        p.append(f'<path d="M83 142L100 190L117 142L100 154Z" fill="{sh_d}"/><path d="M90 142L100 168L110 142Z" fill="#fff"/>')
    else:
        p.append('<path d="M82 142L100 166L118 142Z" fill="#fff"/>')
    p.append(f'<rect x="88" y="116" width="24" height="32" rx="9" fill="{sd}"/>')
    p.append(f'<circle cx="57" cy="98" r="8.5" fill="{s}"/><circle cx="143" cy="98" r="8.5" fill="{s}"/>')
    p.append(f'<ellipse cx="100" cy="94" rx="43" ry="49" fill="{s}"/>')
    if beard == 'full':
        p.append(f'<path d="M58 102C60 140 82 152 100 152C118 152 140 140 142 102C134 122 120 128 100 128C80 128 66 122 58 102Z" fill="{hd}"/>')
    elif beard == 'stubble':
        p.append(f'<path d="M58 102C60 140 82 152 100 152C118 152 140 140 142 102C134 122 120 128 100 128C80 128 66 122 58 102Z" fill="{hair}" opacity=".32"/>')
    p.append(hair_front(style, hair))
    if doppi:
        p.append('<path d="M55 76C55 46 78 34 100 34C122 34 145 46 145 76L145 82C126 87 74 87 55 82Z" fill="#141826"/>'
                 '<path d="M55 80C74 85 126 85 145 80" stroke="#fff" stroke-width="2.2" fill="none" opacity=".9"/>'
                 '<path d="M72 62l6-6 6 6-6 6zM97 54l6-6 6 6-6 6zM122 62l6-6 6 6-6 6z" fill="none" stroke="#fff" stroke-width="1.8"/>')
    p.append('<circle cx="77" cy="110" r="7" fill="#ff8fa3" opacity=".3"/><circle cx="123" cy="110" r="7" fill="#ff8fa3" opacity=".3"/>')
    ec = '#1b1b24'
    if eyes == 'happy':
        p.append(f'<path d="M76 96Q83 88 90 96M110 96Q117 88 124 96" stroke="{ec}" stroke-width="3.4" fill="none" stroke-linecap="round"/>')
    else:
        p.append(f'<ellipse cx="83" cy="94" rx="4.8" ry="5.6" fill="{ec}"/><ellipse cx="117" cy="94" rx="4.8" ry="5.6" fill="{ec}"/>'
                 '<circle cx="85" cy="92" r="1.7" fill="#fff"/><circle cx="119" cy="92" r="1.7" fill="#fff"/>')
    p.append(f'<path d="M73 82Q83 76 93 81M107 81Q117 76 127 82" stroke="{hd}" stroke-width="3.4" fill="none" stroke-linecap="round"/>')
    p.append(f'<path d="M100 99q-4 8 1 11" stroke="{sd}" stroke-width="2.6" fill="none" stroke-linecap="round"/>')
    if mouth == 'grin':
        p.append('<path d="M84 115Q100 137 116 115Z" fill="#8a2f3a"/><path d="M87 116Q100 123 113 116L113 118Q100 125 87 118Z" fill="#fff"/>')
    else:
        p.append('<path d="M86 117Q100 129 114 117" stroke="#7a2e2e" stroke-width="3.4" fill="none" stroke-linecap="round"/>')
    if glasses:
        p.append('<g fill="none" stroke="#20222e" stroke-width="3"><rect x="65" y="82" width="33" height="25" rx="10"/><rect x="102" y="82" width="33" height="25" rx="10"/>'
                 '<path d="M98 92h4M65 90L57 88M135 90L143 88"/></g>')
    if phones:
        p.append('<path d="M53 92C49 30 151 30 147 92" stroke="#2b2f5c" stroke-width="7" fill="none" stroke-linecap="round"/>'
                 '<rect x="42" y="84" width="15" height="32" rx="7.500" fill="#F6D98A"/><rect x="143" y="84" width="15" height="32" rx="7.500" fill="#F6D98A"/>')
    p.append('</g></svg>')
    open(os.path.join(OUT, name + '.svg'), 'w', encoding='utf-8').write(''.join(p))

# --- Asoschi: 18 yoshli multfilm bola ---
av('founder', '#F6D98A', 'b', '#17171f', 'spiky', '#5b5fd6', 'hoodie', phones=True, mouth='grin', eyes='happy')
# --- Mentorlar ---
av('m-jasur', '#C9CDF5', 'c', '#2a1d14', 'short', '#2a3266', 'blazer', beard='stubble')
av('m-dilnoza', '#BFEBDD', 'b', '#1d1417', 'long', '#1f7a55', 'blazer')
av('m-sardor', '#BDE6EC', 'b', '#3a2a1c', 'side', '#15919f', 'shirt', glasses=True)
av('m-madina', '#E5CDF5', 'a', '#4a2a1a', 'bun', '#9a4fc4', 'shirt', glasses=True)
av('m-bekzod', '#F7DDB8', 'c', '#181818', 'curly', '#d0822a', 'shirt', beard='full')
av('m-nigora', '#F7C9D6', 'b', '#2b1a2e', 'long', '#d04a70', 'shirt', mouth='grin')
av('m-otabek', '#D6D9F5', 'b', '#181818', 'short', '#4a4fc4', 'shirt', doppi=True)
av('m-malika', '#CFDBF5', 'a', '#5b3a22', 'long', '#233a66', 'blazer')
av('m-sherzod', '#BFE3D2', 'd', '#111111', 'short', '#0d3d2c', 'hoodie', beard='full')
av('m-aziza', '#F5C9D4', 'b', '#20140f', 'long', '#b33a5b', 'shirt', glasses=True)
av('m-ulugbek', '#C4C8F0', 'c', '#1f1a16', 'side', '#1e2160', 'hoodie', glasses=True)
av('m-kamola', '#E3CBF1', 'a', '#4b2c1c', 'long', '#7a3e9d', 'blazer', mouth='grin')
av('m-rustam', '#CBDAF4', 'b', '#221a14', 'short', '#4a6fb5', 'shirt', glasses=True)
# --- Bitiruvchilar ---
av('a1', '#FBD9A8', 'b', '#1a1a1a', 'short', '#e9b44c', 'hoodie', mouth='grin')
av('a2', '#F7C9D6', 'a', '#3b2416', 'long', '#d04a70', 'shirt')
av('a3', '#C9F0E1', 'c', '#111', 'curly', '#2a9d6c', 'hoodie', eyes='happy')
av('a4', '#D8D9F7', 'b', '#2a1d14', 'side', '#5b5fd6', 'shirt', glasses=True)
av('a5', '#F9DDE2', 'a', '#5b3a22', 'bun', '#b33a5b', 'hoodie', mouth='grin')
av('a6', '#CFE8F5', 'd', '#111', 'short', '#15919f', 'shirt', eyes='happy')
av('a7', '#F5E3B8', 'b', '#181818', 'spiky', '#d0822a', 'hoodie', mouth='grin')
av('a8', '#E9D4F7', 'a', '#2b1a2e', 'long', '#9a4fc4', 'shirt', glasses=True)
av('a9', '#D3F1D9', 'c', '#20140f', 'short', '#0d3d2c', 'blazer')
av('a10', '#FAD3C7', 'b', '#3a2a1c', 'curly', '#e0704a', 'hoodie', eyes='happy', mouth='grin')
print(len(os.listdir(OUT)), 'avatar yaratildi')
