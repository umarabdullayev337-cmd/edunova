// Almaz iqtisodiyoti va do'kon katalogi (hamma narx va mukofotlar shu yerda)
const REWARD = { easy: 10, hard: 15, practicalBonus: 100 };
const COURSE_UNLOCK_PRICE = 3000;
const PREMIUM_AVATAR_PRICE = 2000;

const FRAMES = [
  { key: 'gold', name: 'Oltin halqa', price: 300, desc: 'Yaltirovchi uchqunlar' },
  { key: 'neon', name: 'Neon puls', price: 500, desc: 'Elektr uchqunli neon' },
  { key: 'aurora', name: 'Aurora', price: 900, desc: 'Suzuvchi shimol shafaqi' },
  { key: 'fire', name: 'Olov halqa', price: 1300, desc: "Haqiqiy alanga tillari" },
  { key: 'galaxy', name: 'Galaktika', price: 1800, desc: 'Orbitada aylanuvchi yulduzlar' },
  { key: 'ice', name: 'Muz sovuqligi', price: 700, desc: "Qor parchalari va muz nurlari" },
  { key: 'thunder', name: "Chaqmoq", price: 1000, desc: "Yarqiragan chaqmoqlar" },
  { key: 'royal', name: 'Qirollik toji', price: 2200, desc: 'Yaltirovchi oltin-binafsha' },
];

const PREMIUM_AVATARS = [
  { key: 'phoenix', name: 'Feniks', price: PREMIUM_AVATAR_PRICE, desc: "Olov uchqunlari bilan" },
  { key: 'cyber', name: 'Kiber samuray', price: PREMIUM_AVATAR_PRICE, desc: 'Neon glitch effekti' },
  { key: 'nova', name: 'Nova', price: PREMIUM_AVATAR_PRICE, desc: 'Miltillovchi yulduzlar' },
  { key: 'frost', name: 'Muz malikasi', price: PREMIUM_AVATAR_PRICE, desc: 'Muzdek yaltirash' },
  { key: 'dragon', name: 'Ajdar', price: PREMIUM_AVATAR_PRICE, desc: 'Yashil alanga' },
  { key: 'oracle', name: 'Orakul', price: PREMIUM_AVATAR_PRICE, desc: 'Sirli binafsha nur' },
];

module.exports = { REWARD, COURSE_UNLOCK_PRICE, PREMIUM_AVATAR_PRICE, FRAMES, PREMIUM_AVATARS };
