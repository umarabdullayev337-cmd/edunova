// Til kurslari: IELTS 7+ va IELTS Speaking
module.exports = {
'IELTS 7+ intensiv kursi': { lessons: [
['IELTS tuzilishi va 7+ strategiyasi', `IELTS 4 qismdan iborat: Listening (30 daq, 40 savol), Reading (60 daq, 40 savol), Writing (60 daq, 2 topshiriq), Speaking (11–14 daq, suhbat). Umumiy ball 4 qism o'rtachasi (0.5 ga yaxlitlanadi).

7+ uchun: Reading va Listening'da taxminan 30–32+ to'g'ri javob, Writing va Speaking'da barqaror yuqori ball kerak. Strategiya: har bo'lim mezonlarini bilish, vaqtni boshqarish, o'z zaif tomoningizni topish va muntazam mashq. Ingliz tilini har kuni kamida 1–2 soat ishlating.`,
 [['IELTS nechta bo\'limdan iborat?', ['4','2','3','5'],0,0,'Listening, Reading, Writing, Speaking.'],
  ['Reading bo\'limi necha daqiqa?', ['60','30','90','45'],0,0,'60 daqiqa.'],
  ['Umumiy IELTS bali qanday hisoblanadi?', ['4 bo\'lim ballarining o\'rtachasi','Faqat Speaking','Eng yuqori bo\'lim','Jami yig\'indi'],0,1,'O\'rtacha, 0.5 gacha yaxlitlanadi.']]],
['Listening: strategiya', `Listening'da audio faqat BIR marta eshittiriladi. Savollarni audio boshlanishidan oldin o'qing va kalit so'zlarni belgilang. Javob audioda sinonim bilan berilishi mumkin: savolda "cheap", audioda "inexpensive".

Maslahatlar: yozayotganda imlo va so'z soni talabiga e'tibor bering (NO MORE THAN TWO WORDS). Raqam, sana, ismni to'g'ri yozing. Bir savolda to'xtab qolmang — keyingisiga o'ting. Oxirida 10 daqiqa ichida javoblarni javob varag'iga ko'chirasiz (qog'oz testda).`,
 [['Listening audio necha marta eshittiriladi?', ['Bir marta','Ikki marta','Uch marta','Xohlagancha'],0,0,'Bir marta.'],
  ['Audioda javob ko\'pincha qanday keladi?', ['Savoldagi so\'zdan farqli (sinonim) shaklda','Aynan bir xil','Hech qachon','Faqat raqam'],0,0,'Parafraz.'],
  ['"NO MORE THAN TWO WORDS" talabi bor. "the red car" yozilsa nima bo\'ladi?', ['Xato hisoblanadi (3 so\'z)','To\'g\'ri','Yarim ball','Hech narsa'],0,1,'Cheklovga rioya qiling.']]],
['Reading: skimming va scanning', `Skimming — matnning umumiy mazmunini tez ko'rib chiqish (sarlavha, birinchi jumlalar). Scanning — aniq ma'lumotni (ism, sana, raqam) qidirish.

Savol turlari: True/False/Not Given, Matching Headings, Multiple Choice, Sentence Completion. True/False/Not Given'da: True — matn tasdiqlaydi; False — matn rad etadi; Not Given — matnda bu haqda ma'lumot yo'q. Eng ko'p xato: Not Given'ni False bilan adashtirish. Faqat matndagi ma'lumotga tayaning, o'z bilimingizga emas.`,
 [['Savol "Not Given" bo\'lsa, bu nimani anglatadi?', ['Matnda bu haqda ma\'lumot yo\'q','Matn rad etadi','Matn tasdiqlaydi','Savol xato'],0,0,'Ma\'lumot yo\'q.'],
  ['Scanning nima?', ['Aniq ma\'lumotni tez qidirish','Matnni qayta yozish','Tarjima','Yodlash'],0,0,'Kalit so\'z qidirish.'],
  ['True/False/Not Given savolida javobni qaerga asoslash kerak?', ['Faqat matndagi ma\'lumotga','O\'z bilimingizga','Taxminga','Boshqa savolga'],0,1,'Matn — yagona manba.']]],
['Writing Task 1: grafik va jadval', `Task 1 (kamida 150 so'z, ~20 daqiqa): grafik, jadval, diagramma yoki jarayonni tasvirlash. Fikr bildirmaysiz — faqat ma'lumotni tasvirlaysiz.

Tuzilma: 1) Kirish — ma'lumotni o'z so'zlaringiz bilan qayta bayon qilish (paraphrase). 2) Overview — asosiy tendentsiyalar (eng muhim qism!). 3) Detail paragraflar — tanlangan raqamlar bilan taqqoslash.

~~~
The chart illustrates changes in internet use in three countries between 2000 and 2020.
Overall, usage rose in every country, with the most dramatic growth in Country B.
~~~

Foydali so'zlar: rose, increased, fell, declined, remained stable, peaked at. Har raqamni sanab chiqmang — eng muhimlarini tanlang.`,
 [['Task 1\'da shaxsiy fikr bildiriladimi?', ['Yo\'q, faqat ma\'lumot tasvirlanadi','Ha, doim','Faqat xulosada','Ixtiyoriy'],0,0,'Obyektiv tasvir.'],
  ['Overview nima?', ['Asosiy tendentsiyalar umumiy xulosasi','Har raqam','Kirish gap','Tarjima'],0,0,'Eng muhim qism.'],
  ['Task 1 uchun minimal so\'z soni?', ['150','250','100','300'],0,1,'150.']]],
['Writing Task 2: insho tuzilishi', `Task 2 (kamida 250 so'z, ~40 daqiqa, Task 1'dan ko'proq ball beradi). Mezonlar: Task Response, Coherence & Cohesion, Lexical Resource, Grammar.

Tuzilma (4 paragraf): kirish (mavzu + sizning pozitsiyangiz), 1-asosiy paragraf (g'oya + tushuntirish + misol), 2-asosiy paragraf, xulosa. Savolga aynan javob bering: agar "do you agree or disagree" bo'lsa, pozitsiyangiz aniq bo'lsin. Mavzudan chetga chiqish ballni tushiradi. Oxirida 3–5 daqiqa xatolarni tekshirish uchun qoldiring.`,
 [['Task 2 uchun minimal so\'z soni?', ['250','150','400','100'],0,0,'250.'],
  ['"To what extent do you agree?" savolida nima muhim?', ['Aniq pozitsiyani bildirish','Pozitsiyani yashirish','Hech narsa yozmaslik','Faqat misollar'],0,0,'Task Response.'],
  ['Mavzudan chetga chiqish qaysi mezonga ta\'sir qiladi?', ['Task Response','Faqat imlo','Hech qaysi','Talaffuz'],0,1,'Savolga javob bermaslik.']]],
['Lug\'at va grammatika kengligi', `Yuqori ball uchun xilma-xil, aniq lug'at va turli jumla tuzilmalari kerak. Qiyin so'zlarni noo'rin ishlatishdan ko'ra, oddiy so'zlarni aniq ishlatish yaxshiroq. Kollokatsiyalar (so'z birikmalari) ustida ishlang: make a decision (do emas), heavy traffic, strong evidence.

Grammatika: murakkab jumlalar (although, whereas, which), shart gaplar (If governments invested more..., there would be...), passiv (It is believed that...). Lekin aniqlik muhim: ko'p murakkab, xatoli jumla — ball tushiradi. Sinonimlarni mashq qiling, lekin ma'nosini aniq biling.`,
 [['Kollokatsiya nima?', ['Tabiiy birga ishlatiladigan so\'zlar birikmasi','Grammatika qoidasi','Imlo xatosi','Tarjima'],0,0,'make a decision.'],
  ['Qaysi birikma to\'g\'ri?', ['make a decision','do a decision','perform a decision','create decision'],0,0,'make a decision.'],
  ['Yangi qiyin so\'zlarni ishlatishda asosiy xavf?', ['Ma\'nosini bilmay noto\'g\'ri ishlatish','Hech qanday','Ball oshadi','Vaqt tejaladi'],0,1,'Aniqlik muhimroq.']]],
['Vaqtni boshqarish va test kuni', `Reading'da har bo'limga ~20 daqiqa ajrating; qiyin savolga yopishib qolmang, belgilab keyingisiga o'ting. Hech bir savolni bo'sh qoldirmang — salbiy ball yo'q, taxmin qiling.

Writing'da Task 2 ga ko'proq vaqt (40 daq), Task 1 ga 20 daq. Test kuni: hujjatlarni oldindan tayyorlang, erta keling, tinchlaning. Oldin to'liq vaqtli mock testlar yeching va xatolar daftarini yuriting: har xatoni sababi bilan yozing va takrorlanmasligi ustida ishlang.`,
 [['IELTS Reading\'da javobni bo\'sh qoldirish yaxshimi?', ['Yo\'q, salbiy ball yo\'q — taxmin qilish kerak','Ha','Faqat qiyinlarini','Farqi yo\'q'],0,0,'Salbiy baholash yo\'q.'],
  ['Writing\'da qaysi topshiriqqa ko\'proq vaqt ajratiladi?', ['Task 2','Task 1','Teng','Hech qaysi'],0,0,'Task 2 — 40 daqiqa.'],
  ['Xatolar daftari nima uchun foydali?', ['Takrorlanuvchi xatolarni topib bartaraf etish uchun','Chiroy','Vaqt olish','Foydasiz'],0,1,'Maqsadli mashq.']]],
], practical: ['Amaliy ish: To\'liq mock test va tahlil', `1) Reading (60 daq) va Listening (30 daq) mock testini real vaqtda yeching.
2) Writing Task 2 inshosini 40 daqiqada yozing (250+ so'z).
3) Natijalarni jadvalga yozing: bo'lim, ball, eng ko'p xato turi.
4) Har bo'limdan 3 ta xatoni sababi bilan tahlil qiling.
5) Keyingi 2 hafta uchun mashq rejasini tuzing.
Tayyor bo'lgach savollarga javob bering.`,
 [['Mock testni nega real vaqt rejimida yechish kerak?', ['Vaqtni boshqarish ko\'nikmasini mashq qilish uchun','Qiyinroq bo\'lishi uchun','Majburiy emas','Chiroy'],0,1,'Imtihon sharoitiga tayyorlik.'],
  ['Xatolarni tahlil qilishda eng muhim savol?', ['Nega xato qildim?','Kim yaxshi yechdi?','Qancha vaqt o\'tdi?','Nechta savol bor?'],0,1,'Sababni topish.'],
  ['Mashq rejasi qanday bo\'lishi kerak?', ['Zaif bo\'limlarga qaratilgan, aniq muddatli','Umumiy','Tasodifiy','Rejasiz'],0,1,'Maqsadli.']] ] },

'IELTS Speaking master klassi': { lessons: [
['Speaking tuzilishi va baholash mezonlari', `Speaking 3 qismdan iborat (11–14 daqiqa, imtihonchi bilan yuzma-yuz, yozib olinadi):
- Part 1: tanishuv va oddiy mavzular (uy, ish, hobbi) — 4–5 daqiqa.
- Part 2: kartochka bo'yicha 1–2 daqiqalik monolog (1 daqiqa tayyorlanish).
- Part 3: Part 2 mavzusi bo'yicha mavhumroq muhokama — 4–5 daqiqa.

Mezonlar: Fluency & Coherence (ravonlik), Lexical Resource (lug'at), Grammatical Range & Accuracy (grammatika), Pronunciation (talaffuz). Har biri 25%.`,
 [['Speaking nechta qismdan iborat?', ['3','2','4','5'],0,0,'Part 1, 2, 3.'],
  ['Part 2 qanday format?', ['1–2 daqiqalik monolog','Savol-javob','Insho','Test'],0,0,'Kartochka bo\'yicha.'],
  ['Qaysi mezon baholanadi?', ['Ravonlik, lug\'at, grammatika, talaffuz','Faqat grammatika','Faqat talaffuz','Faqat lug\'at'],0,1,'To\'rt mezon.']]],
['Part 1: qisqa lekin to\'liq javoblar', `Part 1'da "Yes/No" bilan chegaralanmang, javobni 2–3 jumlagacha kengaytiring: javob + sabab + misol.

Savol: Do you enjoy cooking?
Yaxshi javob: "Yes, I do, mostly because it helps me relax after work. For example, on weekends I often try new recipes with my family."

Haddan ortiq uzun gapirmang — imtihonchi navbatdagi savolga o'tadi. Tabiiy bo'ling, yodlangan javob eshitilib turadi va ball tushiradi.`,
 [['Part 1 da javob qanday bo\'lishi kerak?', ['2–3 jumla: javob + sabab + misol','Faqat "Yes"','Besh daqiqa','Jim turish'],0,0,'Kengaytirilgan.'],
  ['Yodlangan javoblar nega xavfli?', ['Tabiiy eshitilmaydi, baholashda ball tushishi mumkin','Hech qanday','Yaxshi','Majburiy'],0,0,'Examiner payqaydi.'],
  ['Part 1 mavzulari odatda qanday?', ['Kundalik va tanish mavzular','Siyosat','Ilmiy nazariya','Texnik'],0,1,'Uy, ish, hobbi.']]],
['Part 2: monolog tuzilishi', `Kartochka misoli: "Describe a book you enjoyed reading." Kartochkada ko'rsatmalar bor (what, when, why...). Tayyorlanish vaqtida (1 daq) kalit so'zlarni yozing, to'liq jumla emas.

Tuzilma: 1) Tanishtirish (what/when), 2) Tafsilot (nima haqida, kim bilan), 3) Sabab/his-tuyg'u (why), 4) Yakun. Hikoya vaqtida o'tgan zamonni to'g'ri ishlating. Kamida 1.5 daqiqa gapirishga harakat qiling; to'xtatilmaguncha davom eting. Yo'nalish: ko'rsatmalardagi barcha punktlarni qoplash.`,
 [['Part 2 da tayyorlanish vaqti qancha?', ['1 daqiqa','5 daqiqa','Yo\'q','10 daqiqa'],0,0,'1 daqiqa.'],
  ['Tayyorlanish vaqtida nima yoziladi?', ['Kalit so\'zlar','To\'liq matn','Hech narsa','Tarjima'],0,0,'Qisqa eslatmalar.'],
  ['Monologda nima qilish to\'g\'ri?', ['Kartochkadagi barcha punktlarni qoplash va to\'xtatilguncha gapirish','Qisqa tugatish','Mavzudan chiqish','Jim qolish'],0,1,'Mavzu va davomiylik.']]],
['Ravonlik va to\'ldiruvchi iboralar', `Ravonlik — tez gapirish emas, to'xtamasdan, mantiqiy ketma-ketlikda gapirish. O'ylanish uchun tabiiy iboralar: "Well, let me think...", "That's an interesting question", "To be honest...". Faqat "um, uh" ni haddan ortiq ishlatmang.

Bog'lovchilar: however, in addition, as a result, for instance. Sizga so'z topilmasa — boshqacha ifodalang (paraphrase): "the thing you use to cut paper" (scissors). O'z-o'zini tuzatishdan qo'rqmang, lekin tez-tez to'xtab qolish ravonlikni pasaytiradi.`,
 [['Ravonlik nimani anglatadi?', ['To\'xtamasdan, mantiqiy gapirish','Juda tez gapirish','Faqat uzun so\'z','Jim bo\'lish'],0,0,'Mantiqiy oqim.'],
  ['So\'z topilmasa nima qilish kerak?', ['Boshqacha ifodalash (paraphrase)','Jim turish','Mavzuni tashlab ketish','O\'zbekcha gapirish'],0,0,'Paraphrase.'],
  ['"Um, uh" ning haddan ortiq ko\'pligi nimaga olib keladi?', ['Ravonlik balli pasayadi','Ball oshadi','Hech narsa','Lug\'at oshadi'],0,1,'To\'xtashlar ko\'p.']]],
['Lug\'at: idiomalar va aniq so\'zlar', `Yuqori ball uchun keng va aniq lug'at kerak. "Good" o'rniga: excellent, beneficial, impressive. Idiomalar tabiiy ishlatilsa foydali: "a piece of cake" (juda oson), "once in a blue moon" (juda kamdan-kam). Lekin majburlab ko'p idioma qo'shmang.

Mavzu bo'yicha lug'at to'plang: ta'lim, texnologiya, atrof-muhit, sayohat. Yangi so'zni jumla ichida o'rganing va gapda ishlating. Aniq misol: "I'm really into..." (menga juda yoqadi), "I can't stand..." (chidab bo'lmaydi).`,
 [['"A piece of cake" nimani anglatadi?', ['Juda oson narsa','Shirinlik','Ziyofat','Yomon narsa'],0,0,'Idioma.'],
  ['"Once in a blue moon" ma\'nosi?', ['Juda kamdan-kam','Har kuni','Kechqurun','Tez'],0,0,'Kamdan-kam.'],
  ['Idiomalarni ishlatishda to\'g\'ri yondashuv?', ['Tabiiy joyda, me\'yorida','Har jumlada','Hech qachon','Tushunmasdan'],0,1,'Majburiy emas.']]],
['Grammatika: zamonlar va murakkab jumlalar', `Turli zamonlardan to'g'ri foydalaning: Present Simple (odat), Past Simple (tugagan voqea), Present Perfect (tajriba: I have visited...), Future (rejalar). Shart gaplar: "If I had more time, I would travel more."

Murakkab jumlalar: "Although it was expensive, I decided to buy it", "The book, which I read last year, changed my views". Murakkablik muhim, lekin aniqlik undan muhimroq: oddiy, xatosiz jumlalar murakkab, xatoli jumlalardan yaxshi. Xato qilsangiz, tezda tuzating.`,
 [['Tajriba haqida gapirishda qaysi zamon mos?', ['Present Perfect','Future Simple','Faqat Past Continuous','Imperative'],0,0,'I have visited...'],
  ['Qaysi gap shart gap (2-tur)?', ['If I had more time, I would travel more.','If I travel, I go.','I travelled.','Travel!'],0,0,'Haqiqiy bo\'lmagan hozirgi shart.'],
  ['Nima yaxshiroq?', ['Oddiy lekin to\'g\'ri jumlalar murakkab xatoli jumlalardan','Doim juda murakkab','Faqat qisqa','Tasodifiy'],0,1,'Aniqlik muhim.']]],
['Talaffuz, urg\'u va intonatsiya', `Talaffuz mezoni lahja emas, tushunarlilik bahosi. Muhim jihatlar: alohida tovushlar, so'z urg'usi (photograph — PHO-to-graph, photography — pho-TO-gra-phy), jumla ritmi va intonatsiya (savolda ohangning ko'tarilishi, muhim so'zlarga urg'u).

Mashqlar: o'z ovozingizni yozib eshiting (shadowing — nutqchini taqlid qilish), qiyin so'zlarni lug'atdan eshiting. Ohangsiz, monoton gapirish ball tushiradi. Tabiiy ritm uchun muhim so'zlarni kuchliroq, yordamchi so'zlarni qisqa talaffuz qiling.`,
 [['Shadowing nima?', ['Nutqchini darhol taqlid qilib takrorlash','Yozish','Tarjima','Yodlash'],0,0,'Talaffuz va ritm mashqi.'],
  ['Talaffuz mezonida asosiy talab?', ['Tushunarlilik','Aynan britaniya lahjasi','Tez gapirish','Baland ovoz'],0,0,'Intelligibility.'],
  ['Monoton (ohangsiz) nutq nimaga olib keladi?', ['Talaffuz va ravonlik ballining pasayishiga','Ball oshishiga','Hech narsaga','Lug\'at oshishiga'],0,1,'Intonatsiya muhim.']]],
['Part 3 va test kuni strategiyasi', `Part 3'da mavhum, fikr bildirishni talab qiluvchi savollar: "Why do some people prefer reading books to watching films?" Javob tuzilmasi: fikr + sabab + misol + (qarama-qarshi nuqtai nazar). "Some people think..., while others..." kabi iboralar yordam beradi.

Aniq bo'lmagan savol bo'lsa, ayting: "Could you repeat that, please?" — bu ball tushirmaydi. Test kuni: asabiylashmang, imtihonchi bilan tabiiy suhbatlashing, ko'z aloqasini saqlang. Taxminlar bildirish uchun: "I suppose...", "It's likely that...".`,
 [['Part 3 savollari qanday?', ['Mavhum va fikr bildirishni talab qiladi','Faqat ismni so\'raydi','Faqat ha/yo\'q','Rasm ta\'rifi'],0,0,'Chuqur muhokama.'],
  ['Savolni tushunmasangiz nima qilish mumkin?', ['Qaytarishni so\'rash','Jim turish','O\'zbekcha javob','Ketib qolish'],0,0,'Bu normal va ruxsat etilgan.'],
  ['Part 3 uchun yaxshi javob tuzilmasi?', ['Fikr + sabab + misol (+ boshqa nuqtai nazar)','Faqat bitta so\'z','Faqat misol','Hikoya'],0,1,'Argumentlangan javob.']]],
], practical: ['Amaliy ish: To\'liq Speaking mock', `1) Telefon yoki do'stingiz bilan Part 1, 2, 3 bo'yicha to'liq mock o'tkazing va ovozni yozib oling.
2) Yozuvni eshitib, to'rt mezon bo'yicha o'zingizni baholang.
3) 5 ta xato (grammatika/talaffuz/to'xtash) ni yozing va to'g'ri variantlarni tuzing.
4) Part 2 mavzusini (kartochka) qayta yozib oling va farqni solishtiring.
5) 1 haftalik mashq rejasini tuzing.
Tayyor bo'lgach savollarga javob bering.`,
 [['Yozuvni eshitishning asosiy foydasi?', ['O\'zingizning xatolaringizni tashqaridan eshitish','Vaqt o\'tkazish','Foyda yo\'q','Reklama'],0,1,'O\'z-o\'zini tahlil.'],
  ['Qayta yozib olish nima uchun?', ['Taraqqiyotni solishtirish uchun','Chiroy','Majburiy emas','Tezlik'],0,1,'Natijani ko\'rish.'],
  ['Mashq rejasi qaysi tamoyil bo\'yicha tuziladi?', ['Eng zaif mezonga ko\'proq vaqt','Barchasiga teng','Faqat kuchli tomonga','Tasodifiy'],0,1,'Maqsadli mashq.']] ] },
};
