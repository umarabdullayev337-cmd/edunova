// Frontend kurslari: JavaScript, React, TypeScript, Vue
module.exports = {
'Zamonaviy JavaScript asoslari': { lessons: [
['O\'zgaruvchilar va ma\'lumot turlari', `JavaScript'da o'zgaruvchi e'lon qilishning zamonaviy usullari: const (o'zgarmas bog'lanish) va let (o'zgaradigan). var eskirgan — undan qoching.

Asosiy turlar: string, number, boolean, null, undefined, object, array.

~~~
const ism = 'Ali';
let yosh = 20;
yosh = 21;
console.log(typeof ism);   // string
console.log(typeof null);  // object (tarixiy xato)
~~~

Standart qoida: avval const yozing, faqat qiymat o'zgarishi kerak bo'lsa let ishlating.`,
 [['Qiymati o\'zgarmaydigan o\'zgaruvchi uchun qaysi kalit so\'z mos?', ['var','let','const','static'],2,0,'const — qayta tayinlab bo\'lmaydi.'],
  ['typeof "salom" natijasi?', ['text','string','char','object'],1,0,'string.'],
  ['typeof null nima qaytaradi?', ['null','undefined','object','number'],2,1,'Bu tilning tarixiy xatosi, shunday qolgan.']]],
['Operatorlar va shartlar', `Taqqoslashda === (qat'iy tenglik) ishlating. == turlarni o'zgartirib solishtiradi va kutilmagan natija beradi.

~~~
console.log(5 == '5');   // true
console.log(5 === '5');  // false
const yosh = 18;
const holat = yosh >= 18 ? 'katta' : 'kichik';
~~~

Falsy qiymatlar: false, 0, '', null, undefined, NaN. Qolgan hamma narsa truthy. Mantiqiy operatorlar: && (va), || (yoki), ?? (faqat null/undefined bo'lsa standart qiymat).`,
 [['0 === "0" natijasi?', ['true','false','undefined','xato'],1,0,'Turlari har xil.'],
  ['Quyidagilardan qaysi biri falsy?', ['"0"','[]','0','"false"'],2,0,'0 falsy, "0" esa bo\'sh bo\'lmagan matn.'],
  ['0 ?? 10 natijasi nima?', ['10','0','null','undefined'],1,1,'?? faqat null/undefined bo\'lganda o\'ngni oladi; 0 bo\'lsa 0 qoladi.']]],
['Funksiyalar va arrow funksiyalar', `Funksiya — qayta ishlatiladigan kod bloki. Arrow funksiya qisqa yozuv beradi.

~~~
function qosh(a, b) { return a + b; }
const qosh2 = (a, b) => a + b;
const salom = (ism = 'mehmon') => 'Salom, ' + ism;
~~~

Default parametr, rest (...args) va spread (...arr) zamonaviy JS'ning muhim qismlari. Funksiya return qilmasa, undefined qaytaradi.`,
 [['Arrow funksiya sintaksisi qaysi?', ['function => x','(x) => x * 2','x -> x * 2','=> (x) x*2'],1,0,'(x) => x * 2.'],
  ['return yozilmagan funksiya nima qaytaradi?', ['0','null','undefined','""'],2,0,'undefined.'],
  ['Math.max(...[3, 9, 4]) da "..." nima qiladi?', ['Massivni elementlarga yoyadi (spread)','Massivni o\'chiradi','Izoh','Xato beradi'],0,1,'Spread massivni alohida argumentlarga aylantiradi.']]],
['Massivlar va ularning metodlari', `Massivlar bilan ishlashning kuchli usullari: map, filter, reduce.

~~~
const sonlar = [1, 2, 3, 4, 5];
const ikki = sonlar.map(n => n * 2);        // [2,4,6,8,10]
const juft = sonlar.filter(n => n % 2 === 0); // [2,4]
const yig = sonlar.reduce((s, n) => s + n, 0); // 15
~~~

map har elementni o'zgartirib yangi massiv qaytaradi, filter shartga mosini ajratadi, reduce hammasini bitta qiymatga yig'adi. Bular asl massivni o'zgartirmaydi.`,
 [['Qaysi metod har elementni o\'zgartirib yangi massiv yaratadi?', ['filter','map','reduce','find'],1,0,'map.'],
  ['[1,2,3,4].filter(n => n > 2) natijasi?', ['[1,2]','[3,4]','[true,true]','[2,3,4]'],1,0,'Faqat 2 dan kattalar.'],
  ['[1,2,3].reduce((s,n) => s + n, 10) natijasi?', ['6','16','10','123'],1,1,'Boshlang\'ich qiymat 10: 10+1+2+3.']]],
['Ob\'ektlar va destrukturizatsiya', `Ob'ekt — kalit-qiymat juftliklari to'plami. Destrukturizatsiya qiymatlarni qulay ajratib oladi.

~~~
const user = { ism: 'Vali', yosh: 22, shahar: 'Toshkent' };
const { ism, yosh } = user;
const nusxa = { ...user, yosh: 23 };
const [a, b] = [10, 20];
~~~

Spread bilan ob'ektdan yangi nusxa yaratiladi, asl ob'ekt o'zgarmaydi. Ixtiyoriy zanjir (?.) mavjud bo'lmagan maydonda xatosiz undefined qaytaradi: user.manzil?.kocha.`,
 [['const { ism } = user; nima qiladi?', ['user ni o\'chiradi','user.ism ni ism o\'zgaruvchisiga oladi','ism ni user ga qo\'shadi','Xato beradi'],1,0,'Destrukturizatsiya.'],
  ['user?.manzil?.kocha manzil yo\'q bo\'lsa nima beradi?', ['Xato','undefined','null','""'],1,0,'Ixtiyoriy zanjir xatoning oldini oladi.'],
  ['{ ...user, yosh: 23 } nima qiladi?', ['user\'ni o\'zgartiradi','Yangi ob\'ekt yaratadi, yosh 23 bo\'ladi','Faqat yosh qaytaradi','Xato'],1,1,'Asl ob\'ekt o\'zgarmaydi.']]],
['DOM bilan ishlash', `DOM — sahifa elementlarining daraxtsimon ko'rinishi. JavaScript orqali uni o'qish va o'zgartirish mumkin.

~~~
const btn = document.querySelector('#btn');
btn.addEventListener('click', () => {
  document.querySelector('h1').textContent = 'Bosildi!';
});
~~~

querySelector — CSS selektor bilan element topadi. addEventListener — hodisaga (click, input, submit) tinglovchi ulaydi. Foydalanuvchi kiritgan matnni innerHTML orqali qo'ymang — XSS xavfi bor; textContent ishlating.`,
 [['Elementni CSS selektor bilan topish metodi?', ['getElement','querySelector','findNode','select'],1,0,'querySelector.'],
  ['Bosilganda funksiya ishlashi uchun nima ishlatiladi?', ['addEventListener("click", ...)','setClick()','onTouchOnly','document.click'],0,0,'Hodisa tinglovchisi.'],
  ['Foydalanuvchi matnini sahifaga qo\'yishda nega textContent xavfsizroq?', ['Tezroq','HTML sifatida talqin qilmaydi (XSS\'ning oldi olinadi)','Chiroyliroq','Farqi yo\'q'],1,1,'innerHTML skriptli tegni ishga tushirishi mumkin.']]],
['Asinxron JavaScript: Promise va async/await', `Server so'rovi kabi sekin amallar kutishni talab qiladi. Promise — kelajakda tugaydigan amal natijasi. async/await uni o'qishga oson qiladi.

~~~
async function yukla() {
  try {
    const res = await fetch('/api/courses');
    if (!res.ok) throw new Error('Xato: ' + res.status);
    return await res.json();
  } catch (e) {
    console.error(e.message);
  }
}
~~~

fetch tarmoq xatosida reject bo'ladi, lekin 404/500 da reject bo'lmaydi — res.ok ni tekshirish shart.`,
 [['await kalit so\'zi qayerda ishlatiladi?', ['Har joyda','async funksiya ichida','Faqat sinfda','Faqat DOM\'da'],1,0,'async funksiya ichida (yoki modul darajasida).'],
  ['Asinxron xatolarni ushlash uchun nima ishlatiladi?', ['if','try/catch','switch','break'],1,0,'try/catch.'],
  ['Server 404 qaytarsa, fetch promise\'i nima bo\'ladi?', ['Reject bo\'ladi','Resolve bo\'ladi, res.ok false','Qotib qoladi','Avtomatik qayta urinadi'],1,1,'fetch faqat tarmoq xatosida reject bo\'ladi.']]],
['Modullar va umumiy amaliyotlar', `ES modullari kodni fayllarga bo'lish imkonini beradi: export bilan chiqarib, import bilan olinadi.

~~~
// utils.js
export const kvadrat = (x) => x * x;
export default function salom() {}
// app.js
import salom, { kvadrat } from './utils.js';
~~~

HTML'da modul ulash: type="module". Toza kod qoidalari: aniq nomlar, kichik funksiyalar, takrorlanmaslik (DRY), const'ni afzal ko'rish. Xatolarni konsolda emas, tushunarli xabar bilan ko'rsating.`,
 [['Nomlangan eksport qanday import qilinadi?', ['import x from','import { x } from','require x','get x from'],1,0,'Jingalak qavs bilan.'],
  ['HTML\'da ES modul skript qanday ulanadi?', ['<script type="module">','<module src>','<script es6>','<import>'],0,0,'type="module".'],
  ['DRY prinsipi nimani anglatadi?', ['Takrorlanmang — bir xil mantiqni bir joyda yozing','Doim qisqa yozing','Faqat funksiya ishlating','Izoh yozmang'],0,1,'Don\'t Repeat Yourself.']]],
], practical: ['Amaliy ish: Vazifalar ro\'yxati ilovasi', `Sof JavaScript bilan Todo ilovasi yarating:
1) Input va tugma orqali vazifa qo'shish (bo'sh matn qo'shilmasin).
2) Vazifani bosib "bajarildi" deb belgilash; o'chirish tugmasi.
3) Ro'yxat massivda saqlansin va har o'zgarishda qayta chizilsin.
4) Foydalanuvchi matni textContent orqali qo'yilsin.
5) Ixtiyoriy: fetch bilan namunaviy ma'lumot yuklash.
Tayyor bo'lgach savollarga javob bering.`,
 [['Bajarilgan vazifalarni ajratib olish uchun qaysi metod mos?', ['map','filter','push','join'],1,1,'filter(t => t.done).'],
  ['Vazifa o\'chirilganda massivni o\'zgartirmay yangisini hosil qilish usuli?', ['arr.pop()','arr.filter(t => t.id !== id)','arr.length = 0','delete arr'],1,1,'filter yangi massiv qaytaradi.'],
  ['Bo\'sh vazifa qo\'shilishining oldini olish uchun nima tekshiriladi?', ['text.trim() !== ""','text == null','typeof text','text.length > 100'],0,1,'Faqat bo\'sh joylar ham bo\'sh hisoblanadi.']] ] },

'React bilan real loyihalar': { lessons: [
['React nima va komponentlar', `React — foydalanuvchi interfeysini komponentlardan quruvchi kutubxona. Komponent — JSX qaytaradigan funksiya.

~~~
function Salom({ ism }) {
  return <h1>Salom, {ism}!</h1>;
}
export default function App() {
  return <Salom ism="Ali" />;
}
~~~

JSX — JavaScript ichida HTML'ga o'xshash yozuv. Komponent nomi katta harf bilan boshlanadi. {} ichida JS ifodasi yoziladi. Props — komponentga tashqaridan beriladigan ma'lumot.`,
 [['React komponenti nima?', ['CSS fayl','JSX qaytaradigan funksiya','Ma\'lumotlar bazasi','HTML teg'],1,0,'Funksiya.'],
  ['Komponent nomi qanday boshlanishi kerak?', ['Kichik harf','Katta harf','Raqam','Pastki chiziq'],1,0,'Aks holda React uni oddiy HTML teg deb oladi.'],
  ['JSX ichida JavaScript ifodasi qanday yoziladi?', ['(( ))','{ }','<% %>','[[ ]]'],1,1,'Jingalak qavs.']]],
['Props va komponentlar tuzilishi', `Props komponentga ma'lumot uzatadi va faqat o'qish uchun: komponent o'z props'ini o'zgartirmaydi. children props'i ichiga o'ralgan kontentni beradi.

~~~
function Card({ title, children }) {
  return <div className="card"><h3>{title}</h3>{children}</div>;
}
<Card title="Kurs"><p>Tavsif</p></Card>
~~~

Katta interfeysni kichik, qayta ishlatiladigan komponentlarga bo'ling: bir komponent — bir vazifa.`,
 [['Props o\'zgartirilishi mumkinmi?', ['Ha, komponent ichida','Yo\'q, ular faqat o\'qish uchun','Faqat funksiyada','Faqat sinfda'],1,0,'Props o\'zgarmas.'],
  ['children props nima?', ['Bolalar sinfi','Teg ichiga yozilgan kontent','CSS klassi','Event'],1,0,'Ochuvchi va yopuvchi teg orasidagi kontent.'],
  ['Ota komponent bolaga qiymat uzatadi. Bola uni o\'zgartirishi kerak bo\'lsa nima qilinadi?', ['Props\'ni to\'g\'ridan-to\'g\'ri o\'zgartiradi','Ota funksiya (callback) props orqali beriladi','Global o\'zgaruvchi','Mumkin emas'],1,1,'Ma\'lumot pastga, hodisalar yuqoriga.']]],
['State va useState', `State — komponentning o'zgaruvchan ma'lumoti. U o'zgarsa, komponent qayta chiziladi.

~~~
import { useState } from 'react';
function Hisoblagich() {
  const [son, setSon] = useState(0);
  return <button onClick={() => setSon(son + 1)}>Bosildi: {son}</button>;
}
~~~

State'ni to'g'ridan-to'g'ri o'zgartirmang (son++), faqat setter orqali. Oldingi qiymatga bog'liq bo'lsa: setSon(s => s + 1). Massiv/ob'ekt state'da yangi nusxa yarating.`,
 [['useState nima qaytaradi?', ['Faqat qiymat','[qiymat, setter] massivi','Funksiya','Promise'],1,0,'Juftlik.'],
  ['State o\'zgarganda nima bo\'ladi?', ['Hech narsa','Komponent qayta chiziladi','Sahifa yangilanadi','Server so\'raladi'],1,0,'Re-render.'],
  ['Massiv state\'ga element qo\'shishning to\'g\'ri usuli?', ['arr.push(x); setArr(arr)','setArr([...arr, x])','arr[arr.length]=x','setArr(arr)'],1,1,'Yangi massiv yaratish kerak, aks holda React o\'zgarishni sezmaydi.']]],
['Ro\'yxatlar, shartli chizish va key', `Ro'yxatni map bilan chiziladi, har elementga noyob key beriladi — React o'zgarishlarni shu orqali aniqlaydi.

~~~
{kurslar.map(k => <li key={k.id}>{k.nom}</li>)}
{yuklanmoqda ? <p>Yuklanmoqda...</p> : <Royxat />}
{xato && <p className="err">{xato}</p>}
~~~

key sifatida massiv indeksini ishlatmang (tartib o'zgarsa xato bo'ladi), ma'lumotdagi noyob id ni ishlating.`,
 [['Ro\'yxat elementlariga nima uchun key beriladi?', ['Dizayn uchun','React elementlarni aniqlab, samarali yangilashi uchun','Tartiblash uchun','Majburiy emas va foydasiz'],1,0,'Identifikatsiya.'],
  ['Shartli chizish uchun qaysi usul ishlatiladi?', ['if teg','Ternary yoki &&','switch teg','when()'],1,0,'{shart ? A : B}.'],
  ['Qo\'shish/o\'chirish bo\'ladigan ro\'yxatda key=indeks nega yomon?', ['Sekin','Elementlar o\'rni o\'zgarsa holat noto\'g\'ri elementga yopishib qoladi','Xato beradi','Farqi yo\'q'],1,1,'Barqaror id kerak.']]],
['Formalar va hodisalar', `Boshqariladigan input — qiymati state'da saqlanadi.

~~~
function Forma() {
  const [email, setEmail] = useState('');
  const yubor = (e) => { e.preventDefault(); console.log(email); };
  return (
    <form onSubmit={yubor}>
      <input value={email} onChange={e => setEmail(e.target.value)} />
      <button>Yuborish</button>
    </form>
  );
}
~~~

e.preventDefault() sahifaning qayta yuklanishini to'xtatadi. Validatsiyani doim serverda ham takrorlang.`,
 [['Boshqariladigan input qiymati qayerda saqlanadi?', ['DOM\'da','State\'da','CSS\'da','Cookie\'da'],1,0,'value + onChange.'],
  ['onSubmit\'da e.preventDefault() nega yoziladi?', ['Formani tozalash uchun','Brauzerning standart yuborish/qayta yuklashini to\'xtatish uchun','Xato chiqarish uchun','Tezlik uchun'],1,0,'SPA\'da sahifa yangilanmasligi kerak.'],
  ['Faqat frontend validatsiyasi nega yetarli emas?', ['Sekin','Foydalanuvchi uni chetlab o\'tib to\'g\'ridan-to\'g\'ri API\'ga yuborishi mumkin','Brauzer qo\'llamaydi','Yetarli'],1,1,'Server tekshiruvi shart.']]],
['useEffect va ma\'lumot yuklash', `useEffect — komponent chizilgandan keyin "yon ta'sir"larni (so'rov, timer) bajaradi. Bog'liqlik massivi qachon qayta ishlashini belgilaydi.

~~~
useEffect(() => {
  let bekor = false;
  fetch('/api/courses').then(r => r.json()).then(d => { if (!bekor) setKurslar(d); });
  return () => { bekor = true; };
}, []);
~~~

[] — faqat birinchi chizilganda. [id] — id o'zgarganda. Qaytarilgan funksiya tozalash uchun (timer, obuna). Bog'liqliklarni yozmasdan qoldirish eskirgan qiymat xatosiga olib keladi.`,
 [['useEffect([]) qachon ishlaydi?', ['Har chizilishda','Faqat birinchi chizilgandan keyin','Hech qachon','Har bosishda'],1,0,'Bo\'sh massiv.'],
  ['useEffect ichida qaytarilgan funksiya nima uchun?', ['Natija qaytarish','Tozalash (cleanup)','State o\'zgartirish','Render'],1,0,'Unmount yoki qayta ishlashdan oldin chaqiriladi.'],
  ['Massivni umuman bermasak (useEffect(fn)) nima bo\'ladi?', ['Faqat bir marta','Har chizilgandan keyin ishlaydi','Ishlamaydi','Xato'],1,1,'Bog\'liqlik ko\'rsatilmasa, har renderdan keyin.']]],
['Routing va holatni ulashish', `SPA'da sahifalar o'rtasida o'tish uchun router ishlatiladi (React Router). Bir nechta komponent bir xil ma'lumotni ishlatsa, state'ni ularning umumiy otasiga ko'taring (lifting state up) yoki Context ishlating.

~~~
const ThemeCtx = createContext('dark');
function Tugma() {
  const tema = useContext(ThemeCtx);
  return <button className={tema}>OK</button>;
}
~~~

Context har joyga props uzatish (prop drilling) muammosini hal qiladi. Lekin tez-tez o'zgaradigan katta ma'lumot uchun maxsus state kutubxonalari qulay.`,
 [['Props\'ni juda ko\'p qatlamdan uzatish muammosi nima deyiladi?', ['Prop drilling','Props leak','Deep render','State drift'],0,0,'Prop drilling.'],
  ['Bir nechta komponent bir xil state kerak bo\'lsa nima qilinadi?', ['Har birida nusxa','State\'ni umumiy otaga ko\'tarish','Global var','Hech narsa'],1,0,'Lifting state up.'],
  ['Context\'dan foydalanish uchun qaysi hook?', ['useState','useContext','useMemo','useRef'],1,1,'useContext.']]],
['Optimallashtirish va deploy', `Keraksiz qayta chizilishlarni kamaytirish: React.memo (props o'zgarmasa qayta chizmaydi), useMemo (qimmat hisobni eslab qoladi), useCallback (funksiyani eslaydi). Lekin avval o'lchang — erta optimallashtirish kodni murakkablashtiradi.

Katta sahifalarni lazy() bilan kerak bo'lganda yuklang. Production build: npm run build keyin statik fayllarni Netlify, Vercel yoki serverga joylashtiring. Muhit o'zgaruvchilari frontendda ochiq bo'ladi — maxfiy kalit yozmang.`,
 [['useMemo nima uchun ishlatiladi?', ['Qimmat hisob natijasini eslab qolish uchun','Stil berish uchun','Forma yuborish uchun','Route uchun'],0,0,'Memoizatsiya.'],
  ['Frontend .env o\'zgaruvchilari nega maxfiy emas?', ['Chunki ular bundle\'ga kiradi va brauzerda ko\'rinadi','Ular shifrlangan','Ular ishlamaydi','Faqat serverda'],0,0,'Build vaqtida kodga joylanadi.'],
  ['Optimallashtirishdan avval nima qilish to\'g\'ri?', ['Hamma narsani useMemo\'ga o\'rash','Haqiqiy muammoni profayler bilan o\'lchash','Kutubxonani almashtirish','Komponentlarni birlashtirish'],1,1,'Avval o\'lchang.']]],
], practical: ['Amaliy ish: Kurslar katalogi', `React'da kurslar katalogi yarating:
1) /api/courses dan ma'lumotni useEffect bilan yuklang (yuklanmoqda va xato holatlari bilan).
2) Qidiruv input'i (boshqariladigan) — ro'yxatni nom bo'yicha filtrlang.
3) Kurs kartochkasi alohida komponent, key = id.
4) Sevimlilar: kartochkadagi tugma state'ni o'zgartirsin.
5) Build qilib deploy qiling.
Tayyor bo'lgach savollarga javob bering.`,
 [['Qidiruv natijasi uchun alohida state kerakmi yoki hisoblash mumkinmi?', ['Hisoblash mumkin: kurslar va qidiruv state\'idan filter bilan olinadi','Doim alohida state','Global var','Mumkin emas'],0,1,'Hosilaviy qiymatni state qilib saqlash ortiqcha.'],
  ['Sevimlilar uchun Set yoki massivni yangilashda nima muhim?', ['Yangi nusxa yaratish','Asl massivni o\'zgartirish','window\'ga yozish','DOM\'ga tegish'],0,1,'Immutability.'],
  ['Yuklash holatlarini nima uchun alohida ko\'rsatish kerak?', ['Chiroyli bo\'lishi uchun','Foydalanuvchi nima bo\'layotganini bilishi va xato holatini ko\'rishi uchun','React talab qiladi','Hech qanday sabab'],1,1,'UX va ishonchlilik.']] ] },

'TypeScript amaliyotda': { lessons: [
['TypeScript nima uchun kerak', `TypeScript — JavaScript ustiga turlar qo'shadigan til. Kod yozish vaqtida xatolarni topadi, ishga tushirishni kutmasdan. Brauzer TS'ni tushunmaydi: u kompilyatsiya qilinib JS'ga aylantiriladi.

~~~
function qosh(a: number, b: number): number { return a + b; }
qosh(2, '3'); // Xato: string number emas
~~~

Afzalliklari: avtomatik to'ldirish, xavfsiz refaktoring, kodning o'zi hujjat vazifasini bajaradi.`,
 [['TypeScript xatolarni qachon topadi?', ['Faqat ishga tushganda','Kod yozish/kompilyatsiya vaqtida','Hech qachon','Faqat productionda'],1,0,'Statik tekshiruv.'],
  ['Brauzer TypeScript\'ni to\'g\'ridan-to\'g\'ri bajara oladimi?', ['Ha','Yo\'q, avval JS\'ga kompilyatsiya qilinadi','Faqat Chrome\'da','Faqat modulda'],1,0,'tsc yoki build vositasi o\'giradi.'],
  ['Turlar ishga tushgan dasturda ham tekshiriladimi?', ['Ha, doim','Yo\'q, kompilyatsiyadan keyin turlar o\'chib ketadi','Faqat strict rejimda','Faqat Node\'da'],1,1,'Runtime\'da faqat JS qoladi.']]],
['Asosiy turlar va tur xulosasi', `Asosiy turlar: string, number, boolean, array, tuple, enum, any, unknown. Ko'pincha tur yozish shart emas — TypeScript o'zi aniqlaydi (type inference).

~~~
let ism: string = 'Ali';
let yosh = 20;            // number deb aniqlanadi
const sonlar: number[] = [1, 2, 3];
const juft: [string, number] = ['a', 1];
~~~

any turni o'chirib qo'yadi — undan qoching. Noma'lum ma'lumot uchun unknown ishlating: ishlatishdan oldin tekshirishga majbur qiladi.`,
 [['Massiv turi qanday yoziladi?', ['number[]','array<number','[number]()','list number'],0,0,'number[] yoki Array<number>.'],
  ['"any" turi nega xavfli?', ['Sekin','Tur tekshiruvini o\'chiradi','Xato beradi','Hajm oshadi'],1,0,'Himoyani yo\'qotadi.'],
  ['Noma\'lum tashqi ma\'lumot uchun any o\'rniga nima yaxshiroq?', ['unknown','void','never','null'],0,1,'unknown tekshirishni talab qiladi.']]],
['Interface va type', `Ob'ekt shaklini interface yoki type bilan tasvirlash mumkin.

~~~
interface Kurs {
  id: string;
  nom: string;
  narx?: number;       // ixtiyoriy
  readonly yaratildi: number;
}
type Daraja = 'oson' | "o'rta" | 'qiyin';  // birlashma
const k: Kurs = { id: '1', nom: 'TS', yaratildi: 1 };
~~~

? — ixtiyoriy maydon, readonly — o'zgartirib bo'lmaydi. Birlashma (|) turi bir nechta qiymatdan birini bildiradi. Interface ob'ektlar uchun, type esa birlashma va murakkab turlar uchun qulay.`,
 [['Ixtiyoriy maydon qaysi belgi bilan yoziladi?', ['!','?','*','&'],1,0,'narx?: number.'],
  ['readonly nimani bildiradi?', ['Faqat o\'qiladi, qayta tayinlab bo\'lmaydi','Yashirin maydon','Majburiy','Statik'],0,0,'O\'zgartirishdan himoya.'],
  ['type Rol = "user" | "admin" ga "guest" tayinlansa nima bo\'ladi?', ['Ishlaydi','Kompilyatsiya xatosi','Runtime xato','Ogohlantirish yo\'q'],1,1,'Literal birlashmadan tashqari qiymat taqiqlanadi.']]],
['Funksiyalar turlari', `Funksiya parametrlari va qaytish turini yozing.

~~~
function topKurs(id: string): Kurs | undefined { /* ... */ }
const salom = (ism: string, salomlash = 'Salom'): string => salomlash + ', ' + ism;
function log(xabar: string): void { console.log(xabar); }
~~~

void — hech narsa qaytarmaydi. Kurs | undefined ishlatganda uni tekshirish shart: if (kurs) { ... }. Bu null/undefined xatolarining katta qismini oldini oladi.`,
 [['Hech narsa qaytarmaydigan funksiya turi?', ['null','void','never','empty'],1,0,'void.'],
  ['"Kurs | undefined" turi qanday ma\'no beradi?', ['Kurs yoki undefined','Faqat Kurs','Ikkalasi bir vaqtda','Xato'],0,0,'Birlashma.'],
  ['Qiymat Kurs | undefined bo\'lsa, uning maydoniga kirishdan oldin nima qilinadi?', ['Hech narsa','undefined emasligini tekshirish (narrowing)','any qilish','try/catch'],1,1,'Torayish (narrowing).']]],
['Generics', `Generics — turni parametr qilib olish: bir funksiyani turli turlar bilan xavfsiz ishlatish.

~~~
function birinchi<T>(arr: T[]): T | undefined { return arr[0]; }
const a = birinchi([1, 2, 3]);     // number
const b = birinchi(['x', 'y']);    // string

interface Javob<T> { ok: boolean; data: T; }
~~~

T — "qandaydir tur" o'rin egasi. Natijada kodni takrorlamaysiz va turlar yo'qolmaydi (any kabi emas).`,
 [['Generic parametr odatda qanday belgilanadi?', ['<T>','[T]','(T)','{T}'],0,0,'Burchakli qavs.'],
  ['birinchi([1,2,3]) qaytaradigan tur?', ['any','number | undefined','string','T'],1,0,'T = number.'],
  ['Generics any\'dan nimasi bilan yaxshi?', ['Kamroq yozish','Tur ma\'lumotini saqlab qoladi','Tezroq ishlaydi','Farqi yo\'q'],1,1,'any turni yo\'qotadi, generic saqlaydi.']]],
['Tur toraytirish va utility turlar', `Narrowing — birlashma turini tekshirib aniqlashtirish: typeof, in, instanceof.

~~~
function uzunlik(x: string | string[]) {
  return typeof x === 'string' ? x.length : x.length;
}
~~~

Utility turlar tayyor o'zgartirishlar beradi:
- Partial<T> — barcha maydonlar ixtiyoriy
- Pick<T, K> — faqat tanlangan maydonlar
- Omit<T, K> — tanlanganlarsiz
- Record<K, V> — kalit-qiymat lug'ati

Misol: Partial<Kurs> yangilash (PATCH) ma'lumoti uchun juda qulay.`,
 [['Barcha maydonlarni ixtiyoriy qiluvchi utility?', ['Partial','Pick','Omit','Record'],0,0,'Partial<T>.'],
  ['Qiymat string yoki massiv ekanligini aniqlash uchun nima ishlatiladi?', ['typeof / Array.isArray','as any','delete','void'],0,0,'Narrowing.'],
  ['Omit<Kurs, "id"> nima beradi?', ['Faqat id','Kurs, lekin id\'siz','Kurs + id','Bo\'sh tur'],1,1,'Tanlangan kalit olib tashlanadi.']]],
['tsconfig, strict rejim va loyihada qo\'llash', `tsconfig.json — kompilyator sozlamalari. "strict": true eng muhim: noImplicitAny, strictNullChecks va boshqa qat'iy tekshiruvlarni yoqadi. Yangi loyihada doim yoqing.

Tashqi JS kutubxonalar uchun tur fayllari: npm i -D @types/node. Mavjud JS loyihani sekin-asta ko'chiring: avval allowJs, keyin fayllarni birma-bir .ts ga o'tkazing.

Type assertion (x as Kurs) kompilyatorga "ishon" deydi, lekin tekshirmaydi — kamroq ishlating. Tashqaridan kelgan ma'lumotni (API) runtime'da ham tekshirish (validatsiya) kerak.`,
 [['strict rejim nima qiladi?', ['Kodni tezlashtiradi','Qat\'iy tur tekshiruvlarini yoqadi','Kodni minimallashtiradi','Testlarni ishga tushiradi'],1,0,'Ko\'proq xatoni oldindan tutadi.'],
  ['@types/node nima uchun?', ['Node\'ni o\'rnatadi','Node API\'lari uchun tur ta\'riflarini beradi','Test','Deploy'],1,0,'Tur deklaratsiyalari.'],
  ['API\'dan kelgan JSON\'ni "as Kurs" deb yozish nima uchun yetarli emas?', ['Sekin','as faqat kompilyatorni ishontiradi, haqiqiy ma\'lumotni tekshirmaydi','Xato beradi','Hech narsa'],1,1,'Runtime validatsiya kerak.']]],
], practical: ['Amaliy ish: Turlangan API klient', `Kurslar API'si uchun turlangan klient yozing:
1) Kurs, Mentor interface'larini aniqlang.
2) async function api<T>(url: string): Promise<T> — res.ok ni tekshirsin.
3) Kurslarni narx bo'yicha filtrlovchi funksiya (Pick<Kurs, "nom" | "narx"> qaytarsin).
4) Yangilash uchun Partial<Kurs> ishlating.
5) tsconfig'da strict: true bo'lsin, xatosiz kompilyatsiya qiling.
Tayyor bo'lgach savollarga javob bering.`,
 [['api<Kurs[]>(url) da <Kurs[]> nimani bildiradi?', ['Funksiya nomi','Qaytadigan ma\'lumot turi (generic argument)','Massiv yaratadi','Izoh'],1,1,'T = Kurs[].'],
  ['Pick<Kurs, "nom" | "narx"> natijasi?', ['Kursning barcha maydonlari','Faqat nom va narx maydonlari','nom va narxsiz','Bo\'sh'],1,1,'Pick — tanlash.'],
  ['strict: true yoqilganda const x: string = null qanday bo\'ladi?', ['Ishlaydi','Xato','Faqat ogohlantirish','undefined bo\'ladi'],1,1,'strictNullChecks.']] ] },

'Vue.js bilan zamonaviy interfeyslar': { lessons: [
['Vue nima va birinchi ilova', `Vue — interfeys qurish uchun progressiv freymvork. Reaktivlik: ma'lumot o'zgarsa, interfeys avtomatik yangilanadi. Vue 3'da Composition API va <script setup> ishlatiladi.

~~~
<script setup>
import { ref } from 'vue';
const son = ref(0);
</script>
<template>
  <button @click="son++">Bosildi: {{ son }}</button>
</template>
~~~

{{ }} — matnni qo'yish (interpolyatsiya). @click — hodisa. ref() reaktiv qiymat yaratadi; script ichida .value orqali o'qiladi, template'da esa avtomatik ochiladi.`,
 [['Vue 3\'da reaktiv qiymat yaratish funksiyasi?', ['ref','state','reactive only','watch'],0,0,'ref().'],
  ['Template\'da qiymatni qo\'yish sintaksisi?', ['{{ qiymat }}','${qiymat}','<% qiymat %>','[qiymat]'],0,0,'Mustache.'],
  ['script ichida ref qiymatiga kirish uchun nima kerak?', ['.value','.get()','.data','Hech narsa'],0,1,'son.value.']]],
['Direktivlar: v-if, v-for, v-bind', `Direktivlar — "v-" bilan boshlanadigan maxsus atributlar.

~~~
<p v-if="yuklanmoqda">Yuklanmoqda...</p>
<ul>
  <li v-for="k in kurslar" :key="k.id">{{ k.nom }}</li>
</ul>
<img :src="rasm" :alt="nom">
~~~

v-if/v-else — shartli chizish. v-for — ro'yxat (key shart). :atribut (v-bind) — atributga dinamik qiymat beradi. v-show element'ni o'chirmay, faqat yashiradi (CSS display).`,
 [['Ro\'yxat chizish direktivi?', ['v-list','v-for','v-each','v-loop'],1,0,'v-for.'],
  [':src nimaning qisqa yozuvi?', ['v-bind:src','v-on:src','v-model:src','v-src'],0,0,'v-bind.'],
  ['v-if va v-show farqi?', ['Farqi yo\'q','v-if elementni DOM\'ga qo\'shadi/olib tashlaydi, v-show faqat yashiradi','v-show tezroq o\'chiradi','v-if faqat ro\'yxatda'],1,1,'DOM vs CSS.']]],
['Hodisalar va v-model', `v-model forma elementi bilan ma'lumotni ikki tomonlama bog'laydi.

~~~
<script setup>
import { ref } from 'vue';
const ism = ref('');
const yubor = () => alert('Salom, ' + ism.value);
</script>
<template>
  <input v-model="ism" placeholder="Ismingiz">
  <form @submit.prevent="yubor"><button>Yuborish</button></form>
</template>
~~~

@submit.prevent — preventDefault'ning qisqa yozuvi (modifikator). Boshqa modifikatorlar: .stop, .once, @keyup.enter.`,
 [['Ikki tomonlama bog\'lash direktivi?', ['v-model','v-two','v-sync','v-link'],0,0,'v-model.'],
  ['@submit.prevent nima qiladi?', ['Formani yuboradi va sahifani qayta yuklaydi','Standart yuborishni to\'xtatib, handler\'ni chaqiradi','Formani o\'chiradi','Hech narsa'],1,0,'.prevent modifikatori.'],
  ['@keyup.enter nimani bildiradi?', ['Har tugmada','Faqat Enter bosilganda','Enter bosilmaganda','Sichqoncha'],1,1,'Tugma modifikatori.']]],
['Computed va watch', `computed — boshqa reaktiv qiymatlardan hisoblanadigan qiymat; u keshlanadi va faqat bog'liqliklar o'zgarganda qayta hisoblanadi. watch esa o'zgarishga yon ta'sir bilan javob beradi.

~~~
import { ref, computed, watch } from 'vue';
const q = ref('');
const royxat = ref(['Vue', 'React', 'Node']);
const topilgan = computed(() => royxat.value.filter(x => x.toLowerCase().includes(q.value.toLowerCase())));
watch(q, (yangi) => console.log('Qidiruv:', yangi));
~~~

Qoida: qiymat hisoblash kerak bo'lsa — computed; so'rov yuborish yoki saqlash kabi ta'sir kerak bo'lsa — watch.`,
 [['Hosilaviy (hisoblanadigan) qiymat uchun nima ishlatiladi?', ['computed','watch','onMounted','emit'],0,0,'computed.'],
  ['computed qiymati qachon qayta hisoblanadi?', ['Har renderda','Bog\'liq reaktiv qiymat o\'zgarganda','Hech qachon','Har soniyada'],1,0,'Keshlanadi.'],
  ['Qidiruv matni o\'zgarganda serverga so\'rov yuborish uchun qaysi biri mos?', ['computed','watch','v-if','ref'],1,1,'Yon ta\'sir → watch.']]],
['Komponentlar: props va emit', `Komponentlar ota-bola bog'lanishiga ega: ota props orqali ma'lumot beradi, bola emit orqali hodisa yuboradi.

~~~
<!-- Karta.vue -->
<script setup>
defineProps({ nom: String });
const emit = defineEmits(['tanlandi']);
</script>
<template><div @click="emit('tanlandi', nom)">{{ nom }}</div></template>

<!-- Ota -->
<Karta nom="Vue" @tanlandi="n => tanlangan = n" />
~~~

Qoida: props pastga, hodisalar yuqoriga. Bola props'ni o'zgartirmaydi.`,
 [['Bola komponent otaga xabar berishi uchun nima ishlatadi?', ['props','emit','ref','v-if'],1,0,'emit.'],
  ['Props qaysi yo\'nalishda oqadi?', ['Bola → ota','Ota → bola','Ikkala tomonga','Global'],1,0,'Yuqoridan pastga.'],
  ['Bola props qiymatini to\'g\'ridan-to\'g\'ri o\'zgartirsa nima bo\'ladi?', ['Yaxshi amaliyot','Ogohlantirish beradi va tavsiya etilmaydi — emit ishlatish kerak','Ota ham o\'zgaradi','Hech narsa'],1,1,'Bir tomonlama ma\'lumot oqimi.']]],
['Hayotiy sikl va API so\'rovlari', `Hayotiy sikl hook'lari komponent hayotining muhim paytlarida kod ishga tushiradi. onMounted — komponent DOM'ga qo'yilgandan keyin; ma'lumot yuklash uchun eng ko'p ishlatiladi.

~~~
import { ref, onMounted } from 'vue';
const kurslar = ref([]);
const xato = ref('');
onMounted(async () => {
  try {
    const r = await fetch('/api/courses');
    if (!r.ok) throw new Error(r.status);
    kurslar.value = (await r.json()).courses;
  } catch (e) { xato.value = 'Yuklab bo\\'lmadi'; }
});
~~~

Yuklanmoqda va xato holatlarini ko'rsatishni unutmang. onUnmounted'da timer va obunalarni tozalang.`,
 [['Ma\'lumotni komponent paydo bo\'lganda yuklash uchun hook?', ['onMounted','onUnmounted','computed','watch'],0,0,'onMounted.'],
  ['Timer\'ni qayerda tozalash kerak?', ['onMounted','onUnmounted','template','computed'],1,0,'Komponent yo\'q qilinganda.'],
  ['Yuklash xatosida nima qilish to\'g\'ri?', ['Hech narsa','Foydalanuvchiga tushunarli xabar ko\'rsatish','Sahifani yopish','Cheksiz qayta urinish'],1,1,'Xato holati UX qismi.']]],
['Router va Pinia', `Vue Router sahifalar o'rtasida o'tishni boshqaradi: yo'llar komponentlarga bog'lanadi, <RouterLink> va <RouterView> ishlatiladi. Dinamik yo'l: /courses/:id → route.params.id.

Pinia — umumiy holat (state) do'koni: bir nechta komponent bir xil ma'lumotni ishlatganda qulay.

~~~
export const useUser = defineStore('user', () => {
  const ism = ref('');
  const kirdi = computed(() => !!ism.value);
  return { ism, kirdi };
});
~~~

Router guard (beforeEach) bilan tizimga kirmaganlarni yopiq sahifalardan qaytarish mumkin — lekin haqiqiy himoya serverda bo'lishi shart.`,
 [['Umumiy holat uchun Vue\'da tavsiya etiladigan kutubxona?', ['Pinia','jQuery','Lodash','Express'],0,0,'Pinia.'],
  ['<RouterView> nima qiladi?', ['Joriy yo\'l komponentini chizadi','Havola yaratadi','Ma\'lumot yuklaydi','Stil beradi'],0,0,'Yo\'lga mos komponent shu yerda chiziladi.'],
  ['Router guard bilan sahifani yopish nima uchun yetarli emas?', ['Sekin','Foydalanuvchi API\'ga to\'g\'ridan-to\'g\'ri murojaat qilishi mumkin; server ham tekshirishi shart','Vue qo\'llamaydi','Yetarli'],1,1,'Frontend himoyasi UX uchun.']]],
], practical: ['Amaliy ish: Vazifalar boshqaruvi', `Vue 3 (script setup) bilan ilova yarating:
1) Vazifa qo'shish formasi (v-model, @submit.prevent).
2) Ro'yxat (v-for + key), bajarildi belgisi, o'chirish.
3) computed: bajarilmagan vazifalar soni; filtr (hammasi/faol/bajarilgan).
4) Alohida TodoItem komponenti (props + emit).
5) Ro'yxatni watch orqali saqlash (ixtiyoriy).
Tayyor bo'lgach savollarga javob bering.`,
 [['Bajarilmagan vazifalar sonini qaysi usul bilan hisoblash to\'g\'ri?', ['computed','onMounted','emit','v-show'],0,1,'Hosilaviy qiymat.'],
  ['TodoItem o\'chirish tugmasi bosilganda ota ro\'yxatdan olib tashlashi uchun nima kerak?', ['Bola ro\'yxatni o\'zi o\'zgartiradi','Bola emit("o\'chir", id) yuboradi, ota o\'chiradi','Global window','Mumkin emas'],1,1,'Hodisalar yuqoriga.'],
  ['v-for da key sifatida nima ishlatiladi?', ['Indeks har doim','Noyob id','Tasodifiy son har renderda','Hech narsa'],1,1,'Barqaror noyob id.']] ] },
};
