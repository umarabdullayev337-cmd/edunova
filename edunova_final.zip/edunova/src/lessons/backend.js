// Backend kurslari: Node.js, JWT, DevOps
module.exports = {
'Node.js va Express: professional backend': { lessons: [
['Node.js nima va u qanday ishlaydi', `Node.js — brauzerdan tashqarida JavaScript ishlatish imkonini beruvchi muhit. U Chrome'ning V8 dvigateli ustiga qurilgan.

Node bitta oqimda (single thread) ishlaydi, lekin Event Loop tufayli minglab so'rovni bir vaqtda boshqara oladi. Sekin ishlar (fayl o'qish, tarmoq) fonda bajariladi, tayyor bo'lganda callback chaqiriladi.

~~~
console.log('Salom, Node!');
setTimeout(() => console.log('keyin'), 0);
console.log('oldin');
~~~

Natija: Salom, Node! → oldin → keyin. Chunki setTimeout callback'i Event Loop navbatiga tushadi.`,
 [['Node.js nimaga asoslangan JavaScript dvigatelida ishlaydi?', ['SpiderMonkey','V8','Chakra','Rhino'],1,0,'Node.js Google Chrome\'dagi V8 dvigatelidan foydalanadi.'],
  ['Node.js asosan nechta oqimda JavaScript kodini bajaradi?', ['Bitta asosiy oqimda','Har so\'rovga alohida oqimda','Doim 4 ta oqimda','Oqimlarsiz'],0,0,'JS kodi bitta asosiy oqimda bajariladi, og\'ir ishlar esa fonda.'],
  ['Yuqoridagi kodda "keyin" matni nega oxirida chiqadi?', ['Kod xato bilan ishlaydi','setTimeout callback\'i Event Loop navbatiga tushadi','console.log sekin','Node tartibni tasodifiy tanlaydi'],1,1,'Timer 0 ms bo\'lsa ham callback joriy sinxron kod tugagach bajariladi.']]],
['Modullar va NPM', `Node'da kod modullarga bo'linadi. Har bir fayl — alohida modul. CommonJS tizimida require() va module.exports ishlatiladi.

NPM — paketlar menejeri. npm init bilan loyiha yaratiladi, npm install express bilan paket o'rnatiladi. Paketlar node_modules papkasiga tushadi, ro'yxati esa package.json'da saqlanadi.

~~~
// math.js
module.exports = { sum: (a, b) => a + b };
// app.js
const { sum } = require('./math');
console.log(sum(2, 3)); // 5
~~~

node_modules papkasini Git'ga qo'shmang — .gitignore'ga yozing.`,
 [['Paketlar ro\'yxati qaysi faylda saqlanadi?', ['node_modules','package.json','index.js','.env'],1,0,'package.json bog\'liqliklarni (dependencies) saqlaydi.'],
  ['CommonJS\'da modulni ulash uchun nima ishlatiladi?', ['import()','require()','include()','using'],1,0,'require() — CommonJS usuli.'],
  ['node_modules papkasi nega Git\'ga qo\'shilmaydi?', ['Chunki u maxfiy','Chunki u katta va package.json orqali qayta tiklanadi','Git uni o\'qiy olmaydi','Chunki u kodni sekinlashtiradi'],1,1,'npm install uni package.json asosida qayta yaratadi.']]],
['Express bilan birinchi server', `Express — Node uchun eng mashhur veb-freymvork. Bir necha qatorda server yaratish mumkin.

~~~
const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Salom!'));
app.listen(3000, () => console.log('Server 3000-portda'));
~~~

req — kelgan so'rov, res — javob. app.get() GET so'rovlarga, app.post() POST so'rovlarga javob beradi. Port — serverning "eshigi" raqami.`,
 [['Express\'da javob yuborish uchun qaysi ob\'ekt ishlatiladi?', ['req','res','app','next'],1,0,'res ob\'ekti javobni qaytaradi.'],
  ['app.listen(3000) nimani bildiradi?', ['3000 ta so\'rovni qabul qiladi','Server 3000-portda so\'rovlarni tinglaydi','3 soniya kutadi','3000 ta foydalanuvchi'],1,0,'3000 — port raqami.'],
  ['Ro\'yxatdan o\'tish formasi ma\'lumotini qabul qilish uchun qaysi metod mos?', ['app.get','app.post','app.listen','app.use faqat'],1,1,'Ma\'lumot yuborish uchun odatda POST ishlatiladi.']]],
['Routing va parametrlar', `Route — manzil (URL) va metodning juftligi. Express'da dinamik parametrlar ":" bilan yoziladi.

~~~
app.get('/users/:id', (req, res) => {
  res.json({ id: req.params.id });
});
// /users/42 -> { "id": "42" }
// /search?q=node -> req.query.q
~~~

req.params — yo'l ichidagi qiymatlar, req.query — "?" dan keyingi qiymatlar, req.body — so'rov tanasi. Routerlarni express.Router() bilan alohida fayllarga ajratish kodni tartibli qiladi.`,
 [['/users/42 so\'rovida req.params.id qiymati nima?', ['42 (matn)','undefined','users','id'],0,0,'Parametrlar doim matn sifatida keladi.'],
  ['"/search?q=node" da "node" qaysi ob\'ektda bo\'ladi?', ['req.params','req.query','req.body','req.headers'],1,0,'"?" dan keyingi qismi req.query\'da.'],
  ['Parametr qiymati har doim qanday turda keladi?', ['Number','String','Boolean','Turi o\'zgaruvchan'],1,1,'URL parametrlari matn bo\'ladi; kerak bo\'lsa Number() bilan o\'giring.']]],
['Middleware', `Middleware — so'rov va javob orasida ishlaydigan funksiya. U req, res va next oladi. next() chaqirilsa, so'rov keyingi bosqichga o'tadi.

~~~
app.use(express.json()); // JSON tanani o'qiydi
app.use((req, res, next) => {
  console.log(req.method, req.url);
  next();
});
~~~

Tartib muhim: middleware route'dan oldin yozilishi kerak. Tekshiruv (autentifikatsiya), loglash, xatolarni boshqarish — hammasi middleware orqali.`,
 [['Middleware ichida so\'rovni keyingi bosqichga o\'tkazish uchun nima chaqiriladi?', ['res.end()','next()','app.listen()','return true'],1,0,'next() boshqaruvni keyingisiga beradi.'],
  ['express.json() nima qiladi?', ['JSON fayl yaratadi','So\'rov tanasidagi JSON\'ni req.body ga o\'qiydi','Javobni JSON qiladi','Ma\'lumotlar bazasini ulaydi'],1,0,'U body-parser vazifasini bajaradi.'],
  ['express.json() ni route\'lardan keyin yozsak nima bo\'ladi?', ['Hech narsa o\'zgarmaydi','Route\'larda req.body undefined bo\'ladi','Server ishga tushmaydi','Avtomatik tuzatiladi'],1,1,'Middleware tartibi muhim: u route\'dan oldin turishi kerak.']]],
['Xatolarni boshqarish', `Xatolar server qulab tushishiga sabab bo'lmasligi kerak. Express'da 4 ta parametrli maxsus middleware xatolarni ushlaydi.

~~~
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Ichki xatolik' });
});
~~~

Async funksiyalarda try/catch ishlating yoki wrapper yozing. HTTP statuslar: 200 OK, 201 yaratildi, 400 noto'g'ri so'rov, 401 kirish yo'q, 403 ruxsat yo'q, 404 topilmadi, 500 server xatosi. Foydalanuvchiga ichki xato tafsilotini ko'rsatmang.`,
 [['"Topilmadi" holati uchun qaysi status kod mos?', ['200','404','500','301'],1,0,'404 — resurs topilmadi.'],
  ['Express\'da xato ushlovchi middleware nechta parametr oladi?', ['2','3','4','1'],2,0,'(err, req, res, next) — 4 ta.'],
  ['Nega foydalanuvchiga xatoning to\'liq stack\'ini ko\'rsatmaslik kerak?', ['Chunki u uzun','Chunki u ichki tuzilma haqida ma\'lumot sizdiradi','Brauzer ko\'rsatmaydi','Hech qanday sabab yo\'q'],1,1,'Stack trace hujumchiga foydali ma\'lumot beradi.']]],
['Ma\'lumotlar bazasi bilan ishlash', `Server ma\'lumotni xotirada saqlasa, qayta ishga tushganda yo'qoladi. Shuning uchun ma'lumotlar bazasi kerak. MongoDB — hujjatlar (JSON ko'rinishida) saqlaydi, PostgreSQL esa jadvallar bilan ishlaydi.

Mongoose — MongoDB uchun kutubxona. U sxema (schema) orqali ma'lumot tuzilmasini belgilaydi.

~~~
const User = mongoose.model('User', new mongoose.Schema({
  name: { type: String, required: true },
  age: Number
}));
const u = await User.create({ name: 'Ali', age: 20 });
~~~

CRUD — Create, Read, Update, Delete: ma'lumot bilan asosiy to'rt amal.`,
 [['CRUD\'dagi "R" nimani bildiradi?', ['Remove','Read','Run','Rewrite'],1,0,'Read — o\'qish.'],
  ['Mongoose\'dagi schema nima uchun kerak?', ['Dizayn berish uchun','Ma\'lumot tuzilmasi va qoidalarini belgilash uchun','Serverni tezlashtirish uchun','Parolni shifrlash uchun'],1,0,'Sxema maydonlar turi va majburiyligini belgilaydi.'],
  ['Server xotirasida (massivda) saqlangan ma\'lumotlar qayta ishga tushganda nima bo\'ladi?', ['Saqlanib qoladi','Yo\'qoladi','Avtomatik arxivlanadi','Bazaga ko\'chadi'],1,1,'Xotira vaqtinchalik; doimiy saqlash uchun baza kerak.']]],
['Muhit o\'zgaruvchilari va deploy', `Parol, API kalit kabi maxfiy ma'lumotlarni kod ichida yozmang. Ular .env faylida saqlanadi va process.env orqali o'qiladi.

~~~
// .env
PORT=3000
JWT_SECRET=juda_maxfiy_kalit
// kodda
require('dotenv').config();
const port = process.env.PORT || 3000;
~~~

.env faylini Git'ga qo'shmang. Deploy — loyihani internetdagi serverga joylashtirish: Render, Railway yoki VPS. Productionda NODE_ENV=production o'rnating va jarayonni PM2 kabi vosita bilan kuzating.`,
 [['Maxfiy kalitlar qayerda saqlanishi kerak?', ['Kod ichida','.env faylida (Git\'ga qo\'shilmagan)','README.md da','Frontend kodida'],1,0,'.env va process.env.'],
  ['process.env nima?', ['Brauzer ob\'ekti','Muhit o\'zgaruvchilari ob\'ekti','Paketlar ro\'yxati','Xatolar jurnali'],1,0,'Operatsion tizim/muhit o\'zgaruvchilari.'],
  ['Kalit tasodifan GitHub\'ga chiqib ketsa, eng to\'g\'ri harakat qaysi?', ['Faylni o\'chirish kifoya','Kalitni darhol almashtirish (revoke)','Hech narsa qilmaslik','Repo nomini o\'zgartirish'],1,1,'Git tarixida qoladi, shuning uchun kalit yangilanishi shart.']]],
], practical: ['Amaliy ish: Vazifalar REST API', `Vazifalar (todo) uchun REST API yarating:
1) GET /todos — ro'yxat, POST /todos — yangi vazifa, PUT /todos/:id — yangilash, DELETE /todos/:id — o'chirish.
2) Bo'sh sarlavhada 400 statusi qaytaring.
3) Mavjud bo'lmagan id uchun 404 qaytaring.
4) Barcha xatolar uchun yagona error middleware yozing.
5) PORT qiymatini .env dan oling.
Kodni yozib, ishlashini tekshirgach, quyidagi savollarga javob bering.`,
 [['Vazifa yaratilganda (POST) qaysi status kod to\'g\'ri?', ['200','201','204','302'],1,1,'201 Created.'],
  ['Mavjud bo\'lmagan id so\'ralsa, API nima qaytarishi kerak?', ['500 va stack','404 va tushunarli xabar','200 va bo\'sh obyekt','Serverni to\'xtatish'],1,1,'404 Not Found.'],
  ['Quyidagilardan qaysi biri to\'g\'ri tartib?', ['Route\'lar → express.json() → error middleware','express.json() → route\'lar → error middleware','error middleware → route\'lar','Tartib ahamiyatsiz'],1,1,'Error middleware eng oxirida bo\'ladi.']] ] },

'JWT va xavfsiz autentifikatsiya': { lessons: [
['Autentifikatsiya va avtorizatsiya', `Autentifikatsiya — "Siz kimsiz?" degan savolga javob (login). Avtorizatsiya — "Sizga nima mumkin?" degan savolga javob (ruxsatlar).

Misol: tizimga parol bilan kirish — autentifikatsiya. Admin panelga faqat admin kira olishi — avtorizatsiya. Ikkalasi ham alohida tekshiriladi va ikkalasini ham serverda bajarish shart: brauzerdagi tekshiruvga ishonib bo'lmaydi.`,
 [['"Siz kimsiz?" savoliga javob qaysi tushunchaga tegishli?', ['Avtorizatsiya','Autentifikatsiya','Shifrlash','Loglash'],1,0,'Identifikatsiyani tekshirish.'],
  ['Faqat admin ko\'ra oladigan sahifa qaysi tushunchaga misol?', ['Avtorizatsiya','Autentifikatsiya','Hashing','CORS'],0,0,'Rolga qarab ruxsat berish.'],
  ['Nega ruxsat tekshiruvi faqat frontendda bo\'lishi yetarli emas?', ['Frontend sekin','Foydalanuvchi frontendni aylanib o\'tib API\'ga to\'g\'ridan-to\'g\'ri murojaat qilishi mumkin','Brauzer qo\'llab-quvvatlamaydi','Yetarli'],1,1,'Haqiqiy tekshiruv serverda bo\'lishi shart.']]],
['Parollarni xavfsiz saqlash', `Parolni hech qachon ochiq matnda saqlamang. Hash funksiyasi parolni qaytarib bo'lmaydigan qiymatga aylantiradi. Parol uchun bcrypt, scrypt yoki Argon2 ishlating — ular ataylab sekin ishlaydi.

Salt — har parolga qo'shiladigan tasodifiy qiymat; bir xil parollar ham turli hash beradi. bcrypt saltni o'zi yaratadi.

~~~
const hash = await bcrypt.hash(password, 12);
const ok = await bcrypt.compare(password, hash);
~~~

Oddiy SHA-256 parol uchun yaramaydi: u juda tez, shuning uchun brute-force oson bo'ladi.`,
 [['Parol bazada qanday saqlanishi kerak?', ['Ochiq matn','Shifrlangan (qaytariladigan)','bcrypt hash sifatida','Base64'],2,0,'Hash — qaytarib bo\'lmaydi.'],
  ['bcrypt.compare nima qiladi?', ['Hashni parolga aylantiradi','Kiritilgan parolni hash bilan solishtiradi','Yangi salt yaratadi','Parolni uzaytiradi'],1,0,'Parol va hash mosligini tekshiradi.'],
  ['Parol uchun nega oddiy SHA-256 yomon tanlov?', ['U juda sekin','U juda tez — brute-force osonlashadi','U salt qo\'shadi','U eskirgan emas'],1,1,'Parol hashlari ataylab sekin bo\'lishi kerak.']]],
['JWT tuzilishi', `JWT (JSON Web Token) uch qismdan iborat: header.payload.signature. Qismlar nuqta bilan ajratilgan va Base64URL bilan kodlangan.

Payload'da foydalanuvchi id'si, rol, amal qilish muddati (exp) bo'ladi. Signature esa token o'zgartirilmaganini kafolatlaydi: server maxfiy kalit bilan imzo yaratadi va tekshiradi.

Muhim: payload shifrlanmagan! Uni istalgan kishi o'qiy oladi. Shuning uchun parol yoki maxfiy ma'lumotni payload'ga yozmang.`,
 [['JWT nechta qismdan iborat?', ['2','3','4','5'],1,0,'Header, payload, signature.'],
  ['Signature nima uchun kerak?', ['Tokenni shifrlash uchun','Token o\'zgartirilmaganini tekshirish uchun','Tokenni qisqartirish uchun','Muddatni belgilash uchun'],1,0,'Imzo yaxlitlikni ta\'minlaydi.'],
  ['Payload ichiga foydalanuvchi parolini yozish nega xavfli?', ['Token uzayib ketadi','Payload shifrlanmagan, uni hamma o\'qiy oladi','JWT parol qabul qilmaydi','Server uni o\'chiradi'],1,1,'Base64 — kodlash, shifrlash emas.']]],
['Access va Refresh token', `Access token — qisqa muddatli (masalan, 15 daqiqa), har so'rovda yuboriladi. Agar o'g'irlansa, zarari qisqa vaqt bilan cheklanadi.

Refresh token — uzoq muddatli (masalan, 7 kun), faqat yangi access token olish uchun ishlatiladi. U httpOnly cookie'da saqlansa, JavaScript uni o'qiy olmaydi va XSS hujumidan himoyalanadi.

Oqim: login → (access + refresh) → access tugadi → refresh orqali yangisi olinadi → refresh ham tugasa, qaytadan login.`,
 [['Access token odatda qanday muddatga ega bo\'ladi?', ['Qisqa (daqiqalar)','1 yil','Hech qachon tugamaydi','Faqat 1 soniya'],0,0,'Qisqa muddat xavfni kamaytiradi.'],
  ['Refresh token nima uchun ishlatiladi?', ['Parolni tiklash uchun','Yangi access token olish uchun','Ma\'lumotni shifrlash uchun','Emailni tasdiqlash uchun'],1,0,'Access tugaganda yangilash uchun.'],
  ['Refresh token httpOnly cookie\'da saqlanishining asosiy foydasi?', ['Tezroq ishlaydi','JavaScript uni o\'qiy olmaydi (XSS\'dan himoya)','Hajmi kichrayadi','Muddatsiz bo\'ladi'],1,1,'httpOnly cookie\'ni document.cookie orqali o\'qib bo\'lmaydi.']]],
['Token rotation va bekor qilish', `Refresh token rotation — har yangilashda eski refresh token bekor qilinib, yangisi beriladi. Agar eski token qayta ishlatilsa, bu o'g'irlik belgisi: shu foydalanuvchining barcha sessiyalari yopiladi.

Serverda refresh tokenlarning faqat hash'ini saqlang (parol kabi). Logout paytida token bazadan o'chiriladi.

Access token'ni bekor qilish qiyin (stateless), shuning uchun u qisqa muddatli qilinadi.`,
 [['Rotation\'da har yangilashda nima sodir bo\'ladi?', ['Eski token davom etadi','Eski token bekor qilinib, yangisi beriladi','Hech narsa','Parol o\'zgaradi'],1,0,'Har token bir marta ishlatiladi.'],
  ['Refresh token bazada qanday saqlanishi yaxshi?', ['Ochiq matnda','Hash ko\'rinishida','Faqat brauzerda','Saqlanmaydi'],1,0,'Baza o\'g\'irlansa ham tokenlar ishlatilmaydi.'],
  ['Eski (allaqachon almashtirilgan) refresh token qayta ishlatilsa, eng to\'g\'ri reaksiya?', ['Jim o\'tkazib yuborish','Foydalanuvchining barcha sessiyalarini bekor qilish','Faqat xabar yozish','Yangi token berish'],1,1,'Reuse detection — o\'g\'irlik ehtimoli.']]],
['Rol asosidagi ruxsatlar (RBAC)', `RBAC — foydalanuvchiga rol (user, mentor, admin) beriladi, ruxsatlar rolga bog'lanadi. Express'da bu middleware bilan qilinadi.

~~~
const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Ruxsat yo\\'q' });
  }
  next();
};
app.delete('/courses/:id', auth, requireRole('admin'), handler);
~~~

401 — tizimga kirmagan, 403 — kirgan, lekin ruxsati yo'q. Rolni har doim tokendan yoki bazadan oling, so'rov tanasidan emas.`,
 [['Kirgan, lekin ruxsati yo\'q foydalanuvchiga qaysi status qaytariladi?', ['401','403','404','500'],1,0,'403 Forbidden.'],
  ['401 qachon qaytariladi?', ['Ruxsat yo\'q bo\'lsa','Foydalanuvchi aniqlanmasa (token yo\'q/yaroqsiz)','Sahifa topilmasa','Server o\'chiq bo\'lsa'],1,0,'Autentifikatsiya muvaffaqiyatsiz.'],
  ['Rolni foydalanuvchi yuborgan JSON tanasidan olish nega xato?', ['JSON sekin','Foydalanuvchi o\'zini "admin" deb yuborishi mumkin','Rol harflari katta','Hech qanday muammo yo\'q'],1,1,'Mijoz yuborgan ma\'lumotga ishonib bo\'lmaydi.']]],
['Rate limiting va brute-force himoyasi', `Brute-force — parolni ko'p marta sinab ko'rish hujumi. Himoya: rate limiting (bir IP'dan cheklangan so'rov), login urinishlarini sekinlashtirish, vaqtincha bloklash.

~~~
const limiter = rateLimit({ windowMs: 15*60*1000, max: 10 });
app.use('/auth/login', limiter);
~~~

Xato xabarini umumiy qiling: "Email yoki parol noto'g'ri" — qaysi biri xato ekanini oshkor qilmang (user enumeration'ning oldi olinadi).`,
 [['Rate limiting nimaga qarshi himoya beradi?', ['Brute-force va ortiqcha yuklama','SQL injection','Fayl o\'g\'irligi','Tarjima xatolari'],0,0,'So\'rovlar sonini cheklaydi.'],
  ['Login xatosi uchun qaysi xabar yaxshiroq?', ['"Bunday email yo\'q"','"Email yoki parol noto\'g\'ri"','"Parol xato"','Stack trace'],1,0,'Umumiy xabar ma\'lumot sizdirmaydi.'],
  ['"Bunday email topilmadi" xabari qanday zaiflikka olib keladi?', ['XSS','User enumeration (mavjud emaillarni aniqlash)','CSRF','Clickjacking'],1,1,'Hujumchi qaysi email ro\'yxatdan o\'tganini bilib oladi.']]],
['Himoya sarlavhalari: Helmet, CORS, cookie', `Helmet — Express'ga xavfsizlik HTTP sarlavhalarini qo'shadi (Content-Security-Policy va boshqalar). CORS — qaysi saytlar API'ga brauzer orqali murojaat qila olishini belgilaydi. Ruxsat ro'yxatini aniq yozing, "*" ni credentials bilan ishlatmang.

Cookie bayroqlari:
- httpOnly — JS o'qiy olmaydi
- secure — faqat HTTPS orqali
- sameSite — CSRF xavfini kamaytiradi

~~~
res.cookie('rt', token, { httpOnly: true, secure: true, sameSite: 'strict', maxAge: 7*864e5 });
~~~`,
 [['Cookie\'dagi secure bayrog\'i nimani anglatadi?', ['JS o\'qiy olmaydi','Faqat HTTPS orqali yuboriladi','Muddatsiz','Boshqa saytlarga yuboriladi'],1,0,'Shifrlanmagan HTTP orqali ketmaydi.'],
  ['Helmet nima qiladi?', ['Parolni hashlaydi','Xavfsizlik sarlavhalarini o\'rnatadi','Bazani ulaydi','Rasm siqadi'],1,0,'HTTP sarlavhalar orqali himoya qatlami beradi.'],
  ['sameSite=strict cookie asosan qaysi hujumga qarshi yordam beradi?', ['SQL injection','CSRF','Brute-force','DDoS'],1,1,'Boshqa saytdan kelgan so\'rovlarda cookie yuborilmaydi.']]],
], practical: ['Amaliy ish: Xavfsiz auth tizimi', `Quyidagi tizimni loyihalang va yozing:
1) POST /register — parol bcrypt (12 raund) bilan hashlanadi.
2) POST /login — access (15 daq) JSON'da, refresh (7 kun) httpOnly cookie'da qaytariladi.
3) POST /refresh — rotation: eski refresh bekor qilinadi.
4) GET /admin/stats — faqat admin roli uchun.
5) /login ga rate limit: 15 daqiqada 10 ta urinish.
Tayyor bo'lgach savollarga javob bering.`,
 [['Refresh endpointida eski token qayta kelsa nima qilinadi?', ['Qabul qilinadi','Rad etiladi va foydalanuvchi sessiyalari bekor qilinadi','Faqat log yoziladi','Access token uzaytiriladi'],1,1,'Reuse detection.'],
  ['/admin/stats uchun oddiy foydalanuvchiga qaysi status mos?', ['401','403','404','200'],1,1,'Kirgan, lekin ruxsat yo\'q → 403.'],
  ['Access tokenni localStorage\'da emas, xotirada saqlashning sababi?', ['Tezroq','XSS orqali o\'g\'irlash xavfi kamayadi','Muddatsiz bo\'ladi','Brauzer talab qiladi'],1,1,'localStorage JS orqali o\'qiladi.']] ] },

'DevOps asoslari: Docker va CI/CD': { lessons: [
['DevOps nima?', `DevOps — dasturlash (Dev) va operatsiyalar (Ops) jamoalarini birlashtiruvchi madaniyat va amaliyotlar to'plami. Maqsad: kodni tez, ishonchli va takrorlanadigan tarzda foydalanuvchiga yetkazish.

Asosiy g'oyalar: avtomatlashtirish, kichik va tez-tez relizlar, monitoring, "kod sifatida infratuzilma" (Infrastructure as Code). "Mening kompyuterimda ishlayapti" muammosini yo'qotish DevOps'ning asosiy vazifalaridan biri.`,
 [['DevOps maqsadi nima?', ['Faqat dizayn','Kodni tez va ishonchli yetkazish','Faqat test yozish','Jamoani kamaytirish'],1,0,'Yetkazib berishni tezlashtirish va ishonchli qilish.'],
  ['"Kod sifatida infratuzilma" nimani anglatadi?', ['Kodni chop etish','Serverlarni fayllar/kod orqali avtomatik sozlash','Kodni arxivlash','Dizayn yozish'],1,0,'Infratuzilma ham kod kabi versiyalanadi.'],
  ['Kichik va tez-tez relizlarning afzalligi?', ['Xato topish va qaytarish osonlashadi','Kod ko\'payadi','Testlar kerak bo\'lmaydi','Server kamayadi'],0,1,'Kichik o\'zgarish — kichik xavf.']]],
['Linux va terminal asoslari', `Serverlarning aksariyati Linux'da ishlaydi. Asosiy buyruqlar:

~~~
pwd            # joriy papka
ls -la         # fayllar ro'yxati
cd /var/log    # papkaga o'tish
cat file.txt   # faylni ko'rsatish
chmod 600 key  # ruxsatlar
ps aux | grep node   # jarayonlarni qidirish
~~~

"|" (pipe) bir buyruq natijasini keyingisiga uzatadi. chmod fayl ruxsatlarini o'zgartiradi: kalit fayllari faqat egasi o'qiy oladigan bo'lishi kerak. Doim ehtiyot bo'ling: sudo va rm -rf xavfli buyruqlar.`,
 [['Joriy papkani ko\'rsatuvchi buyruq?', ['ls','pwd','cd','cat'],1,0,'pwd — print working directory.'],
  ['"|" belgisi nima qiladi?', ['Faylni o\'chiradi','Bir buyruq chiqishini keyingisiga kirish qiladi','Izoh yozadi','Papka yaratadi'],1,0,'Pipe.'],
  ['Maxfiy SSH kalit fayli uchun qaysi ruxsat to\'g\'ri?', ['777','600','666','755'],1,1,'Faqat egasi o\'qiy olishi kerak.']]],
['Git va jamoaviy ish', `Git — kod tarixini saqlovchi tizim. Branch (tarmoq) alohida g'oya ustida ishlash imkonini beradi, main esa barqaror kodni saqlaydi.

~~~
git checkout -b feature/login
git add .
git commit -m "Login sahifasi qo'shildi"
git push origin feature/login
~~~

Keyin Pull Request ochiladi, jamoa kodni ko'rib chiqadi (code review) va main'ga qo'shadi (merge). Commit xabarlari aniq bo'lsin: nima va nega o'zgargani yozilsin.`,
 [['Yangi branch yaratish buyrug\'i?', ['git checkout -b nom','git new nom','git branch --delete','git init'],0,0,'checkout -b yaratadi va o\'tadi.'],
  ['Pull Request nima uchun kerak?', ['Kodni o\'chirish','O\'zgarishlarni ko\'rib chiqish va main\'ga qo\'shish uchun','Serverni o\'chirish','Paket o\'rnatish'],1,0,'Code review jarayoni.'],
  ['Nega to\'g\'ridan-to\'g\'ri main\'ga push qilish tavsiya etilmaydi?', ['Git ruxsat bermaydi','Ko\'rib chiqilmagan va testdan o\'tmagan kod barqaror shaxobchaga tushadi','Sekin','Branch yo\'qoladi'],1,1,'main himoyalangan bo\'lishi kerak.']]],
['Docker: konteynerlar', `Konteyner — ilova va uning barcha bog'liqliklarini bitta izolyatsiyalangan paketga o'raydi. Virtual mashinadan farqli, konteyner operatsion tizim yadrosini ulashadi, shuning uchun yengil va tez.

Image — konteyner shabloni (o'zgarmas), container — image'ning ishlayotgan nusxasi.

~~~
docker pull node:20-alpine
docker run -d -p 3000:3000 --name app myapp
docker ps
docker logs app
docker stop app
~~~

"-p 3000:3000" — kompyuterning 3000-portini konteynerning 3000-portiga ulaydi.`,
 [['Image va container farqi nima?', ['Farqi yo\'q','Image — shablon, container — uning ishlayotgan nusxasi','Container — shablon, image — ishlayotgan','Ikkalasi ham fayl turi'],1,0,'Image → container.'],
  ['Konteynerning VM\'dan asosiy afzalligi?', ['Yengil va tez ishga tushadi','Ko\'proq RAM oladi','Yadro alohida','Faqat Windows\'da'],0,0,'Yadro ulashiladi.'],
  ['"-p 8080:3000" nimani bildiradi?', ['Konteyner 8080 ga, host 3000 ga','Host\'ning 8080-porti konteynerning 3000-portiga yo\'naltiriladi','Ikki konteyner ulanadi','Port yopiladi'],1,1,'Format: host:konteyner.']]],
['Dockerfile yozish', `Dockerfile — image yaratish retsepti. Har bir buyruq yangi qatlam (layer) hosil qiladi va keshlanadi, shuning uchun kam o'zgaradigan qadamlarni oldinga qo'ying.

~~~
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
~~~

Avval faqat package.json nusxalanadi: kod o'zgarsa ham, bog'liqliklar qatlami keshdan olinadi va build tez bo'ladi. .dockerignore bilan node_modules va .env'ni image'ga kiritmang.`,
 [['Dockerfile\'da asosiy image qaysi buyruq bilan beriladi?', ['RUN','FROM','CMD','COPY'],1,0,'FROM boshlang\'ich image.'],
  ['CMD nima qiladi?', ['Image yig\'adi','Konteyner ishga tushganda bajariladigan buyruqni belgilaydi','Fayl nusxalaydi','Port ochadi'],1,0,'Ishga tushirish buyrug\'i.'],
  ['package.json avval, kod keyin nusxalanishining sababi?', ['Chiroyli','Layer keshi ishlashi va build tezlashishi','Docker talabi','Xavfsizlik uchun'],1,1,'Bog\'liqliklar qatlami o\'zgarmasa keshdan olinadi.']]],
['Docker Compose', `Ilova odatda bir nechta xizmatdan iborat: server, baza, kesh. Docker Compose ularni bitta YAML faylda tasvirlaydi va bitta buyruq bilan ishga tushiradi.

~~~
services:
  app:
    build: .
    ports: ["3000:3000"]
    environment:
      - MONGO_URL=mongodb://db:27017/app
    depends_on: [db]
  db:
    image: mongo:7
    volumes: [dbdata:/data/db]
volumes:
  dbdata:
~~~

docker compose up -d hammasini ishga tushiradi. Volume — ma'lumotni konteyner o'chsa ham saqlaydi. Xizmatlar bir-biriga nomi bilan murojaat qiladi (db).`,
 [['Compose konfiguratsiyasi qaysi formatda yoziladi?', ['XML','YAML','CSV','INI'],1,0,'docker-compose.yml.'],
  ['Volume nima uchun kerak?', ['Tezlik uchun','Ma\'lumotni konteyner o\'chganda ham saqlash uchun','Port ochish uchun','Log yozish uchun'],1,0,'Doimiy saqlash.'],
  ['Compose\'da app xizmati bazaga qanday murojaat qiladi?', ['localhost orqali','Xizmat nomi (db) orqali','IP topib','Murojaat qila olmaydi'],1,1,'Compose umumiy tarmoq yaratadi; nom DNS vazifasini bajaradi.']]],
['CI/CD: avtomatik testlash va deploy', `CI (Continuous Integration) — har o'zgarishda kod avtomatik yig'iladi va testlanadi. CD (Continuous Delivery/Deployment) — tayyor kod avtomatik muhitga joylanadi.

GitHub Actions misoli:

~~~
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm ci
      - run: npm test
~~~

Test muvaffaqiyatsiz bo'lsa, pipeline to'xtaydi va xato kod productionga chiqmaydi. Maxfiy qiymatlar uchun Secrets ishlating.`,
 [['CI\'dagi "I" nimani anglatadi?', ['Integration','Internet','Install','Interface'],0,0,'Continuous Integration.'],
  ['Pipeline\'da test yiqilsa nima bo\'lishi kerak?', ['Davom etib deploy qilinadi','To\'xtaydi, deploy qilinmaydi','Testlar o\'chiriladi','Hech narsa'],1,0,'Xato kodni to\'sish — CI maqsadi.'],
  ['Deploy uchun parol/kalitlarni workflow faylida ochiq yozish o\'rniga nima qilinadi?', ['Kommentga yoziladi','GitHub Secrets\'da saqlanadi','README\'ga qo\'yiladi','Image ichiga qo\'shiladi'],1,1,'Secrets shifrlangan holda saqlanadi.']]],
['Monitoring va loglar', `Deploy — ish tugashi emas. Ilovani kuzatish kerak: loglar (nima bo'ldi), metrikalar (CPU, xotira, so'rovlar soni) va alertlar (muammo bo'lganda xabar).

Health-check endpointi (/health) ilova tirikligini tekshiradi. Loglarni strukturali (JSON) yozing va maxfiy ma'lumot (parol, token) log'ga tushmasin.

Reliz muvaffaqiyatsiz chiqsa — rollback: oldingi barqaror versiyaga tezda qaytish. Shuning uchun image'larni versiya teglari bilan saqlang (latest emas).`,
 [['Health-check endpointi nima uchun?', ['Dizayn uchun','Ilova ishlayotganini tekshirish uchun','Parol uchun','Rasm yuklash uchun'],1,0,'Monitoring va balanslashtirgich ishlatadi.'],
  ['Rollback nima?', ['Yangi funksiya qo\'shish','Oldingi barqaror versiyaga qaytish','Serverni o\'chirish','Loglarni tozalash'],1,0,'Muammoli relizni bekor qilish.'],
  ['Nega productionda image\'ni faqat "latest" tegi bilan ishlatish xavfli?', ['Sekin','Aynan qaysi versiya ishlayotgani noaniq va rollback qiyin','Docker rad etadi','Hajmi katta'],1,1,'Aniq versiya tegi izlanuvchanlik beradi.']]],
], practical: ['Amaliy ish: Ilovani konteynerlash va CI', `Node.js ilovangiz uchun:
1) Dockerfile yozing (alpine image, npm ci, non-root foydalanuvchi bo'lsa yaxshi).
2) .dockerignore'ga node_modules va .env qo'shing.
3) docker-compose.yml: app + MongoDB, volume bilan.
4) GitHub Actions: push'da npm ci va npm test ishlasin.
5) /health endpointi qo'shing.
Tayyor bo'lgach savollarga javob bering.`,
 [['.env fayli image ichiga tushib qolsa qanday xavf bor?', ['Hech qanday','Image\'ni olgan har kim maxfiy kalitlarni ko\'ra oladi','Image tezlashadi','Faqat hajm oshadi'],1,1,'Maxfiy ma\'lumot image qatlamlarida qoladi.'],
  ['Mongo ma\'lumoti konteyner qayta yaratilganda yo\'qolmasligi uchun nima kerak?', ['Port','Volume','Yangi image','CMD'],1,1,'Named volume.'],
  ['CI\'da npm install o\'rniga npm ci tavsiya etilishining sababi?', ['Tezroq va package-lock.json bo\'yicha aniq (takrorlanadigan) o\'rnatadi','Kamroq xotira','Test yozadi','Ruxsat so\'ramaydi'],0,1,'npm ci lock-fayl bo\'yicha toza o\'rnatadi.']] ] },
};
