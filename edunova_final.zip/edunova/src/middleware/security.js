const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const config = require('../config');

// 1) Helmet — xavfsiz HTTP headerlar + qat'iy Content-Security-Policy
const helmetMw = helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      'font-src': ["'self'", 'https://fonts.gstatic.com'],
      // 'https:' — foydalanuvchilar profil rasmini tashqi URL orqali qo'yishi mumkin
      'img-src': ["'self'", 'data:', 'https:'],
      'connect-src': ["'self'"],
      'object-src': ["'none'"],
      'frame-ancestors': ["'none'"],
      'upgrade-insecure-requests': config.isProd ? [] : null,
    },
  },
  crossOriginEmbedderPolicy: false,
});

// 2) CORS — faqat CLIENT_ORIGIN (http://localhost:3000) ga ruxsat
const corsMw = cors({
  origin(origin, cb) {
    if (!origin || origin === config.origin) return cb(null, true);
    cb(new Error('CORS: bu manbaga ruxsat berilmagan'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
});

const limitMessage = (error) => ({ error, code: 'RATE_LIMIT' });

// 3) Rate limiting — /auth/login ga 1 daqiqada 5 ta so'rov
const loginLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: limitMessage("Juda ko'p urinish. Iltimos, 1 daqiqadan keyin qayta urinib ko'ring."),
});

// Ro'yxatdan o'tish / kod tasdiqlash / qayta yuborish uchun
const sensitiveLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: limitMessage("So'rovlar soni oshib ketdi. Bir daqiqadan keyin urinib ko'ring."),
});

// 4) DDoS ga qarshi asosiy himoya: umumiy limit + sekinlashtirish (slow-down)
const globalLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: limitMessage("Juda ko'p so'rov yuborildi. Birozdan keyin qayta urinib ko'ring."),
});

const speedLimiter = slowDown({
  windowMs: 60 * 1000,
  delayAfter: 80, // 80-so'rovdan keyin javoblar sekinlasha boshlaydi
  delayMs: (used) => Math.min((used - 80) * 40, 3000),
});

module.exports = { helmetMw, corsMw, loginLimiter, sensitiveLimiter, globalLimiter, speedLimiter };
