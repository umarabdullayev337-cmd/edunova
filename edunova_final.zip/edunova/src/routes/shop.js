const express = require('express');
const db = require('../db');
const { authenticate } = require('../middleware/auth');
const { wrap, courseView, isPremiumActive } = require('../utils/helpers');
const S = require('../shop');

const router = express.Router();
router.use(authenticate);

const catalog = (type) => (type === 'frame' ? S.FRAMES : S.PREMIUM_AVATARS);
// VIP (admin yoki faol premium status) uchun do'kondagi HAMMA narsa ochiq; oddiy foydalanuvchi faqat sotib olganini ko'radi
const owned = (u, type) => {
  if (isPremiumActive(u)) return catalog(type).map((x) => x.key);
  return type === 'frame' ? (u.ownedFrames = u.ownedFrames || []) : (u.ownedAvatars = u.ownedAvatars || []);
};

router.get('/', wrap(async (req, res) => {
  const u = req.user;
  const unlockedIds = u.unlockedCourses || [];
  const premiumCourses = db.data.courses.filter((c) => c.premium).map((c) => ({
    ...courseView(c),
    unlocked: isPremiumActive(u) || unlockedIds.includes(c.id),
    enrolled: !!db.findEnrollment(u.id, c.id),
  }));
  res.json({
    diamonds: u.diamonds || 0,
    isPremium: isPremiumActive(u),
    unlockPrice: S.COURSE_UNLOCK_PRICE,
    frames: S.FRAMES.map((f) => ({ ...f, owned: owned(u, 'frame').includes(f.key), equipped: u.frame === f.key })),
    avatars: S.PREMIUM_AVATARS.map((a) => ({ ...a, owned: owned(u, 'avatar').includes(a.key), equipped: u.avatar === `/img/premium/${a.key}.svg` })),
    premiumCourses,
    reward: S.REWARD,
  });
}));

router.post('/buy', wrap(async (req, res) => {
  const { type, key } = req.body || {};
  if (!['frame', 'avatar'].includes(type)) return res.status(400).json({ error: "Tur noto'g'ri" });
  const item = catalog(type).find((x) => x.key === key);
  if (!item) return res.status(404).json({ error: 'Mahsulot topilmadi' });
  const u = req.user;
  if (isPremiumActive(u)) return res.status(409).json({ error: 'VIP uchun hammasi allaqachon ochiq' });
  if (owned(u, type).includes(key)) return res.status(409).json({ error: 'Bu mahsulot sizda bor' });
  if ((u.diamonds || 0) < item.price) return res.status(402).json({ error: `Almaz yetarli emas (kerak: ${item.price})`, code: 'NO_FUNDS' });
  u.diamonds -= item.price;
  owned(u, type).push(key);
  db.save();
  res.json({ diamonds: u.diamonds });
}));

// type: 'frame' | 'avatar'; key = null bo'lsa ramka olib tashlanadi
router.post('/equip', wrap(async (req, res) => {
  const { type, key } = req.body || {};
  const u = req.user;
  if (type === 'frame') {
    if (key === null) u.frame = null;
    else if (owned(u, 'frame').includes(key)) u.frame = key;
    else return res.status(403).json({ error: 'Bu ramka sizda yo\'q' });
  } else if (type === 'avatar') {
    if (!owned(u, 'avatar').includes(key)) return res.status(403).json({ error: "Bu avatar sizda yo'q" });
    u.avatar = `/img/premium/${key}.svg`;
  } else return res.status(400).json({ error: "Tur noto'g'ri" });
  db.save();
  res.json({ ok: true });
}));

// Premium kursni almazga ochish va darhol yozilish
router.post('/unlock-course', wrap(async (req, res) => {
  const course = db.findCourse(req.body?.courseId);
  const u = req.user;
  if (isPremiumActive(u)) return res.status(409).json({ error: 'VIP uchun premium kurslar ochiq' });
  if (!course) return res.status(404).json({ error: 'Kurs topilmadi' });
  if (!course.premium) return res.status(400).json({ error: 'Bu kurs premium emas' });
  u.unlockedCourses = u.unlockedCourses || [];
  if (u.unlockedCourses.includes(course.id)) return res.status(409).json({ error: 'Bu kurs allaqachon ochilgan' });
  if ((u.diamonds || 0) < S.COURSE_UNLOCK_PRICE) return res.status(402).json({ error: `Almaz yetarli emas (kerak: ${S.COURSE_UNLOCK_PRICE})`, code: 'NO_FUNDS' });
  u.diamonds -= S.COURSE_UNLOCK_PRICE;
  u.unlockedCourses.push(course.id);
  if (!db.findEnrollment(u.id, course.id)) {
    db.data.enrollments.push({ id: db.id(), userId: u.id, courseId: course.id, completed: false, completedAt: null, createdAt: Date.now() });
  }
  db.save();
  res.json({ diamonds: u.diamonds, courseId: course.id });
}));

module.exports = router;
