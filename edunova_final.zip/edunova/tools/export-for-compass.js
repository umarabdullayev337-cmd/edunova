// data/db.json ni MongoDB Compass'ga import qilish uchun jadval-jadval JSON fayllarga ajratadi.
// Ishlatish:  node tools/export-for-compass.js
// Natija:     data/compass-export/users.json, courses.json, ...
// Eslatma: bu faqat KO'RISH uchun (bir tomonlama). Sayt baribir data/db.json bilan ishlaydi.
const fs = require('fs');
const path = require('path');

const src = path.join(__dirname, '..', 'data', 'db.json');
const out = path.join(__dirname, '..', 'data', 'compass-export');
if (!fs.existsSync(src)) { console.error('data/db.json topilmadi. Avval saytni bir marta ishga tushiring (npm start).'); process.exit(1); }

const db = JSON.parse(fs.readFileSync(src, 'utf8'));
const SECRET = /hash$|^verifyCodeHash$|^loginCodeHash$/i; // parol va kod hashlari eksport qilinmaydi
const SKIP = new Set(['refreshTokens']);

fs.mkdirSync(out, { recursive: true });
for (const [name, rows] of Object.entries(db)) {
  if (!Array.isArray(rows) || SKIP.has(name)) continue;
  const clean = rows.map((r) => {
    const o = { ...r };
    if (o.id) { o._id = o.id; delete o.id; } // Compass uchun _id
    for (const k of Object.keys(o)) if (SECRET.test(k)) delete o[k];
    return o;
  });
  fs.writeFileSync(path.join(out, `${name}.json`), JSON.stringify(clean, null, 2));
  console.log(`${name}.json  —  ${clean.length} ta yozuv`);
}
console.log(`\nTayyor: ${out}`);
