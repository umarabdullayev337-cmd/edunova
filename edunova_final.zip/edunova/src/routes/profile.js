const express = require('express');
const db = require('../db');
const { authenticate } = require('../middleware/auth');
const { wrap, publicUser, courseView, isPremiumActive } = require('../utils/helpers');
const { CATEGORIES, LEVELS } = require('./courses');
const L = require('../lessons');

const router = express.Router();

const GOALS = [
  { id: 'university', label: 'Chet el universitetiga kirish' },
  { id: 'job', label: 'IT kompaniyada ishga joylashish' },
  { id: 'freelance', label: 'Frilanser sifatida pul topish' },
  { id: 'startup', label: "O'z startapini boshlash" },
  { id: 'hobby', label: 'Shunchaki yangi ko\'nikma o\'rganish' },
];
const DAY_NAMES = ['Dushanba', 'Seshanba', 'Chorshanba', 'Payshanba', 'Juma', 'Shanba', 'Yakshanba'];
const MAX_AVATAR_BASE64 = 260_000; // taxminan ~190 KB rasm
const AVATAR_URL_RE = /^https:\/\/[^\s"'<>]{5,400}$/i;
const DATA_URI_RE = /^data:image\/(png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=]+$/;
const PRESET_AVATARS = ['astronaut', 'ninja', 'robot', 'fox', 'panda', 'wizard', 'gamer', 'dj', 'scientist', 'king', 'alien', 'cat'];

// ---------- GET /profile — himoyalangan: faqat access token bilan ochiladi ----------
router.get('/', authenticate, wrap(async (req, res) => {
  const courses = db.data.enrollments
    .filter((e) => e.userId === req.user.id)
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((e) => {
      const c = db.findCourse(e.courseId);
      if (!c) return null;
      const real = L.progressPercent(req.user.id, c, e);
      const progress = real !== null ? real : e.completed ? 100 : Math.min(90, Math.round(((Date.now() - e.createdAt) / (14 * 24 * 3600 * 1000)) * 90));
      return { ...courseView(c), enrolledAt: e.createdAt, completed: e.completed, completedAt: e.completedAt, progress, hasLessons: real !== null };
    })
    .filter(Boolean);
  res.json({ user: publicUser(req.user), courses, goals: GOALS, categories: CATEGORIES });
}));

router.patch('/', authenticate, wrap(async (req, res) => {
  const errors = [];
  if (req.body?.name !== undefined) {
    const name = String(req.body.name).trim().replace(/\s+/g, ' ');
    if (name.length < 2 || name.length > 60) errors.push("Ism 2–60 ta belgidan iborat bo'lishi kerak");
    else req.user.name = name;
  }
  if (req.body?.birthday !== undefined) {
    const b = String(req.body.birthday || '').trim();
    if (b === '') req.user.birthday = null;
    else if (!/^\d{4}-\d{2}-\d{2}$/.test(b) || Number.isNaN(new Date(b).getTime()) || new Date(b) > new Date()) {
      errors.push("Tug'ilgan sana noto'g'ri formatda");
    } else req.user.birthday = b;
  }
  if (req.body?.level !== undefined) {
    if (!LEVELS.includes(req.body.level)) errors.push("Daraja noto'g'ri tanlangan");
    else req.user.level = req.body.level;
  }
  if (errors.length) return res.status(400).json({ error: errors[0], errors });
  db.save();
  res.json({ user: publicUser(req.user) });
}));

// ---------- Profil rasmi: URL orqali yoki o'zi yuklagan rasm orqali ----------
router.put('/avatar', authenticate, wrap(async (req, res) => {
  const mode = req.body?.mode;
  if (mode === 'url') {
    const url = String(req.body?.value || '').trim();
    if (!AVATAR_URL_RE.test(url)) return res.status(400).json({ error: "Rasm manzili https:// bilan boshlanishi va to'g'ri bo'lishi kerak" });
    req.user.avatar = url;
  } else if (mode === 'upload') {
    const data = String(req.body?.value || '');
    if (data.length > MAX_AVATAR_BASE64) return res.status(413).json({ error: "Rasm hajmi juda katta (~190 KB dan kichik bo'lsin)" });
    if (!DATA_URI_RE.test(data)) return res.status(400).json({ error: 'Rasm formati qo\'llab-quvvatlanmaydi (PNG, JPEG, WEBP yoki GIF)' });
    req.user.avatar = data;
  } else if (mode === 'preset') {
    const key = String(req.body?.value || '');
    if (!PRESET_AVATARS.includes(key)) return res.status(400).json({ error: "Noma'lum avatar tanlandi" });
    req.user.avatar = `/img/presets/${key}.svg`;
  } else if (mode === 'clear') {
    req.user.avatar = null;
  } else {
    return res.status(400).json({ error: "mode 'url', 'upload', 'preset' yoki 'clear' bo'lishi kerak" });
  }
  db.save();
  res.json({ user: publicUser(req.user) });
}));

// ---------- Onboarding: qiziqishlar, maqsad, haftalik vaqt ----------
router.put('/onboarding', authenticate, wrap(async (req, res) => {
  const interests = (Array.isArray(req.body?.interests) ? req.body.interests : []).filter((x) => CATEGORIES.includes(x)).slice(0, 5);
  const goal = GOALS.find((g) => g.id === req.body?.goal)?.id;
  const level = LEVELS.includes(req.body?.level) ? req.body.level : null;
  const weeklyHours = Number(req.body?.weeklyHours);
  const startDate = String(req.body?.startDate || '').trim();

  if (!interests.length) return res.status(400).json({ error: "Kamida bitta yo'nalishni tanlang" });
  if (!goal) return res.status(400).json({ error: "Maqsadingizni tanlang" });
  if (!level) return res.status(400).json({ error: "Darajangizni tanlang" });
  if (!(weeklyHours >= 1 && weeklyHours <= 40)) return res.status(400).json({ error: "Haftalik vaqt 1–40 soat oralig'ida bo'lsin" });

  req.user.interests = interests;
  req.user.goal = goal;
  req.user.level = level;
  req.user.weeklyHours = Math.round(weeklyHours);
  req.user.startDate = /^\d{4}-\d{2}-\d{2}$/.test(startDate) ? startDate : new Date().toISOString().slice(0, 10);
  req.user.onboarded = true;
  db.save();
  res.json({ user: publicUser(req.user) });
}));

// ---------- Shaxsiy tavsiyalar va haftalik reja ----------
function scoreCourse(course, user) {
  let score = 0;
  if (user.interests?.includes(course.category)) score += 4;
  if (course.tags?.some((t) => user.interests?.some((i) => t.toLowerCase().includes(i.toLowerCase())))) score += 1;
  if (course.level === user.level) score += 2;
  else if (Math.abs(LEVELS.indexOf(course.level) - LEVELS.indexOf(user.level)) === 1) score += 1;
  const goalTags = {
    university: ['ingliz', 'ielts', 'xavfsizlik', 'ma\'lumotlar', 'algoritm'],
    job: ['backend', 'frontend', 'xavfsizlik', 'jwt', 'api'],
    freelance: ['frontend', 'dizayn', 'mobil', 'wordpress'],
    startup: ['backend', 'frontend', 'mobil', 'mahsulot'],
    hobby: [],
  };
  const kws = goalTags[user.goal] || [];
  const hay = `${course.title} ${course.description} ${(course.tags || []).join(' ')}`.toLowerCase();
  if (kws.some((k) => hay.includes(k))) score += 1;
  if (course.premium) score += 0.5;
  return score;
}

function buildWeeklyPlan(course, weeklyHours) {
  const hoursPerLesson = course.durationHours / course.lessons;
  const perDayHours = weeklyHours / 7;
  const lessonsPerDay = Math.max(1, Math.round(perDayHours / hoursPerLesson));
  let cursor = 1;
  const days = DAY_NAMES.map((name, i) => {
    if (i === 5) return { day: name, rest: true, lessons: 0, from: null, to: null, hours: 0 };
    if (cursor > course.lessons) return { day: name, rest: false, lessons: 0, from: null, to: null, hours: 0, done: true };
    const from = cursor;
    const to = Math.min(course.lessons, cursor + lessonsPerDay - 1);
    cursor = to + 1;
    return { day: name, rest: false, lessons: to - from + 1, from, to, hours: Math.round((to - from + 1) * hoursPerLesson * 10) / 10 };
  });
  return { courseId: course.id, courseTitle: course.title, weeklyHours, hoursPerLesson: Math.round(hoursPerLesson * 10) / 10, days };
}

router.get('/recommendations', authenticate, wrap(async (req, res) => {
  const u = req.user;
  if (!u.onboarded) {
    return res.json({ onboarded: false, goals: GOALS, categories: CATEGORIES, levels: LEVELS });
  }
  const enrolledIds = new Set(db.data.enrollments.filter((e) => e.userId === u.id).map((e) => e.courseId));
  const scored = db.data.courses
    .filter((c) => !enrolledIds.has(c.id))
    .map((c) => ({ course: c, score: scoreCourse(c, u) }))
    .sort((a, b) => b.score - a.score || b.course.createdAt - a.course.createdAt);

  const recommended = scored.slice(0, 6).map((x) => courseView(x.course));

  // Haftalik reja: davom etayotgan kursi bo'lsa o'sha, bo'lmasa eng mos tavsiya bo'yicha
  const inProgress = db.data.enrollments.find((e) => e.userId === u.id && !e.completed);
  const planCourse = inProgress ? db.findCourse(inProgress.courseId) : scored[0]?.course;
  const plan = planCourse ? buildWeeklyPlan(planCourse, u.weeklyHours || 6) : null;

  res.json({
    onboarded: true,
    isPremium: isPremiumActive(u),
    goal: GOALS.find((g) => g.id === u.goal) || null,
    recommended,
    plan,
  });
}));

module.exports = router;
module.exports.GOALS = GOALS;
