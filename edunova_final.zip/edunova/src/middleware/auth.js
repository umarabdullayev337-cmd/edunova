const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db');

// Faqat "Authorization: Bearer <access token>" bilan ochiladi.
function authenticate(req, res, next) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ error: 'Kirish uchun tizimga kiring', code: 'NO_TOKEN' });
  }
  try {
    const payload = jwt.verify(token, config.accessSecret);
    const user = db.findUser(payload.sub);
    if (!user) return res.status(401).json({ error: 'Foydalanuvchi topilmadi', code: 'INVALID_TOKEN' });
    req.user = user; // rol har safar bazadan olinadi — rol o'zgarsa darhol kuchga kiradi
    next();
  } catch (e) {
    const expired = e.name === 'TokenExpiredError';
    res.status(401).json({
      error: expired ? 'Token muddati tugagan' : 'Token yaroqsiz',
      code: expired ? 'TOKEN_EXPIRED' : 'INVALID_TOKEN',
    });
  }
}

// Token bo'lsa foydalanuvchini biriktiradi, bo'lmasa yoki yaroqsiz bo'lsa ham davom etadi (mehmon sifatida)
function optionalAuthenticate(req, res, next) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme !== 'Bearer' || !token) return next();
  try {
    const payload = jwt.verify(token, config.accessSecret);
    req.user = db.findUser(payload.sub) || null;
  } catch { /* mehmon sifatida davom etamiz */ }
  next();
}

const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ error: "Bu amal uchun ruxsatingiz yo'q", code: 'FORBIDDEN' });
  }
  next();
};

module.exports = { authenticate, optionalAuthenticate, requireRole };
