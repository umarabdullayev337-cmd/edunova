require('dotenv').config();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const isProd = process.env.NODE_ENV === 'production';
const rand = () => crypto.randomBytes(48).toString('hex');

// Development rejimida .env bo'lmasa, kalitlar data/.dev-secrets.json ga saqlanadi
// (shunda server qayta ishga tushganda sessiyalar bekor bo'lmaydi).
function devSecrets() {
  const file = path.join(__dirname, '..', 'data', '.dev-secrets.json');
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    const s = { JWT_ACCESS_SECRET: rand(), JWT_REFRESH_SECRET: rand() };
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(s));
    return s;
  }
}

let cachedDev = null;
function secret(name) {
  const v = process.env[name];
  if (v && v.length >= 32) return v;
  if (isProd) throw new Error(`${name} .env faylida kamida 32 belgi bo'lishi shart.`);
  cachedDev = cachedDev || devSecrets();
  return cachedDev[name];
}

module.exports = {
  isProd,
  port: Number(process.env.PORT) || 3000,
  origin: process.env.CLIENT_ORIGIN || 'http://localhost:3000',
  accessSecret: secret('JWT_ACCESS_SECRET'),
  refreshSecret: secret('JWT_REFRESH_SECRET'),
  accessTtl: '15m',
  accessTtlSeconds: 15 * 60,
  refreshTtl: '7d',
  refreshTtlMs: 7 * 24 * 60 * 60 * 1000,
  bcryptRounds: 12,
  smtp: {
    host: process.env.SMTP_HOST || '',
    port: Number(process.env.SMTP_PORT) || 587,
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    from: process.env.SMTP_FROM || (process.env.SMTP_USER ? `EduNova <${process.env.SMTP_USER}>` : 'EduNova <no-reply@edunova.uz>'),
  },
  admin: {
    name: process.env.ADMIN_NAME || 'EduNova Admin',
    email: (process.env.ADMIN_EMAIL || 'admin@edunova.uz').toLowerCase(),
    password: process.env.ADMIN_PASSWORD || 'Admin12345',
  },
};
