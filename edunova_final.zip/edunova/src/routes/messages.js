const express = require('express');
const db = require('../db');
const { wrap, messageView } = require('../utils/helpers');
const { sensitiveLimiter } = require('../middleware/security');
const { optionalAuthenticate } = require('../middleware/auth');

const router = express.Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// Oddiy foydalanuvchi (tizimga kirgan yoki mehmon) adminga xabar yubora oladi
router.post('/', sensitiveLimiter, optionalAuthenticate, wrap(async (req, res) => {
  const name = String(req.body?.name || (req.user ? req.user.name : '')).trim().replace(/\s+/g, ' ');
  const email = String(req.body?.email || (req.user ? req.user.email : '')).trim().toLowerCase();
  const subject = String(req.body?.subject || '').trim().replace(/\s+/g, ' ');
  const text = String(req.body?.text || '').trim().replace(/\s+/g, ' ');

  if (name.length < 2 || name.length > 60) return res.status(400).json({ error: "Ismingizni to'g'ri kiriting" });
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: "Email manzil noto'g'ri" });
  if (subject.length < 3 || subject.length > 100) return res.status(400).json({ error: "Mavzu 3–100 ta belgidan iborat bo'lishi kerak" });
  if (text.length < 10 || text.length > 1000) return res.status(400).json({ error: "Xabar 10–1000 ta belgidan iborat bo'lishi kerak" });

  const message = {
    id: db.id(),
    name, email, subject, text,
    userId: req.user ? req.user.id : null,
    status: 'open',
    reply: null,
    repliedAt: null,
    createdAt: Date.now(),
  };
  db.data.messages.push(message);
  db.save();
  res.status(201).json({ message: 'Xabaringiz yuborildi. Tez orada javob beramiz.', item: messageView(message) });
}));

module.exports = router;
