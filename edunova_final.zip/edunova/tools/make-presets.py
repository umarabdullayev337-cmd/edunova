# Foydalanuvchilar uchun tayyor, yorqin "premium" avatarlar (SVG).
# Ishga tushirish: python3 tools/make-presets.py
import os

OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'img', 'presets')
os.makedirs(OUT, exist_ok=True)

def wrap(name, c1, c2, inner):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" role="img" aria-label="{name}">
<defs>
  <linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></linearGradient>
  <clipPath id="c"><circle cx="100" cy="100" r="100"/></clipPath>
</defs>
<g clip-path="url(#c)">
  <rect width="200" height="200" fill="url(#g)"/>
  <circle cx="156" cy="38" r="62" fill="#fff" opacity=".10"/>
  <circle cx="30" cy="172" r="46" fill="#000" opacity=".08"/>
  {inner}
</g>
</svg>'''

PRESETS = {
  'astronaut': ('#2b2f78', '#5b5fd6', '''
    <path d="M70 60l-10-14M130 60l10-14" stroke="#F6EFDD" stroke-width="5" stroke-linecap="round"/>
    <circle cx="60" cy="44" r="5" fill="#F6EFDD"/><circle cx="140" cy="44" r="5" fill="#F6EFDD"/>
    <circle cx="100" cy="98" r="52" fill="#F6EFDD"/>
    <ellipse cx="100" cy="100" rx="34" ry="30" fill="#0D1230"/>
    <ellipse cx="88" cy="90" rx="9" ry="12" fill="#fff" opacity=".45"/>
    <path d="M58 152c0-20 18-32 42-32s42 12 42 32" fill="#F6EFDD"/>
    <rect x="86" y="140" width="28" height="10" rx="5" fill="#E9B44C"/>'''),
  'ninja': ('#1a1a2e', '#e14b4b', '''
    <path d="M56 72c0-30 20-46 44-46s44 16 44 46v28c0 26-20 44-44 44s-44-18-44-44Z" fill="#1c1f3a"/>
    <path d="M44 74h112" stroke="#e14b4b" stroke-width="11"/>
    <path d="M150 68l20 7-20 7Z" fill="#e14b4b"/>
    <ellipse cx="82" cy="98" rx="9" ry="6.5" fill="#F6EFDD"/><ellipse cx="118" cy="98" rx="9" ry="6.5" fill="#F6EFDD"/>
    <ellipse cx="82" cy="98" rx="3.5" ry="5" fill="#1c1f3a"/><ellipse cx="118" cy="98" rx="3.5" ry="5" fill="#1c1f3a"/>'''),
  'robot': ('#152a4a', '#5cc8e8', '''
    <rect x="97" y="38" width="6" height="18" fill="#CFE3F5"/><circle cx="100" cy="34" r="7" fill="#CFE3F5"/>
    <rect x="54" y="58" width="92" height="84" rx="22" fill="#CFE3F5"/>
    <rect x="54" y="58" width="92" height="84" rx="22" fill="none" stroke="#17203d" stroke-width="3" opacity=".3"/>
    <circle cx="80" cy="96" r="11" fill="#17203d"/><circle cx="120" cy="96" r="11" fill="#17203d"/>
    <circle cx="83" cy="93" r="3" fill="#5cc8e8"/><circle cx="123" cy="93" r="3" fill="#5cc8e8"/>
    <rect x="76" y="118" width="48" height="9" rx="4.5" fill="#17203d"/>
    <rect x="86" y="122" width="10" height="4" fill="#5cc8e8"/><rect x="104" y="122" width="10" height="4" fill="#5cc8e8"/>'''),
  'fox': ('#c6671a', '#ffce6b', '''
    <path d="M58 68 36 24 82 54Z" fill="#E8742E"/><path d="M142 68 164 24 118 54Z" fill="#E8742E"/>
    <path d="M62 62 50 36 78 54Z" fill="#fff"/><path d="M138 62 150 36 122 54Z" fill="#fff"/>
    <ellipse cx="100" cy="104" rx="54" ry="50" fill="#E8742E"/>
    <path d="M100 116c-17 0-26 9-26 19 0 11 11 15 26 15s26-4 26-15c0-10-9-19-26-19Z" fill="#fff"/>
    <circle cx="80" cy="96" r="7.5" fill="#20140c"/><circle cx="120" cy="96" r="7.5" fill="#20140c"/>
    <path d="M100 122l-7 9h14Z" fill="#20140c"/>'''),
  'panda': ('#1c6e63', '#6ee7d8', '''
    <circle cx="56" cy="54" r="22" fill="#20222c"/><circle cx="144" cy="54" r="22" fill="#20222c"/>
    <circle cx="100" cy="106" r="56" fill="#fff"/>
    <ellipse cx="76" cy="100" rx="17" ry="21" fill="#20222c"/><ellipse cx="124" cy="100" rx="17" ry="21" fill="#20222c"/>
    <circle cx="79" cy="100" r="5.5" fill="#fff"/><circle cx="127" cy="100" r="5.5" fill="#fff"/>
    <ellipse cx="100" cy="132" rx="9" ry="7" fill="#20222c"/>
    <path d="M86 140q14 10 28 0" stroke="#20222c" stroke-width="3" fill="none" stroke-linecap="round"/>'''),
  'wizard': ('#3a1f6b', '#a970f0', '''
    <path d="M100 16 154 94H46Z" fill="#6a4fd6"/>
    <path d="M100 16 154 94H46Z" fill="none" stroke="#8a4fd6" stroke-width="2"/>
    <circle cx="116" cy="46" r="3.2" fill="#F6D98A"/><circle cx="88" cy="62" r="2.4" fill="#F6D98A"/><circle cx="104" cy="74" r="2" fill="#F6D98A"/>
    <ellipse cx="100" cy="114" rx="38" ry="36" fill="#F6D3B3"/>
    <path d="M62 120c0 32 16 50 38 50s38-18 38-50" fill="#fff"/>
    <circle cx="87" cy="110" r="5.5" fill="#20140c"/><circle cx="113" cy="110" r="5.5" fill="#20140c"/>
    <path d="M78 122q22 14 44 0" stroke="#5a4a3a" stroke-width="3" fill="none" stroke-linecap="round"/>'''),
  'gamer': ('#0f3d2e', '#4fd69c', '''
    <path d="M54 102a46 46 0 0 1 92 0" fill="none" stroke="#17203d" stroke-width="11"/>
    <rect x="42" y="96" width="18" height="28" rx="7" fill="#17203d"/><rect x="140" y="96" width="18" height="28" rx="7" fill="#17203d"/>
    <ellipse cx="100" cy="108" rx="52" ry="48" fill="#F0C79A"/>
    <rect x="64" y="96" width="72" height="22" rx="9" fill="#101a30"/>
    <rect x="70" y="101" width="26" height="12" rx="3" fill="#5cd6f0"/><rect x="104" y="101" width="26" height="12" rx="3" fill="#5cd6f0"/>
    <path d="M148 124l16 10" stroke="#17203d" stroke-width="6" stroke-linecap="round"/>
    <path d="M90 142q10 8 20 0" stroke="#5a3a22" stroke-width="3.5" fill="none" stroke-linecap="round"/>'''),
  'dj': ('#4a1033', '#e0569a', '''
    <ellipse cx="100" cy="108" rx="52" ry="48" fill="#D9A374"/>
    <path d="M56 98a44 44 0 0 1 88 0" fill="none" stroke="#17203d" stroke-width="10"/>
    <circle cx="54" cy="106" r="17" fill="#17203d"/><circle cx="146" cy="106" r="17" fill="#17203d"/>
    <rect x="66" y="92" width="68" height="19" rx="9.5" fill="#17203d"/>
    <ellipse cx="88" cy="101" rx="13" ry="7" fill="#5a4fd6" opacity=".6"/><ellipse cx="114" cy="101" rx="13" ry="7" fill="#5a4fd6" opacity=".6"/>
    <path d="M82 134q18 16 36 0" stroke="#5a3a22" stroke-width="4" fill="none" stroke-linecap="round"/>'''),
  'scientist': ('#0d3d2c', '#2ec4a0', '''
    <ellipse cx="100" cy="110" rx="52" ry="48" fill="#F0C79A"/>
    <circle cx="80" cy="100" r="19" fill="none" stroke="#1c6e63" stroke-width="6"/><circle cx="120" cy="100" r="19" fill="none" stroke="#1c6e63" stroke-width="6"/>
    <path d="M98 100h4" stroke="#1c6e63" stroke-width="6"/>
    <circle cx="80" cy="100" r="6" fill="#17203d"/><circle cx="120" cy="100" r="6" fill="#17203d"/>
    <path d="M68 156c0-17 15-28 32-28s32 11 32 28" fill="#fff"/>
    <rect x="94" y="128" width="12" height="6" fill="#fff"/>
    <path d="M154 60l12 26-12 7-12-7Z" fill="#6ee7d8" opacity=".9"/><rect x="148" y="52" width="12" height="10" rx="2" fill="#6ee7d8" opacity=".9"/>'''),
  'king': ('#5a3a0a', '#f3c969', '''
    <ellipse cx="100" cy="114" rx="50" ry="48" fill="#F6D3B3"/>
    <path d="M52 78l17-36 21 22 10-28 10 28 21-22 17 36Z" fill="#F6D98A"/>
    <path d="M52 78l17-36 21 22 10-28 10 28 21-22 17 36Z" fill="none" stroke="#c7912a" stroke-width="2"/>
    <circle cx="69" cy="62" r="5.5" fill="#E14B4B"/><circle cx="100" cy="48" r="5.5" fill="#5cd6c0"/><circle cx="131" cy="62" r="5.5" fill="#E14B4B"/>
    <circle cx="83" cy="110" r="5.5" fill="#20140c"/><circle cx="117" cy="110" r="5.5" fill="#20140c"/>
    <path d="M86 128q14 10 28 0" stroke="#5a3a22" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M56 156c0-20 20-32 44-32s44 12 44 32" fill="#6a4fd6"/>'''),
  'alien': ('#0a3d1f', '#8fe06a', '''
    <path d="M100 18c-36 0-58 34-58 74 0 36 22 62 58 62s58-26 58-62c0-40-22-74-58-74Z" fill="#8fd65e"/>
    <ellipse cx="76" cy="96" rx="15" ry="22" fill="#12301d"/><ellipse cx="124" cy="96" rx="15" ry="22" fill="#12301d"/>
    <ellipse cx="80" cy="88" rx="4.5" ry="7" fill="#fff" opacity=".55"/><ellipse cx="128" cy="88" rx="4.5" ry="7" fill="#fff" opacity=".55"/>
    <path d="M88 136q12 9 24 0" stroke="#12301d" stroke-width="4" fill="none" stroke-linecap="round"/>'''),
  'cat': ('#7a2e1a', '#ff9a4d', '''
    <path d="M64 66 48 26 88 54Z" fill="#E8742E"/><path d="M136 66 152 26 112 54Z" fill="#E8742E"/>
    <path d="M68 60 58 36 84 54Z" fill="#F6C9C9"/><path d="M132 60 142 36 116 54Z" fill="#F6C9C9"/>
    <circle cx="100" cy="106" r="52" fill="#E8742E"/>
    <circle cx="81" cy="100" r="7.5" fill="#20140c"/><circle cx="119" cy="100" r="7.5" fill="#20140c"/>
    <path d="M100 114l-7 9h14Z" fill="#20140c"/>
    <path d="M38 112h32M38 123h27M130 112h32M135 123h27" stroke="#20140c" stroke-width="3" stroke-linecap="round"/>'''),
}

for key, (c1, c2, inner) in PRESETS.items():
    open(os.path.join(OUT, key + '.svg'), 'w', encoding='utf-8').write(wrap(key, c1, c2, inner))

print(len(PRESETS), 'ta tayyor avatar yaratildi:', ', '.join(PRESETS))
