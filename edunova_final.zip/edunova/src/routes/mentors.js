const express = require('express');
const db = require('../db');
const { wrap, mentorView, courseView } = require('../utils/helpers');

const router = express.Router();

router.get('/', wrap(async (req, res) => {
  const list = db.data.users.filter((u) => u.role === 'mentor').map(mentorView);
  res.json({ mentors: list });
}));

router.get('/:id', wrap(async (req, res) => {
  const m = db.findMentor(req.params.id);
  if (!m) return res.status(404).json({ error: 'Mentor topilmadi' });
  const courses = db.data.courses.filter((c) => c.mentorId === m.id).map(courseView);
  res.json({ mentor: mentorView(m), courses });
}));

module.exports = router;
