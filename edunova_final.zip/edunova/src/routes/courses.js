const express = require('express');
const db = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');
const { wrap, courseView, reviewView, isPremiumActive } = require('../utils/helpers');
const L = require('../lessons');

const router = express.Router();

const CATEGORIES = ['Backend', 'Frontend', 'Mobil', "Ma'lumotlar", 'Dizayn', 'Xavfsizlik', 'Tillar'];
const LEVELS = ["Boshlang'ich", "O'rta", 'Yuqori'];

const cleanArr = (v, max = 20, len = 140) =>
  (Array.isArray(v) ? v : [])
    .map((x) => String(x ?? '').trim().replace(/\s+/g, ' '))
    .filter(Boolean)
    .slice(0, max)
    .map((x) => x.slice(0, len));

function parseSyllabus(v) {
  if (!Array.isArray(v)) return [];
  return v.slice(0, 16).map((w, i) => ({
    week: Number.isFinite(Number(w?.week)) ? Math.round(Number(w.week)) : i + 1,
    title: String(w?.title ?? '').trim().slice(0, 100),
    topics: cleanArr(w?.topics, 10, 100),
  })).filter((w) => w.title);
}

function parseCourse(b = {}) {
  const errors = [];
  const str = (v) => String(v ?? '').trim().replace(/[ \t]+/g, ' ');
  const int = (v) => (Number.isFinite(Number(v)) && String(v).trim() !== '' ? Math.round(Number(v)) : NaN);

  const value = {
    title: str(b.title),
    description: str(b.description),
    category: str(b.category),
    level: str(b.level),
    price: int(b.price),
    durationHours: int(b.durationHours),
    lessons: int(b.lessons),
    instructor: str(b.instructor),
    premium: !!(b.premium === true || b.premium === 'true' || b.premium === 'on'),
    mentorId: b.mentorId ? str(b.mentorId) : null,
    tags: cleanArr(b.tags, 8, 24),
    whatYouWillLearn: cleanArr(b.whatYouWillLearn, 10, 120),
    requirements: cleanArr(b.requirements, 10, 120),
    syllabus: parseSyllabus(b.syllabus),
  };

  if (value.title.length < 3 || value.title.length > 80) errors.push("Kurs nomi 3–80 ta belgidan iborat bo'lishi kerak");
  if (value.description.length < 20 || value.description.length > 600) errors.push("Tavsif 20–600 ta belgidan iborat bo'lishi kerak");
  if (!CATEGORIES.includes(value.category)) errors.push("Yo'nalish noto'g'ri tanlangan");
  if (!LEVELS.includes(value.level)) errors.push("Daraja noto'g'ri tanlangan");
  if (!(value.price >= 0 && value.price <= 100000000)) errors.push("Narx 0 dan 100 000 000 gacha bo'lishi kerak");
  if (!(value.durationHours >= 1 && value.durationHours <= 500)) errors.push("Davomiylik 1–500 soat bo'lishi kerak");
  if (!(value.lessons >= 1 && value.lessons <= 500)) errors.push("Darslar soni 1–500 oralig'ida bo'lishi kerak");
  if (value.instructor.length < 2 || value.instructor.length > 60) errors.push("Mentor ismi 2–60 ta belgidan iborat bo'lishi kerak");
  if (value.mentorId && !db.findMentor(value.mentorId)) errors.push("Tanlangan mentor topilmadi");
  return { value, errors };
}

// ---------- Courses mini-API ----------

// GET /courses — barcha uchun ochiq
router.get('/', wrap(async (req, res) => {
  const list = [...db.data.courses].sort((a, b) => b.createdAt - a.createdAt).map(courseView);
  res.json({ courses: list, categories: CATEGORIES, levels: LEVELS });
}));

// Bosh sahifa uchun so'nggi sharhlar (barcha kurslar bo'yicha)
router.get('/reviews/recent', wrap(async (req, res) => {
  const list = [...db.data.reviews]
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 8)
    .map((r) => ({ ...reviewView(r), courseTitle: (db.findCourse(r.courseId) || {}).title || '' }));
  res.json({ reviews: list });
}));

router.get('/:id', wrap(async (req, res) => {
  const c = db.findCourse(req.params.id);
  if (!c) return res.status(404).json({ error: 'Kurs topilmadi' });
  res.json({ course: courseView(c) });
}));

// POST /courses — faqat admin
router.post('/', authenticate, requireRole('admin'), wrap(async (req, res) => {
  const { value, errors } = parseCourse(req.body);
  if (errors.length) return res.status(400).json({ error: errors[0], errors });
  const course = { id: db.id(), ...value, createdAt: Date.now() };
  db.data.courses.push(course);
  db.save();
  res.status(201).json({ course: courseView(course) });
}));

// PUT /courses/:id — admin
router.put('/:id', authenticate, requireRole('admin'), wrap(async (req, res) => {
  const course = db.findCourse(req.params.id);
  if (!course) return res.status(404).json({ error: 'Kurs topilmadi' });
  const { value, errors } = parseCourse(req.body);
  if (errors.length) return res.status(400).json({ error: errors[0], errors });
  Object.assign(course, value);
  L.syncCourse(course);
  db.save();
  res.json({ course: courseView(course) });
}));

// DELETE /courses/:id — admin
router.delete('/:id', authenticate, requireRole('admin'), wrap(async (req, res) => {
  const idx = db.data.courses.findIndex((c) => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Kurs topilmadi' });
  const [removed] = db.data.courses.splice(idx, 1);
  db.data.enrollments = db.data.enrollments.filter((e) => e.courseId !== removed.id);
  db.data.reviews = db.data.reviews.filter((r) => r.courseId !== removed.id);
  db.save();
  res.json({ message: "Kurs o'chirildi" });
}));

// Kursga yozilish / bekor qilish (tizimga kirgan foydalanuvchi)
router.post('/:id/enroll', authenticate, wrap(async (req, res) => {
  const course = db.findCourse(req.params.id);
  if (!course) return res.status(404).json({ error: 'Kurs topilmadi' });
  if (course.premium && !isPremiumActive(req.user) && !(req.user.unlockedCourses || []).includes(course.id)) {
    return res.status(403).json({ error: 'Bu premium kurs. Premium status yoki almaz bilan oching.', code: 'PREMIUM_REQUIRED' });
  }
  const exists = db.findEnrollment(req.user.id, course.id);
  if (exists) return res.status(409).json({ error: 'Siz bu kursga allaqachon yozilgansiz' });
  db.data.enrollments.push({ id: db.id(), userId: req.user.id, courseId: course.id, completed: false, completedAt: null, createdAt: Date.now() });
  db.save();
  res.status(201).json({ course: courseView(course) });
}));

router.delete('/:id/enroll', authenticate, wrap(async (req, res) => {
  const before = db.data.enrollments.length;
  db.data.enrollments = db.data.enrollments.filter((e) => !(e.userId === req.user.id && e.courseId === req.params.id));
  if (db.data.enrollments.length === before) return res.status(404).json({ error: 'Yozilish topilmadi' });
  db.save();
  res.json({ message: 'Kursdan chiqdingiz' });
}));

// Kursni yakunlash — sharh qoldirish va sertifikat olish shu orqali ochiladi
router.post('/:id/enroll/complete', authenticate, wrap(async (req, res) => {
  const e = db.findEnrollment(req.user.id, req.params.id);
  if (!e) return res.status(404).json({ error: 'Avval kursga yoziling' });
  if (!e.completed && L.getContent(db.findCourse(req.params.id))) {
    return res.status(400).json({ error: 'Kursni yakunlash uchun barcha darslar va amaliy ishni bajaring', code: 'LESSONS_REQUIRED' });
  }
  if (!e.completed) { e.completed = true; e.completedAt = Date.now(); db.save(); }
  res.json({ message: 'Tabriklaymiz! Kurs yakunlandi', enrollment: e });
}));

// ---------- Sharhlar (otzivlar) ----------
router.get('/:id/reviews', wrap(async (req, res) => {
  const course = db.findCourse(req.params.id);
  if (!course) return res.status(404).json({ error: 'Kurs topilmadi' });
  const list = db.data.reviews.filter((r) => r.courseId === course.id).sort((a, b) => b.createdAt - a.createdAt).map(reviewView);
  res.json({ reviews: list });
}));

router.post('/:id/reviews', authenticate, wrap(async (req, res) => {
  const course = db.findCourse(req.params.id);
  if (!course) return res.status(404).json({ error: 'Kurs topilmadi' });
  const e = db.findEnrollment(req.user.id, course.id);
  if (!e || !e.completed) {
    return res.status(403).json({ error: "Sharh qoldirish uchun avval kursni yakunlashingiz kerak", code: 'NOT_COMPLETED' });
  }
  const rating = Math.round(Number(req.body?.rating));
  const text = String(req.body?.text || '').trim().replace(/\s+/g, ' ');
  if (!(rating >= 1 && rating <= 5)) return res.status(400).json({ error: 'Baho 1 dan 5 gacha bo\'lishi kerak' });
  if (text.length < 10 || text.length > 500) return res.status(400).json({ error: "Sharh 10–500 ta belgidan iborat bo'lishi kerak" });

  let review = db.data.reviews.find((r) => r.userId === req.user.id && r.courseId === course.id);
  if (review) { review.rating = rating; review.text = text; review.updatedAt = Date.now(); }
  else {
    review = { id: db.id(), userId: req.user.id, courseId: course.id, rating, text, createdAt: Date.now() };
    db.data.reviews.push(review);
  }
  db.save();
  res.status(201).json({ review: reviewView(review) });
}));

router.delete('/:id/reviews/mine', authenticate, wrap(async (req, res) => {
  const before = db.data.reviews.length;
  db.data.reviews = db.data.reviews.filter((r) => !(r.userId === req.user.id && r.courseId === req.params.id));
  if (db.data.reviews.length === before) return res.status(404).json({ error: 'Sharh topilmadi' });
  db.save();
  res.json({ message: "Sharh o'chirildi" });
}));

module.exports = router;
module.exports.CATEGORIES = CATEGORIES;
module.exports.LEVELS = LEVELS;
