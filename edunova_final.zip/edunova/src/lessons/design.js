// Dizayn kurslari: Figma, Mahsulot dizayni
module.exports = {
'UI/UX dizayn: Figma bilan': { lessons: [
['UI va UX farqi', `UX (User Experience) — foydalanuvchi mahsulotdan foydalanish tajribasi: qulaylik, tushunarlilik, tezlik. UI (User Interface) — ko'rinish: ranglar, shriftlar, tugmalar, joylashuv.

Oddiy misol: uy qurilishida UX — xonalar joylashuvi va qulayligi, UI — devor rangi va mebel. Chiroyli, lekin chalkash ilova yaxshi UI, yomon UX'ga ega. Yaxshi dizayner ikkalasini uyg'unlashtiradi va doim foydalanuvchidan boshlaydi.`,
 [['Ilovadagi tugma rangi va shrifti qaysi sohaga kiradi?', ['UI','UX faqat','Backend','Marketing'],0,0,'Vizual ko\'rinish — UI.'],
  ['UX\'ning asosiy e\'tibori?', ['Foydalanuvchi tajribasi va qulaylik','Faqat ranglar','Kod yozish','Narx'],0,0,'Tajriba.'],
  ['Chiroyli, lekin to\'lov tugmasi topilmaydigan ilova qanday?', ['Yaxshi UI, yomon UX','Yaxshi UX','Yomon UI','Mukammal'],0,1,'Ko\'rinish yaxshi, tajriba yomon.']]],
['Figma muhiti va freymlar', `Figma — brauzerda ishlaydigan dizayn vositasi. Asosiy tushunchalar: Frame (ekran/konteyner), Layer (qatlam), Component (qayta ishlatiladigan element), Auto Layout (avtomatik joylashuv).

Frame yarating (F tugmasi), ekran o'lchamini tanlang: mobil uchun taxminan 390×844, veb uchun 1440 kenglik. Qatlamlarga aniq nom bering ("Button / Primary") — jamoada ishlash osonlashadi. Qisqa yo'llar: R — to'rtburchak, T — matn, Ctrl/Cmd+D — nusxa, Ctrl/Cmd+G — guruhlash.`,
 [['Ekran yoki konteyner yaratish uchun Figma\'da nima ishlatiladi?', ['Frame','Pen faqat','Comment','Plugin'],0,0,'Frame.'],
  ['Qatlamlarga aniq nom berishning foydasi?', ['Jamoada tartib va tezlik','Fayl kichrayadi','Rang o\'zgaradi','Foydasi yo\'q'],0,0,'Tushunarli fayl.'],
  ['Qayta ishlatiladigan element Figma\'da qanday ataladi?', ['Component','Sticker','Page','Export'],0,1,'Component.']]],
['Rang nazariyasi va kontrast', `Rang hissiyot beradi: ko'k — ishonch, yashil — o'sish, qizil — diqqat/xavf. Palitra: asosiy (brand) rang, ikkilamchi, neytrallar (kulrang) va holat ranglari (muvaffaqiyat, xato, ogohlantirish).

60-30-10 qoidasi: 60% asosiy fon, 30% ikkilamchi, 10% urg'u. Kontrast o'qiluvchanlik uchun hal qiluvchi: WCAG bo'yicha oddiy matn uchun kontrast nisbati kamida 4.5:1 bo'lishi kerak. Ma'noni faqat rang bilan bermang — rang ko'rmaydigan foydalanuvchilar ham bor (ikonka yoki matn qo'shing).`,
 [['WCAG bo\'yicha oddiy matn uchun minimal kontrast?', ['1.5:1','4.5:1','2:1','10:1'],1,0,'4.5:1.'],
  ['60-30-10 qoidasida 10% nima?', ['Urg\'u rangi','Fon','Matn','Chegara'],0,0,'Accent.'],
  ['Xatolikni faqat qizil rang bilan ko\'rsatish nega yomon?', ['Rang ko\'rmaydigan foydalanuvchilar sezmaydi — matn/ikonka ham kerak','Qizil yoqmaydi','Sekin','Muammo yo\'q'],0,1,'Inklyuzivlik.']]],
['Tipografiya', `Shrift tanlashda o'qiluvchanlik birinchi o'rinda. Ikkitadan ortiq shrift oilasini ishlatmang: sarlavha va matn uchun. Ierarxiya o'lcham, qalinlik va rang bilan beriladi.

Amaliy qoidalar: asosiy matn 16px atrofida, qator balandligi (line-height) shrift o'lchamining 1.4–1.6 baravari, qator uzunligi 50–75 belgi. Hizalash: matn uchun odatda chapga tekislash. Katta harflar bilan uzun matn yozmang — o'qish qiyinlashadi.`,
 [['Mobil ilovada asosiy matn odatda taxminan qancha o\'lchamda?', ['8px','16px','40px','4px'],1,0,'Taxminan 16px.'],
  ['Yaxshi qator balandligi taxminan qancha?', ['1.0','1.4–1.6','3.0','0.5'],1,0,'O\'qish qulayligi.'],
  ['Ierarxiya (sarlavha/matn farqi) qanday beriladi?', ['O\'lcham, qalinlik va rang bilan','Faqat tasodifiy','Hamma narsani bir xil qilib','Faqat animatsiya'],0,1,'Vizual ierarxiya.']]],
['Maket: Grid, bo\'shliq va Auto Layout', `Tartibli maket — grid va bo'shliq (spacing) tizimiga asoslanadi. 8px tizimi: barcha oraliq va o'lchamlar 8 ning karralisi (8, 16, 24, 32). Bu izchillik beradi.

Auto Layout elementlarni avtomatik joylaydi: matn uzaysa, tugma ham kengayadi. Padding (ichki bo'shliq), gap (elementlar orasi), hizalash sozlanadi. Bo'sh joy (white space) — kamchilik emas, u kontentni "nafas oldiradi" va asosiy narsaga e'tiborni qaratadi.`,
 [['8px tizimi nimani anglatadi?', ['Barcha o\'lchamlar 8 ning karralisi','Faqat 8 ta element','8 ta rang','8 ta shrift'],0,0,'Izchillik.'],
  ['Auto Layout\'ning foydasi?', ['Kontent o\'zgarsa elementlar o\'lchami avtomatik moslashadi','Rangni o\'zgartiradi','Kod yozadi','Faylni o\'chiradi'],0,0,'Moslashuvchan komponentlar.'],
  ['Bo\'sh joy (white space) haqida to\'g\'ri fikr?', ['U ortiqcha, to\'ldirish kerak','U kontentni o\'qishga qulay qiladi va e\'tiborni qaratadi','Faqat reklama uchun','Hech ahamiyati yo\'q'],1,1,'Nafas oladigan dizayn.']]],
['Komponentlar va Design System', `Komponent — bir marta yaratilib ko'p joyda ishlatiladigan element (tugma, input). Asosiy komponent (main) o'zgarsa, barcha nusxalar (instance) yangilanadi.

Variants bir komponentning holatlarini birlashtiradi: Default, Hover, Disabled, Error. Design System — komponentlar, ranglar, shriftlar va qoidalar to'plami; mahsulotning izchil ko'rinishini va jamoaning tezligini ta'minlaydi.

Tokenlar (masalan, color/primary, space/16) qiymatlarni nom bilan boshqaradi: rang o'zgarsa, bitta joyda o'zgartirasiz.`,
 [['Asosiy komponent o\'zgarsa, nusxalar (instance) nima bo\'ladi?', ['Yangilanadi','O\'zgarmaydi','O\'chadi','Nusxalanadi'],0,0,'Bog\'langan.'],
  ['Variants nima uchun?', ['Bir komponentning turli holatlarini boshqarish uchun','Fayl hajmi uchun','Izoh','Eksport'],0,0,'Holatlar.'],
  ['Design token\'ning afzalligi?', ['Qiymatni bir joyda o\'zgartirib, hamma joyda yangilash','Fayl o\'chadi','Animatsiya','Shrift almashadi'],0,1,'Markazlashgan boshqaruv.']]],
['Prototip va interaksiya', `Prototip — statik ekranlarni bog'lab, ilova qanday ishlashini ko'rsatadi. Figma'da Prototype rejimida ekranlar orasiga oqim (flow) chiziladi: trigger (bosish), harakat (navigate) va animatsiya (smart animate).

Prototipning vazifasi — kod yozishdan oldin g'oyani sinash. Foydalanuvchiga ko'rsatib, qaerda adashishini kuzating. Mikro-animatsiyalar (tugma bosilishi, yuklanish) qisqa (200–400 ms) va maqsadli bo'lsin — bezak uchun emas, holatni tushuntirish uchun.`,
 [['Prototipning asosiy maqsadi?', ['Kodsiz g\'oyani sinash','Rasm chizish','Yakuniy mahsulot','Reklama'],0,0,'Erta sinov.'],
  ['Mikro-animatsiya uchun mos davomiylik?', ['200–400 ms','5 soniya','0 ms','30 soniya'],0,0,'Qisqa.'],
  ['Prototip ustida foydalanuvchini kuzatganda nimaga e\'tibor beriladi?', ['Qaerda adashishi yoki ikkilanishi','Faqat tez bosishi','Ranglarni tanlashi','Hech narsaga'],0,1,'Usability muammolari.']]],
['Topshirish (handoff) va hamkorlik', `Dizayn tayyor bo'lgach dasturchiga topshiriladi. Figma Dev Mode o'lchamlar, ranglar va CSS ma'lumotini ko'rsatadi. Eksport: rasmlar PNG/JPG, ikonkalar SVG formatda; @1x, @2x, @3x masshtablar.

Izoh (comment) bilan jamoa fikr bildiradi. Versiya tarixi o'zgarishlarni saqlaydi. Yaxshi handoff: qatlamlar tartibli nomlangan, komponentlar ishlatilgan, barcha holatlar (xato, bo'sh, yuklanmoqda) ko'rsatilgan, dizayn va kod orasida kelishuv bor.`,
 [['Ikonkalar uchun eng yaxshi eksport formati?', ['SVG','JPG','BMP','GIF'],0,0,'Vektor, har masshtabda aniq.'],
  ['Dev Mode kimga foydali?', ['Dasturchilarga o\'lcham va CSS ko\'rish uchun','Faqat marketologlarga','Mijozga','Hech kimga'],0,0,'Handoff.'],
  ['Handoff\'da nega "xato", "bo\'sh" va "yuklanmoqda" holatlari ham beriladi?', ['Dasturchi ularni o\'zi taxmin qilmasligi uchun','Hajm to\'ldirish','Majburiy emas','Chiroyli'],0,1,'Barcha holatlar aniq bo\'lishi kerak.']]],
], practical: ['Amaliy ish: Mobil ilova ekranlari', `Kitob o'qish ilovasi uchun 3 ta ekran dizayn qiling:
1) Bosh sahifa (qidiruv, kategoriyalar, kitoblar ro'yxati).
2) Kitob tafsilotlari (muqova, tavsif, "O'qish" tugmasi).
3) Profil.
Talablar: 390×844 frame, 8px tizimi, kontrast ≥ 4.5:1, kamida 3 ta komponent (tugma, karta, input), Auto Layout, ekranlar orasida prototip.
Tayyor bo'lgach savollarga javob bering.`,
 [['Tugma matni va foni kontrasti 3:1 chiqdi. Nima qilish kerak?', ['Kontrastni 4.5:1 dan yuqori qilish uchun ranglarni tuzatish','Qoldirish','Shriftni kichraytirish','Rangni ochroq qilish'],0,1,'WCAG talabi.'],
  ['Kitob kartasi 10 joyda ishlatiladi. Eng to\'g\'ri yondashuv?', ['Har safar nusxalab yopishtirish','Component qilib instance ishlatish','Rasm sifatida joylash','Qo\'lda chizish'],1,1,'Komponent.'],
  ['Qidiruv natijasi topilmasa qanday ekran kerak?', ['Bo\'sh holat (empty state) tushuntirish va taklif bilan','Hech narsa','Qora ekran','Xato kodi'],0,1,'UX: bo\'sh holat ham dizayn qilinadi.']] ] },

'Mahsulot dizayni: 0 dan 1 gacha': { lessons: [
['Mahsulot dizayni nima', `Mahsulot dizayni — g'oyadan tayyor mahsulotgacha foydalanuvchi muammosini hal qilish jarayoni. Faqat ko'rinish emas: muammoni tushunish, yechim topish, sinash va takomillashtirish.

"0 dan 1 gacha" — bo'sh joydan birinchi ishlaydigan mahsulotgacha yo'l. Asosiy savollar: Kim uchun? Qanday muammoni hal qiladi? Nega hozirgi yechimlar yetarli emas? Mahsulot dizayneri biznes maqsadi, foydalanuvchi ehtiyoji va texnik imkoniyatlarni muvozanatda ushlaydi.`,
 [['Mahsulot dizaynining boshlanish nuqtasi nima bo\'lishi kerak?', ['Foydalanuvchi muammosi','Rang tanlash','Logotip','Reklama'],0,0,'Muammodan boshlanadi.'],
  ['"0 dan 1 gacha" nimani bildiradi?', ['Bo\'sh joydan birinchi ishlaydigan mahsulotgacha','1 ta foydalanuvchi','1 ta ekran','1 ta rang'],0,0,'Yangi mahsulot yaratish.'],
  ['Mahsulot dizayneri qaysi uch narsani muvozanatda ushlaydi?', ['Foydalanuvchi ehtiyoji, biznes maqsadi, texnik imkoniyat','Rang, shrift, logotip','Narx, reklama, aksiya','Faqat estetika'],0,1,'Uch doira kesishuvi.']]],
['Foydalanuvchi tadqiqoti', `Taxmin emas, dalil kerak. Intervyu (sifat) va so'rovnoma (miqdor) — asosiy usullar. Yaxshi intervyu savollari ochiq bo'ladi: "Oxirgi marta bu muammoga qachon duch keldingiz? Nima qildingiz?" — "Bu ilova sizga yoqadimi?" kabi yetaklovchi savollardan qoching.

Odamlar nima deyishi va nima qilishi farq qiladi: kelajak haqidagi fikrdan ko'ra o'tmishdagi xatti-harakat ishonchliroq. Natijalarni umumiy qonuniyatlarga (insight) aylantiring.`,
 [['Qaysi savol yaxshi intervyu savoli?', ['"Oxirgi marta bu muammoga qachon duch keldingiz?"','"Bu ilova yoqadimi?"','"Siz ham shunday deb o\'ylaysizmi?"','"Bizning g\'oya ajoyibmi?"'],0,0,'Ochiq va xatti-harakatga qaratilgan.'],
  ['So\'rovnoma qaysi turdagi ma\'lumot beradi?', ['Miqdoriy','Faqat sifat','Hech qanday','Faqat vizual'],0,0,'Ko\'p odamdan raqamli.'],
  ['Nega o\'tmishdagi xatti-harakat haqida so\'rash ishonchliroq?', ['Odamlar kelajak haqida ko\'pincha noto\'g\'ri taxmin qiladi','U tezroq','Arzonroq','Farqi yo\'q'],0,1,'Aytish va qilish farqi.']]],
['Muammoni aniqlash: persona va JTBD', `Persona — maqsadli foydalanuvchining tadqiqotga asoslangan namunaviy portreti (ismi, maqsadi, og'riqli nuqtalari). Faqat demografiya emas — xulq va motivatsiya muhim.

Jobs To Be Done (JTBD): odamlar mahsulotni "ish"ni bajarish uchun "yollaydi". Format: "Qachonki [vaziyat], men [harakat] qilishni xohlayman, shunda [natija]". Masalan: "Imtihondan oldin qisqa vaqtim bo'lganda, men asosiy mavzularni tez takrorlashni xohlayman, shunda ishonch bilan kirishim mumkin."

Muammo bayonoti aniq bo'lsa, yechimlar ham aniq bo'ladi.`,
 [['JTBD formatida qaysi qism "vaziyat" ni bildiradi?', ['Qachonki ...','Men xohlayman ...','Shunda ...','Narx'],0,0,'Kontekst.'],
  ['Persona nimaga asoslanishi kerak?', ['Tadqiqot ma\'lumotlariga','Tasodifiy fikrga','Dizaynerning didiga','Raqobatchi ismiga'],0,0,'Haqiqiy ma\'lumot.'],
  ['"25 yoshli erkak, Toshkentda yashaydi" — yaxshi persona uchun yetarlimi?', ['Yo\'q, maqsad, xulq va og\'riqli nuqtalar kerak','Ha','Faqat yosh','Faqat shahar'],0,1,'Demografiya yetarli emas.']]],
['G\'oyalar generatsiyasi va MVP', `Ko'p g'oya yig'ing, keyin tanlang. Usullar: brainstorming, Crazy 8s (8 daqiqada 8 eskiz). Tanlash mezonlari: foydalanuvchi qiymati, bajarish osonligi, biznes ta'siri.

MVP (Minimum Viable Product) — qiymat beruvchi eng kichik versiya. Maqsad — ko'p narsa qurish emas, gipotezani minimal xarajat bilan sinash. MVP'ga faqat asosiy muammoni hal qiluvchi funksiyalarni kiriting. "Yaxshi bo'lardi" funksiyalar keyinga qoladi.`,
 [['MVP nima?', ['Qiymat beruvchi eng kichik versiya','Eng to\'liq mahsulot','Reklama','Logotip'],0,0,'Minimum Viable Product.'],
  ['Crazy 8s nima?', ['8 daqiqada 8 xil g\'oya eskizi','8 kunlik reja','8 ta ekran','8 ta test'],0,0,'Tez g\'oya mashqi.'],
  ['MVP\'ga qaysi funksiya kiritilmaydi?', ['"Yaxshi bo\'lardi" turidagi qo\'shimcha funksiyalar','Asosiy muammoni hal qiluvchi funksiya','Kirish','Asosiy oqim'],0,1,'Ustuvorlashtirish.']]],
['Foydalanuvchi oqimi va wireframe', `User flow — foydalanuvchi maqsadga erishish uchun bosadigan qadamlar xaritasi (kirish → qidirish → tanlash → to'lov). Eng qisqa va tushunarli yo'lni izlang: har ortiqcha qadam foydalanuvchining bir qismini yo'qotadi.

Wireframe — rangsiz, soddalashtirilgan ekran eskizi: faqat tuzilma va kontent joylashuvi. Maqsad — vizual bezakdan chalg'imasdan mantiqni tekshirish. Avval qog'ozda yoki kulrang bloklarda chizing, keyin vizual dizaynga o'ting.`,
 [['Wireframe\'da nimaga e\'tibor beriladi?', ['Tuzilma va joylashuv','Rang va soya','Animatsiya','Logotip'],0,0,'Mantiq.'],
  ['User flow nima?', ['Foydalanuvchi qadamlari xaritasi','Rang palitrasi','Server sxemasi','Reklama rejasi'],0,0,'Qadamlar ketma-ketligi.'],
  ['Ro\'yxatdan o\'tishda forma maydonlarini 10 tadan 4 taga kamaytirish nimaga olib kelishi mumkin?', ['Konversiya (yakunlaganlar)ning oshishiga','Pasayishiga','Hech narsaga','Xatolarga'],0,1,'Ishqalanish kamayadi.']]],
['Foydalanuvchi sinovi (usability testing)', `Prototipni 5 nafar foydalanuvchida sinash ko'pchilik usability muammolarining katta qismini ochib beradi. Jarayon: vazifa bering ("Kurs sotib oling"), yordam bermang, ovoz chiqarib fikrlashni so'rang ("think aloud"), kuzating va yozib boring.

Nimaga e'tibor: vazifani bajara oldimi, qancha vaqt ketdi, qayerda ikkilandi. Foydalanuvchini aybdor qilmang — adashsa, dizayn aybdor. Topilgan muammolarni jiddiyligi bo'yicha tartiblang va avval eng muhimini tuzating.`,
 [['Testda foydalanuvchi adashsa, kim aybdor deb hisoblanadi?', ['Dizayn','Foydalanuvchi','Tasodif','Kompyuter'],0,0,'Muammo dizaynda.'],
  ['"Think aloud" nimani anglatadi?', ['Foydalanuvchi o\'ylarini ovoz chiqarib aytadi','Jim ishlaydi','Test kompyuterda','Yozma hisobot'],0,0,'Fikrlash jarayonini ochadi.'],
  ['Test paytida foydalanuvchiga yo\'l-yo\'riq ko\'rsatish nega xato?', ['Haqiqiy foydalanishni buzadi — aslida yordam bo\'lmaydi','Sekin','Qimmat','Xato emas'],0,1,'Tabiiy xatti-harakatni ko\'rish kerak.']]],
['Metrikalar va takomillashtirish', `Mahsulot chiqqach o'lchash boshlanadi. Asosiy metrikalar: faol foydalanuvchilar (DAU/MAU), saqlanib qolish (retention), konversiya, NPS. "Vanity" metrikalar (jami yuklab olish) chiroyli ko'rinadi, lekin qiymatni ko'rsatmaydi.

A/B test — ikki variantni tasodifiy guruhlarga ko'rsatib solishtirish; bir vaqtda faqat bitta o'zgarishni sinang. Yaxshi gipoteza: "Agar [o'zgarish] qilsak, [metrika] [qancha]ga oshadi, chunki [sabab]". Doimiy sikl: o'lcha → o'rgan → yaxshila.`,
 [['Retention nimani o\'lchaydi?', ['Foydalanuvchilar qaytib kelishini','Yuklab olishlar sonini','Narxni','Dizaynni'],0,0,'Saqlanib qolish.'],
  ['A/B testda bir vaqtda nechta o\'zgarish sinaladi?', ['Bittasi','Hammasi','10 ta','Kamida 5'],0,0,'Aks holda sababni bilib bo\'lmaydi.'],
  ['"Vanity" metrika nima?', ['Chiroyli ko\'rinadi, lekin haqiqiy qiymatni ko\'rsatmaydi','Eng muhim metrika','Daromad','Xato'],0,1,'Masalan, faqat umumiy yuklashlar.']]],
], practical: ['Amaliy ish: Mahsulot g\'oyasidan prototipgacha', `O'zingiz tanlagan muammo uchun (masalan, talabalar uchun vaqtni rejalashtirish):
1) 3 ta odam bilan qisqa intervyu o'tkazing, 3 ta insight yozing.
2) Muammo bayonoti va JTBD jumlasini tuzing.
3) MVP funksiyalari ro'yxatini (5 tadan oshmasin) tanlang.
4) User flow va 3 ta wireframe chizing.
5) Prototipni 2 kishida sinab, topilgan 2 muammoni tuzating.
Tayyor bo'lgach savollarga javob bering.`,
 [['MVP funksiyalarini tanlashda asosiy mezon?', ['Asosiy muammoni hal qilishga ta\'siri','Qaysi biri chiroyliroq','Qaysi biri ko\'proq','Tasodif'],0,1,'Qiymat birinchi.'],
  ['Intervyudan olingan insight qanday bo\'lishi kerak?', ['Kuzatuvga asoslangan, umumlashtirilgan xulosa','Shaxsiy fikr','Reklama shiori','Tasodifiy'],0,1,'Dalil → qonuniyat.'],
  ['Sinovda 5 kishidan 4 tasi bir joyda adashdi. Nima qilasiz?', ['Bu muammoni birinchi navbatda tuzatasiz','Foydalanuvchilarni kiritmaysiz','Qoldirasiz','Rangini o\'zgartirasiz'],0,1,'Takrorlanuvchi muammo — yuqori ustuvorlik.']] ] },
};
