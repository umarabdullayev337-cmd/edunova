const nodemailer = require('nodemailer');
const config = require('../config');

const escapeHtml = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const smtpReady = !!(config.smtp.host && config.smtp.user && config.smtp.pass);
let transport = null;
if (smtpReady) {
  transport = nodemailer.createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    secure: config.smtp.port === 465,
    auth: { user: config.smtp.user, pass: config.smtp.pass },
  });
  transport.verify().then(
    () => console.log(`[mail] SMTP tayyor (${config.smtp.host}) — kodlar haqiqiy emailga yuboriladi`),
    (e) => console.error(`[mail] SMTP ulanmadi: ${e.message}. SMTP_USER/SMTP_PASS ni tekshiring.`),
  );
} else {
  console.warn('[mail] SMTP sozlanmagan! Kodlar emailga ketmaydi. .env faylida SMTP_HOST, SMTP_USER, SMTP_PASS ni to\'ldiring (README ga qarang).');
}

class MailError extends Error {}

// Kod FAQAT shu email manziliga yuboriladi. Sahifada hech qachon ko'rsatilmaydi.
async function sendCodeEmail(to, name, code, purpose = 'register') {
  if (!transport) {
    if (config.isProd) throw new MailError('Email xizmati sozlanmagan');
    // Lokal ishlab chiqish: kod faqat server konsoliga yoziladi (sahifada ko'rinmaydi)
    console.log(`\n[DEV] ${to} uchun kod: ${code}  (SMTP sozlanmagan, faqat konsolda)\n`);
    return { sent: false };
  }
  const title = purpose === 'login' ? 'Tizimga kirish' : "Ro'yxatdan o'tish";
  const lead = purpose === 'login'
    ? 'Hisobingizga kirish uchun quyidagi tasdiqlash kodini kiriting:'
    : "Ro'yxatdan o'tishni yakunlash uchun quyidagi tasdiqlash kodini kiriting:";
  const html = `
  <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:32px;background:#0D1230;color:#F6EFDD;border-radius:16px">
    <h2 style="margin:0 0 12px;color:#F6D98A">EduNova — ${title}</h2>
    <p>Salom, ${escapeHtml(name)}!</p>
    <p>${lead}</p>
    <p style="font-size:34px;letter-spacing:10px;font-weight:700;margin:24px 0;color:#E9B44C">${code}</p>
    <p style="color:#A6ABC9;font-size:13px">Kod 10 daqiqa amal qiladi. Agar bu siz bo'lmasangiz, xatni e'tiborsiz qoldiring va parolingizni almashtiring.</p>
  </div>`;
  try {
    await transport.sendMail({
      from: config.smtp.from, to,
      subject: `EduNova kodi: ${code}`,
      text: `${title} kodingiz: ${code} (10 daqiqa amal qiladi)`,
      html,
    });
  } catch (e) {
    console.error('[mail] yuborilmadi:', e.message);
    throw new MailError('Emailga kod yuborib bo\'lmadi. Keyinroq urinib ko\'ring.');
  }
  return { sent: true };
}

module.exports = { sendCodeEmail, sendVerificationEmail: (to, name, code) => sendCodeEmail(to, name, code, 'register'), MailError };
