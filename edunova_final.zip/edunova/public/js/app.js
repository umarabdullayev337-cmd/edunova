import { api, session, refresh, setSession, onAuthChange } from './api.js';

/* =====================================================================
   Yordamchi funksiyalar
   ===================================================================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ic = (name, cls = '') => `<svg class="ic ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const price = (n) => (n === 0 ? 'Bepul' : `${String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} so'm`);
const fmtDate = (ms) => {
  const d = new Date(ms);
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
};
const fmtDateLong = (ms) => {
  const months = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'];
  const d = new Date(ms);
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
};
const initials = (name = '') => name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || 'U';
const mmss = (ms) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};
const plural = (n, one) => `${n} ${one}`;
const avatarImg = (avatar, name, size = 40, frame = null) => {
  const inner = avatar
    ? `<img class="avatar-img" src="${esc(avatar)}" alt="" style="width:${size}px;height:${size}px" loading="lazy">`
    : `<span class="avatar" style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.4)}px">${esc(initials(name))}</span>`;
  const prem = avatar && /^\/img\/premium\/(\w+)\.svg$/.exec(avatar);
  const fr = frame && /^\w+$/.test(frame) ? frame : null;
  if (!prem && !fr) return inner;
  const fxl = fr ? `<span class="fxl" aria-hidden="true">${[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => `<i style="--i:${i}"></i>`).join('')}</span>` : '';
  return `<span class="av ${fr ? `frame-${fr}` : ''} ${prem ? `fx-${prem[1]}` : ''}" style="width:${size}px;height:${size}px;--s:${size}px">${fxl}<span class="av-in">${inner}</span></span>`;
};
const RANKS = [
  { level: 1, name: 'Yangi', icon: '🌱' }, { level: 2, name: 'Shogird', icon: '📘' }, { level: 3, name: 'Tajribali', icon: '⚡' },
  { level: 4, name: 'Usta', icon: '🔥' }, { level: 5, name: 'Ekspert', icon: '💎' }, { level: 6, name: 'Afsona', icon: '👑' },
];
const rankBadge = (r, small = false) => {
  const lv = typeof r === 'object' && r ? r.level : Number(r) || 1;
  const info = RANKS[Math.min(Math.max(lv, 1), 6) - 1];
  return `<span class="rank-badge r${info.level} ${small ? 'sm' : ''}" title="${info.name} rank">${info.icon} ${info.name}</span>`;
};
const gem = (n) => `<span class="gem-pill">${ic('gem')}${esc(n)}</span>`;
const enc = encodeURIComponent;
const mentorImg = (key, size = 40, cls = '') => `<img class="avatar-img ${cls}" src="/img/avatars/${esc(key || 'm-jasur')}.svg" alt="" style="width:${size}px;height:${size}px" loading="lazy">`;
const stars = (r) => {
  if (r == null) return `<span class="muted" style="font-size:.85rem">Hali baholanmagan</span>`;
  const full = Math.round(r);
  return `<span class="stars" aria-label="${r} / 5">${Array.from({ length: 5 }, (_, i) => `<svg class="star ${i < full ? 'on' : ''}" viewBox="0 0 24 24"><use href="#i-star"/></svg>`).join('')}</span><b>${r}</b>`;
};

const CATS = {
  Backend: { icon: 'layers', key: 'backend' },
  Frontend: { icon: 'code', key: 'frontend' },
  Mobil: { icon: 'zap', key: 'mobile' },
  "Ma'lumotlar": { icon: 'chart', key: 'data' },
  Dizayn: { icon: 'star', key: 'design' },
  Xavfsizlik: { icon: 'shield', key: 'security' },
  Tillar: { icon: 'book', key: 'lang' },
};
const LEVELS = ["Boshlang'ich", "O'rta", 'Yuqori'];
const GOALS = [
  { id: 'university', label: 'Chet el universitetiga kirish', icon: 'award' },
  { id: 'job', label: 'IT kompaniyada ishga joylashish', icon: 'layers' },
  { id: 'freelance', label: 'Frilanser sifatida pul topish', icon: 'zap' },
  { id: 'startup', label: "O'z startapini boshlash", icon: 'star' },
  { id: 'hobby', label: "Shunchaki yangi ko'nikma o'rganish", icon: 'book' },
];
const goalLabel = (id) => GOALS.find((g) => g.id === id)?.label || '';
const catOf = (c) => CATS[c.category] || CATS.Backend;
const MENTOR_AVATARS = ['m-jasur', 'm-dilnoza', 'm-sardor', 'm-madina', 'm-bekzod', 'm-nigora', 'm-otabek', 'm-malika', 'm-sherzod', 'm-aziza', 'm-ulugbek', 'm-kamola', 'm-rustam'];
const PRESET_AVATARS = [
  { key: 'astronaut', label: 'Kosmonavt' }, { key: 'ninja', label: 'Nindzya' }, { key: 'robot', label: 'Robot' },
  { key: 'fox', label: 'Tulki' }, { key: 'panda', label: 'Panda' }, { key: 'wizard', label: 'Sehrgar' },
  { key: 'gamer', label: 'Geymer' }, { key: 'dj', label: 'DJ' }, { key: 'scientist', label: 'Olim' },
  { key: 'king', label: 'Qirol' }, { key: 'alien', label: 'Begona' }, { key: 'cat', label: 'Mushuk' },
];
const presetImg = (key, size = 56) => `<img class="avatar-img" src="/img/presets/${esc(key)}.svg" alt="" style="width:${size}px;height:${size}px" loading="lazy">`;

const view = $('#view');
const modal = $('#modal');

const state = {
  courses: [],
  mentors: [],
  enrolledMap: new Map(), // courseId -> enrollment info
  filters: { q: '', cat: 'Hammasi', level: 'Hammasi', premium: 'Hammasi' },
  admin: { tab: 'courses', data: null, users: null, mentors: null, messages: null, msgFilter: 'open' },
};

/* =====================================================================
   Toast, modal, tasdiqlash oynasi
   ===================================================================== */
function toast(msg, type = 'ok') {
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.setAttribute('role', type === 'ok' ? 'status' : 'alert');
  t.innerHTML = `${ic(type === 'ok' ? 'check' : 'x')}<span>${esc(msg)}</span>`;
  $('#toasts').append(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 260); }, 4200);
}

function openModal(html, cls = '') {
  modal.className = cls;
  modal.innerHTML = html;
  if (!modal.open) modal.showModal();
}
function closeModal() { if (modal.open) modal.close(); }
modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

function confirmBox(title, text, okLabel = "Ha, o'chirish") {
  return new Promise((resolve) => {
    openModal(`<div class="modal-body"><h3>${esc(title)}</h3><p class="muted">${esc(text)}</p>
      <div class="row end"><button class="btn ghost" data-close>Bekor qilish</button><button class="btn danger" data-ok>${esc(okLabel)}</button></div></div>`, 'sm');
    let done = false;
    const finish = (v) => {
      if (done) return;
      done = true;
      modal.removeEventListener('click', onClick);
      modal.removeEventListener('close', onClose);
      closeModal();
      resolve(v);
    };
    const onClick = (e) => {
      if (e.target.closest('[data-ok]')) finish(true);
      else if (e.target.closest('[data-close]') || e.target === modal) finish(false);
    };
    const onClose = () => finish(false);
    modal.addEventListener('click', onClick);
    modal.addEventListener('close', onClose);
  });
}

function promptCertName() {
  return new Promise((resolve) => {
    openModal(`<div class="modal-body">
      <h3>Sertifikat uchun ismingiz</h3>
      <p class="muted">Sertifikatda aynan shu ism-familiya ko'rsatiladi.</p>
      <form data-form="cert-name">
        <div class="form-error" role="alert"></div>
        <div class="field"><label for="cert-name">Ism va familiya</label><input id="cert-name" name="fullName" required minlength="3" maxlength="80" value="${esc(session.user?.name || '')}"></div>
        <div class="row end"><button type="button" class="btn ghost" data-close>Bekor qilish</button><button class="btn primary" type="submit">Sertifikat olish</button></div>
      </form>
    </div>`, 'sm');
    let done = false;
    const finish = (v) => {
      if (done) return;
      done = true;
      modal.removeEventListener('click', onClick);
      modal.removeEventListener('close', onClose);
      resolve(v);
    };
    const onClick = (e) => { if (e.target.closest('[data-close]')) { closeModal(); finish(null); } };
    const onClose = () => finish(null);
    modal.addEventListener('click', onClick);
    modal.addEventListener('close', onClose);
    modal._certFinish = finish;
  });
}

/* =====================================================================
   Navigatsiya
   ===================================================================== */
const currentPath = () => (location.hash.replace(/^#/, '') || '/').split('?')[0];

function renderNav() {
  const u = session.user;
  const p = currentPath();
  const link = (href, label) => `<a href="#${href}" class="nav-link ${p === href ? 'active' : ''}">${label}</a>`;
  $('#nav').innerHTML = `
    <div class="wrap nav-in">
      <a class="brand" href="#/" aria-label="EduNova bosh sahifa"><svg class="mark"><use href="#logo-mark"/></svg><span>EduNova</span></a>
      <nav class="nav-links" aria-label="Asosiy menyu">
        ${link('/', 'Bosh sahifa')}${link('/courses', 'Kurslar')}${link('/mentors', 'Mentorlar')}${link('/help', 'Yordam')}
        ${link('/ranks', 'Reyting')}${u ? link('/shop', "Do'kon") : ''}${u ? link('/profile', 'Kabinet') : ''}${u && u.role === 'admin' ? link('/admin', 'Admin panel') : ''}
      </nav>
      <div class="nav-cta">
        ${u
          ? `<a class="avatar-chip ${u.isPremium ? 'premium' : ''}" href="#/profile" aria-label="Kabinet">${avatarImg(u.avatar, u.name, 32, u.frame)}<span class="hide-sm">${esc(u.name.split(' ')[0])}</span><span class="hide-sm">${rankBadge(u.rank, true)}</span>${u.isPremium ? ic('star', 'gold-ic') : ''}</a>
             <a class="gem-pill" href="#/shop" title="Almazlar do'koni" aria-label="Almazlar do'koni">${ic('gem')}<span id="nav-gems">${u.diamonds || 0}</span></a>
             <button class="btn ghost sm" data-action="logout" aria-label="Chiqish">${ic('logout')}<span class="hide-sm">Chiqish</span></button>`
          : `<a class="btn ghost sm" href="#/login">Kirish</a><a class="btn primary sm hide-sm" href="#/register">Ro'yxatdan o'tish</a>`}
      </div>
      <button class="burger" data-action="toggle-menu" aria-label="Menyu" aria-expanded="false">${ic('menu')}</button>
    </div>`;
}

function redirect(path, remember = false) {
  if (remember) sessionStorage.setItem('returnTo', location.hash || '#/');
  if (currentPath() === path) return null;
  location.hash = `#${path}`;
  return null;
}

/* =====================================================================
   Taymerlar
   ===================================================================== */
let tick = null;
function clearTimers() { if (tick) clearInterval(tick); tick = null; }
function startTimers() {
  clearTimers();
  const run = () => {
    $$('[data-countdown]').forEach((el) => {
      if (el.dataset.countdown === 'token') {
        const ms = session.expiresAt - Date.now();
        el.classList.toggle('off', ms <= 0);
        el.textContent = ms > 0 ? mmss(ms) : "Muddati tugagan. Keyingi so'rovda avtomatik yangilanadi.";
      } else if (el.dataset.countdown === 'resend') {
        const ms = Number(sessionStorage.getItem('resendAt') || 0) - Date.now();
        el.disabled = ms > 0;
        el.textContent = ms > 0 ? `Kodni qayta yuborish (${Math.ceil(ms / 1000)} s)` : 'Kodni qayta yuborish';
      } else if (el.dataset.countdown === 'premium') {
        const ms = Number(el.dataset.until) - Date.now();
        if (ms <= 0) { el.textContent = ''; return; }
        const h = Math.floor(ms / 3600000);
        const m = Math.floor((ms % 3600000) / 60000);
        el.textContent = `${h} soat ${m} daqiqa qoldi`;
      }
    });
  };
  if ($('[data-countdown]')) { run(); tick = setInterval(run, 1000); }
}

/* =====================================================================
   Kurs kartasi
   ===================================================================== */
function premiumBadge(sm = false) {
  return `<span class="p-badge ${sm ? 'sm' : ''}">${ic('star')}Premium</span>`;
}

function courseCard(c) {
  const cat = catOf(c);
  const mine = state.enrolledMap.has(c.id);
  return `
  <article class="course ${c.premium ? 'is-premium' : ''}">
    <a class="cover ${cat.key}" href="#/courses/${esc(c.id)}">${ic(cat.icon, 'cover-ic')}<span class="lvl">${esc(c.level)}</span>${c.premium ? premiumBadge(true) : ''}</a>
    <div class="course-b">
      <div class="row between" style="align-items:center"><span class="tag">${esc(c.category)}</span>${stars(c.rating)}</div>
      <h3><a href="#/courses/${esc(c.id)}">${esc(c.title)}</a></h3>
      <p class="clamp">${esc(c.description)}</p>
      <ul class="meta">
        <li>${ic('clock')}${esc(c.durationHours)} soat</li>
        <li>${ic('layers')}${esc(c.lessons)} dars</li>
        <li>${ic('users')}${esc(c.students)} o'quvchi</li>
      </ul>
      <div class="course-f">
        <div><div class="price">${esc(price(c.price))}</div><div class="by">${c.mentor ? esc(c.mentor.name) : esc(c.instructor)}</div></div>
        <div class="btns">
          <a class="btn ghost sm" href="#/courses/${esc(c.id)}">Batafsil</a>
          ${mine ? `<a class="btn ok sm" href="#/courses/${esc(c.id)}">${ic('check')}Yozilgan</a>` : `<button class="btn primary sm" data-action="enroll" data-id="${esc(c.id)}">Yozilish</button>`}
        </div>
      </div>
    </div>
  </article>`;
}

function mentorCardMini(m) {
  return `<a class="mentor-mini" href="#/mentors/${esc(m.id)}">
    ${mentorImg(m.avatarKey, 60)}
    <div><h3>${esc(m.name)}</h3><small>${esc(m.title)}</small>${m.rating ? `<div class="row" style="margin-top:.3rem;gap:.4rem">${stars(m.rating)}</div>` : ''}</div>
  </a>`;
}

/* =====================================================================
   Ma'lumot yuklash
   ===================================================================== */
async function loadCourses() {
  const d = await api('/courses', { auth: false });
  state.courses = d.courses;
  return d;
}
async function loadMentors() {
  const d = await api('/mentors', { auth: false });
  state.mentors = d.mentors;
  return d;
}
async function loadEnrolled() {
  if (!session.user) { state.enrolledMap = new Map(); return null; }
  const p = await api('/profile');
  state.enrolledMap = new Map(p.courses.map((c) => [c.id, c]));
  return p;
}

/* =====================================================================
   Bosh sahifa
   ===================================================================== */
async function home() {
  await Promise.all([loadCourses(), loadMentors()]);
  await loadEnrolled().catch(() => {});
  let recentReviews = [];
  try { recentReviews = (await api('/courses/reviews/recent', { auth: false })).reviews; } catch { /* jim */ }

  const cs = state.courses;
  const lessons = cs.reduce((s, c) => s + c.lessons, 0);
  const hours = cs.reduce((s, c) => s + c.durationHours, 0);
  const top = [...cs].sort((a, b) => b.students - a.students || b.lessons - a.lessons).slice(0, 3);
  const premiumCourses = cs.filter((c) => c.premium).slice(0, 3);
  const topMentors = [...state.mentors].sort((a, b) => (b.rating || 0) - (a.rating || 0) || b.studentCount - a.studentCount).slice(0, 4);
  const u = session.user;

  return `
  <section class="hero">
    <div class="wrap hero-in">
      <div>
        <h1>Kasbingizni amaliyot bilan o'rganing, natijani birinchi haftadan ko'ring</h1>
        <p class="lead">EduNova — backend, frontend, mobil ilova, dizayn va xavfsizlik yo'nalishlaridagi kurslar. Har bir modul real loyiha bilan yakunlanadi, mentor esa har qadamda yoningizda.</p>
        <div class="cta-row">
          <a class="btn primary" href="#/courses">Kurslarni ko'rish</a>
          ${u ? (u.onboarded ? `<a class="btn ghost" href="#/profile">Kabinetga o'tish</a>` : `<a class="btn ghost" href="#/onboarding">Shaxsiy tavsiya olish</a>`) : `<a class="btn ghost" href="#/register">Bepul hisob yaratish</a>`}
        </div>
        <dl class="stats">
          <div><dt>${cs.length}</dt><dd>ta kurs</dd></div>
          <div><dt>${lessons}</dt><dd>ta video dars</dd></div>
          <div><dt>${hours}</dt><dd>soat mazmun</dd></div>
          <div><dt>${state.mentors.length}</dt><dd>ta mentor</dd></div>
        </dl>
      </div>

      <div class="panel" aria-label="Dars jarayoni namunasi">
        <div class="panel-top">
          <svg class="ring" viewBox="0 0 120 120" role="img" aria-label="Kurs 72% tugallangan">
            <circle class="ring-bg" cx="60" cy="60" r="52"/>
            <circle class="ring-fg" cx="60" cy="60" r="52" transform="rotate(-90 60 60)"/>
            <text x="60" y="69" text-anchor="middle">72%</text>
          </svg>
          <div><small>Bugungi dars</small><h3>Node.js va Express: professional backend</h3></div>
        </div>
        <ul class="lessons">
          <li class="done"><span class="dot">${ic('check')}</span>JWT nima va qanday ishlaydi</li>
          <li class="done"><span class="dot">${ic('check')}</span>Access va refresh token</li>
          <li class="now"><span class="dot"></span>httpOnly cookie bilan sessiya</li>
          <li class="lock"><span class="dot">${ic('lock')}</span>Rate limiting va himoya</li>
        </ul>
        <svg class="seal" viewBox="0 0 120 120" aria-hidden="true">
          <defs><path id="sealpath" d="M60 60 m-43 0 a43 43 0 1 1 86 0 a43 43 0 1 1 -86 0"/></defs>
          <circle cx="60" cy="60" r="58" fill="#E9B44C"/>
          <circle cx="60" cy="60" r="52" fill="none" stroke="#0D1230" stroke-width="1.4" stroke-dasharray="2 3"/>
          <text font-size="10" font-weight="700" fill="#0D1230" font-family="Hanken Grotesk, sans-serif"><textPath href="#sealpath" textLength="262" lengthAdjust="spacing">EduNova sertifikati • EduNova •</textPath></text>
          <g transform="translate(42 42)" stroke="#0D1230" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path transform="scale(1.5)" d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.2 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/></g>
        </svg>
      </div>
    </div>
  </section>

  <section class="sec alt" id="afzalliklar">
    <div class="wrap split">
      <div class="stick">
        <h2>Yaxshi o'qish uchun kerak bo'lgan hamma narsa bir joyda</h2>
        <p>Nazariyani ko'p gapirmaymiz. Har bir mavzu amaliy topshiriq bilan mustahkamlanadi va mentor tomonidan tekshiriladi.</p>
      </div>
      <div class="feat-list">
        <div class="feat"><div class="badge-ic">${ic('code')}</div><div><h3>Real loyihalar ustida ishlash</h3><p>Portfolioga qo'yishga arziydigan ishlar: API, veb-ilova, mobil ilova va dizayn prototiplari.</p></div></div>
        <div class="feat"><div class="badge-ic">${ic('users')}</div><div><h3>Mentor doim yoningizda</h3><p>Kod ko'rib chiqish, savollarga tezkor javob va shaxsiy o'sish rejasi.</p></div></div>
        <div class="feat"><div class="badge-ic">${ic('award')}</div><div><h3>Tan olingan onlayn sertifikat</h3><p>Kursni tugatganingizda, tekshirish kodi bilan tasdiqlangan sertifikat olasiz.</p></div></div>
        <div class="feat"><div class="badge-ic">${ic('zap')}</div><div><h3>Shaxsiy tavsiya va haftalik reja</h3><p>Qiziqishlaringiz va maqsadingizga qarab kurslar tavsiya qilinadi, o'quv rejasi avtomatik tuziladi.</p></div></div>
      </div>
    </div>
  </section>

  <section class="sec">
    <div class="wrap">
      <div class="sec-head">
        <div><h2>Eng ko'p tanlangan kurslar</h2></div>
        <a class="btn ghost" href="#/courses">Barcha kurslar</a>
      </div>
      <div class="course-grid" style="padding-bottom:0">${top.map(courseCard).join('')}</div>
    </div>
  </section>

  ${premiumCourses.length ? `
  <section class="sec alt premium-sec">
    <div class="wrap">
      <div class="sec-head">
        <div><span class="tag gold">${ic('star')} Premium</span><h2 style="margin-top:.6rem">Kamroq, lekin eng qimmatli kurslar</h2><p>Chuqur va intensiv dasturlar — natijaga eng tez olib boradigan yo'nalishlar uchun.</p></div>
        <a class="btn ghost" href="#/courses?premium=1">Barcha premium kurslar</a>
      </div>
      <div class="course-grid" style="padding-bottom:0">${premiumCourses.map(courseCard).join('')}</div>
    </div>
  </section>` : ''}

  <section class="sec" id="mentorlar">
    <div class="wrap">
      <div class="sec-head"><div><h2>Mentorlaringiz bilan tanishing</h2><p>Sohasining amaliyotchilari — nazariyani emas, haqiqiy tajribani o'rgatishadi.</p></div><a class="btn ghost" href="#/mentors">Barcha mentorlar</a></div>
      <div class="mentor-grid">${topMentors.map(mentorCardMini).join('')}</div>
    </div>
  </section>

  <section class="sec alt" id="asoschi">
    <div class="wrap founder-wrap">
      <div class="founder-photo">${mentorImg('founder', 220)}<svg class="seal sm" viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="58" fill="#5cd6c0"/><g transform="translate(38 38)" stroke="#0D1230" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path transform="scale(1.8)" d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.2 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/></g></svg></div>
      <div>
        <span class="tag">Asoschi</span>
        <h2 style="margin-top:.7rem">18 yoshda IT akademiyasini asos solgan bola</h2>
        <p class="lead" style="margin-top:1rem">EduNova g'oyasi 18 yoshli dasturchi tomonidan tug'ildi: u maktabda o'zi duch kelgan bo'shliqni — sifatli, amaliy va arzon IT ta'limning yo'qligini — ko'rib, shu muammoni hal qilish uchun akademiya ochdi.</p>
        <ul class="founder-stats">
          <li><b>3000+</b><span>bitirgan talaba</span></li>
          <li><b>4.9/5</b><span>o'rtacha reyting</span></li>
          <li><b>12</b><span>xalqaro tanlov g'olibi</span></li>
          <li><b>2 yosh</b><span>eng yosh IT-asoschilardan biri</span></li>
        </ul>
        <p class="muted">"Men bir marta qiynalgan yo'lni boshqalar uchun qisqartirmoqchiman — shuning uchun EduNova'da hamma narsa faqat amaliyot va natijaga qaratilgan."</p>
      </div>
    </div>
  </section>

  ${recentReviews.length ? `
  <section class="sec">
    <div class="wrap">
      <div class="sec-head"><h2>O'quvchilarimiz nima deydi</h2></div>
      <div class="review-grid">${recentReviews.slice(0, 6).map((r) => `
        <div class="review-card">
          <div class="row" style="gap:.7rem;align-items:center">${avatarImg(r.user.avatar, r.user.name, 42, r.user.frame)}<div><b>${esc(r.user.name)}</b> ${rankBadge(r.user.rank, true)}<div>${stars(r.rating)}</div></div></div>
          <p>${esc(r.text)}</p>
          <small class="muted">${esc(r.courseTitle)}</small>
        </div>`).join('')}</div>
    </div>
  </section>` : ''}

  <section class="sec alt">
    <div class="wrap">
      <div class="sec-head"><h2>O'qishni boshlash uchun uch qadam</h2></div>
      <ol class="steps">
        <li class="step"><h3>Hisob yarating</h3><p>Ism, email va parolni kiriting. Parolingiz hech qachon ochiq holda saqlanmaydi.</p></li>
        <li class="step"><h3>Qisqa so'rovnomani to'ldiring</h3><p>Qiziqishlaringiz va maqsadingizga qarab sizga mos kurslar va haftalik reja tuziladi.</p></li>
        <li class="step"><h3>O'qishni boshlang</h3><p>Kursga yoziling, jarayonni kuzating va yakunida sertifikat oling.</p></li>
      </ol>
    </div>
  </section>

  <section class="sec" id="xavfsizlik">
    <div class="wrap split">
      <div class="stick">
        <h2>Ma'lumotlaringiz ishonchli himoyada</h2>
        <p>Platforma zamonaviy xavfsizlik amaliyotlari asosida qurilgan: sizning hisobingiz va parolingiz uchun.</p>
      </div>
      <dl class="spec">
        <div><dt>${ic('lock')}Parollar</dt><dd>bcrypt bilan hashlanadi va hech qachon ochiq matnda saqlanmaydi.</dd></div>
        <div><dt>${ic('key')}Sessiya</dt><dd>15 daqiqalik access token va 7 kunlik refresh token (httpOnly cookie'da).</dd></div>
        <div><dt>${ic('mail')}Email</dt><dd>Ro'yxatdan o'tganda 6 xonali tasdiqlash kodi yuboriladi.</dd></div>
        <div><dt>${ic('shield')}Himoya</dt><dd>Helmet, CORS, rate limiting va DDoSga qarshi sekinlashtirish yoqilgan.</dd></div>
        <div><dt>${ic('users')}Ruxsatlar</dt><dd>Foydalanuvchi, mentor va admin rollari alohida ajratilgan.</dd></div>
      </dl>
    </div>
  </section>

  <div class="wrap">
    <div class="cta-band">
      <div><h2>Kelajagingizni bugun boshlang</h2><p>Hisob yaratish bepul. Kursni o'zingizga mos vaqtda tanlang va o'qishni boshlang.</p></div>
      ${u ? `<a class="btn primary" href="#/courses">Kurs tanlash</a>` : `<a class="btn primary" href="#/register">Ro'yxatdan o'tish</a>`}
    </div>
  </div>`;
}

/* =====================================================================
   Kurslar ro'yxati
   ===================================================================== */
function filteredCourses() {
  const { q, cat, level, premium } = state.filters;
  const s = q.trim().toLowerCase();
  return state.courses.filter((c) =>
    (cat === 'Hammasi' || c.category === cat) &&
    (level === 'Hammasi' || c.level === level) &&
    (premium === 'Hammasi' || (premium === 'premium' ? c.premium : !c.premium)) &&
    (!s || `${c.title} ${c.description} ${c.instructor} ${(c.tags || []).join(' ')}`.toLowerCase().includes(s)));
}

function gridHtml() {
  const list = filteredCourses();
  return list.length
    ? list.map(courseCard).join('')
    : `<div class="empty" style="grid-column:1/-1"><h3>Hech narsa topilmadi</h3><p>Qidiruv so'zini o'zgartiring yoki filtrlarni tozalang.</p><button class="btn ghost" data-action="reset-filters">Filtrlarni tozalash</button></div>`;
}

function renderGrid() {
  const grid = $('#grid');
  if (!grid) return;
  grid.innerHTML = gridHtml();
  $('#count').textContent = `${filteredCourses().length} ta kurs`;
  $$('.chip[data-cat]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.cat === state.filters.cat)));
  $$('.chip[data-premium]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.premium === state.filters.premium)));
}

async function coursesView() {
  await loadCourses();
  await loadEnrolled().catch(() => {});
  const qs = new URLSearchParams(location.hash.split('?')[1] || '');
  if (qs.get('premium') === '1') state.filters.premium = 'premium';
  const f = state.filters;
  return `
  <div class="wrap">
    <div class="page-head">
      <h1 style="font-size:clamp(2.2rem,4.5vw,3.4rem)">Kurslar</h1>
      <p>O'zingizga mos yo'nalishni tanlang: har bir kurs amaliy loyiha bilan yakunlanadi.</p>
      <div class="filters">
        <div class="search">${ic('search')}<input type="search" placeholder="Kurs, mentor yoki mavzu qidiring" value="${esc(f.q)}" data-filter="q" aria-label="Qidirish"></div>
        <select class="role-sel" style="padding:.8rem 2.4rem .8rem 1rem;font-size:.95rem" data-filter="level" aria-label="Daraja">
          <option value="Hammasi">Barcha darajalar</option>
          ${LEVELS.map((l) => `<option ${f.level === l ? 'selected' : ''}>${esc(l)}</option>`).join('')}
        </select>
      </div>
      <div class="chips" style="margin-top:.9rem" role="group" aria-label="Yo'nalishlar">
        ${['Hammasi', ...Object.keys(CATS)].map((k) => `<button class="chip" data-action="chip" data-cat="${esc(k)}" aria-pressed="${f.cat === k}">${esc(k)}</button>`).join('')}
      </div>
      <div class="chips" style="margin-top:.5rem" role="group" aria-label="Premium filtri">
        <button class="chip" data-action="chip-premium" data-premium="Hammasi" aria-pressed="${f.premium === 'Hammasi'}">Barchasi</button>
        <button class="chip" data-action="chip-premium" data-premium="free" aria-pressed="${f.premium === 'free'}">Oddiy</button>
        <button class="chip gold" data-action="chip-premium" data-premium="premium" aria-pressed="${f.premium === 'premium'}">${ic('star')}Premium</button>
      </div>
      <p class="count" id="count" aria-live="polite">${filteredCourses().length} ta kurs</p>
    </div>
    <div class="course-grid" id="grid">${gridHtml()}</div>
  </div>`;
}

/* =====================================================================
   Kurs tafsilotlari (to'liq sahifa)
   ===================================================================== */
function ratingBreakdownHtml(reviews) {
  const counts = [5, 4, 3, 2, 1].map((n) => reviews.filter((r) => r.rating === n).length);
  const max = Math.max(1, ...counts);
  return `<div class="rate-bars">${[5, 4, 3, 2, 1].map((n, i) => `
    <div class="rate-row"><span>${n}${ic('star')}</span><div class="bar-h"><i style="width:${Math.round((counts[i] / max) * 100)}%"></i></div><span class="muted">${counts[i]}</span></div>`).join('')}</div>`;
}

async function courseDetailView(params) {
  let d;
  try { d = await api(`/courses/${encodeURIComponent(params.id)}`, { auth: false }); }
  catch { return notFound(); }
  const c = d.course;
  await loadEnrolled().catch(() => {});
  const enrollment = state.enrolledMap.get(c.id);
  const reviews = (await api(`/courses/${encodeURIComponent(c.id)}/reviews`, { auth: false })).reviews;
  const cat = catOf(c);
  const myReview = session.user ? reviews.find((r) => r.userId === session.user.id) : null;
  const canReview = enrollment?.completed;
  const totalWeeks = c.syllabus.length;

  return `
  <div class="course-hero ${cat.key}">
    <div class="wrap course-hero-in">
      <div>
        <div class="row" style="gap:.6rem;flex-wrap:wrap"><span class="tag light">${esc(c.category)}</span><span class="tag light">${esc(c.level)}</span>${c.premium ? premiumBadge() : ''}</div>
        <h1 style="margin-top:1rem;font-size:clamp(1.8rem,4vw,2.8rem)">${esc(c.title)}</h1>
        <p class="lead" style="color:#e3e5f5;margin-top:1rem;max-width:40rem">${esc(c.description)}</p>
        <div class="row" style="gap:1.6rem;margin-top:1.4rem;flex-wrap:wrap;color:#d6d8ec">
          <span>${stars(c.rating)} <span class="muted">(${c.reviewCount} sharh)</span></span>
          <span>${ic('users')} ${c.students} o'quvchi</span>
          <span>${ic('clock')} ${c.durationHours} soat</span>
          <span>${ic('layers')} ${c.lessons} dars</span>
        </div>
      </div>
    </div>
  </div>
  <div class="wrap course-detail-grid">
    <div>
      ${c.whatYouWillLearn.length ? `
      <section class="box">
        <h2>Nimalarni o'rganasiz</h2>
        <ul class="check-list">${c.whatYouWillLearn.map((x) => `<li>${ic('check')}<span>${esc(x)}</span></li>`).join('')}</ul>
      </section>` : ''}

      ${totalWeeks ? `
      <section class="box">
        <h2>Kurs dasturi (${totalWeeks} hafta)</h2>
        <div class="syllabus">${c.syllabus.map((w, i) => `
          <details class="syl-week" ${i === 0 ? 'open' : ''}>
            <summary><span>${w.week}-hafta: ${esc(w.title)}</span></summary>
            <ul>${w.topics.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>
          </details>`).join('')}</div>
      </section>` : ''}

      ${c.curriculum ? `
      <section class="box">
        <h2>Darslar (${c.curriculum.lessons.length}${c.curriculum.practical ? ' + amaliy ish' : ''})</h2>
        <p class="muted" style="margin-bottom:.8rem">Har bir darsda 1 ta uy ishi bor. To'g'ri javob: oddiy savol +10, qiyin savol +15 ${ic('gem')}</p>
        <ol class="cur-list">${c.curriculum.lessons.map((l, i) => `<li><span class="les-num">${i + 1}</span><span>${esc(l.title)}</span><small>${l.questions} savol</small></li>`).join('')}
        ${c.curriculum.practical ? `<li><span class="les-num prac">${ic('award')}</span><span><b>${esc(c.curriculum.practical.title)}</b></span><small>+100 ${ic('gem')} bonus</small></li>` : ''}</ol>
      </section>` : ''}

      ${c.requirements.length ? `
      <section class="box">
        <h2>Talablar</h2>
        <ul class="dash-list">${c.requirements.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
      </section>` : ''}

      <section class="box" id="reviews">
        <div class="row between" style="align-items:center"><h2>Sharhlar (${reviews.length})</h2>${reviews.length ? stars(c.rating) : ''}</div>
        ${reviews.length ? ratingBreakdownHtml(reviews) : ''}
        ${canReview ? `
        <form data-form="review" data-course="${esc(c.id)}" style="margin-top:1.3rem;padding-top:1.3rem;border-top:1px solid var(--line)">
          <div class="form-error" role="alert"></div>
          <label style="font-weight:600;font-size:.9rem">${myReview ? 'Sharhingizni tahrirlash' : 'Sharh qoldiring'}</label>
          <div class="star-input" data-stars="1" role="radiogroup" aria-label="Baho">
            ${[1, 2, 3, 4, 5].map((n) => `<button type="button" class="star-btn" data-val="${n}" aria-label="${n} yulduz">${ic('star')}</button>`).join('')}
          </div>
          <input type="hidden" name="rating" value="${myReview ? myReview.rating : ''}">
          <textarea name="text" placeholder="Kurs haqida fikringizni yozing (kamida 10 belgi)" maxlength="500" required minlength="10">${myReview ? esc(myReview.text) : ''}</textarea>
          <button class="btn primary sm" type="submit" style="margin-top:.8rem">${myReview ? 'Yangilash' : 'Yuborish'}</button>
        </form>` : (enrollment ? `<p class="muted" style="margin-top:1rem">Sharh qoldirish uchun avval kursni yakunlang.</p>` : '')}
        <div class="review-list">
          ${reviews.length ? reviews.map((r) => `
            <div class="review-row">
              <div class="row" style="gap:.7rem;align-items:center">${avatarImg(r.user.avatar, r.user.name, 40, r.user.frame)}<div><b>${esc(r.user.name)}</b> ${rankBadge(r.user.rank, true)}<br><small class="muted">${fmtDate(r.createdAt)}</small></div><span style="margin-left:auto">${stars(r.rating)}</span></div>
              <p>${esc(r.text)}</p>
            </div>`).join('') : `<p class="muted" style="margin-top:1rem">Hali sharhlar yo'q. Birinchi bo'lib fikr bildiring!</p>`}
        </div>
      </section>
    </div>

    <aside>
      <div class="box buy-box">
        <div class="price" style="font-size:1.9rem">${esc(price(c.price))}</div>
        ${enrollment
          ? (enrollment.completed
              ? `<div class="badge green" style="margin:.8rem 0">${ic('check')}Kurs yakunlangan</div><button class="btn primary block" data-action="get-cert" data-id="${esc(c.id)}">${ic('award')}Sertifikat olish</button>${c.curriculum ? `<a class="btn ghost block" style="margin-top:.5rem" href="#/learn/${esc(c.id)}/0">Darslarni qayta ko'rish</a>` : ''}`
              : `<div class="progress-wrap"><div class="bar-h" style="height:8px"><i style="width:${enrollment.progress}%"></i></div><small class="muted">${enrollment.progress}% bajarildi</small></div>${c.curriculum ? `<a class="btn primary block" href="#/learn/${esc(c.id)}" style="margin-top:.8rem">${ic('play')}${enrollment.progress ? 'Darsni davom ettirish' : 'Darsni boshlash'}</a>` : `<button class="btn ok block" data-action="mark-complete" data-id="${esc(c.id)}" style="margin-top:.8rem">${ic('check')}Kursni yakunlash</button>`}`)
          : `<button class="btn primary block" data-action="enroll" data-id="${esc(c.id)}" style="margin-top:.8rem">Hoziroq yozilish</button>
             ${c.premium && session.user && !session.user.isPremium && !(session.user.unlockedCourses || []).includes(c.id)
               ? `<button class="btn ghost block" style="margin-top:.5rem" data-action="unlock-course" data-id="${esc(c.id)}" data-title="${esc(c.title)}" data-price="3000">${ic('gem')}3000 almaz bilan ochish</button><small class="muted" style="display:block;margin-top:.4rem">Premium kurs: premium status yoki almaz bilan ochiladi.</small>` : ''}`}
        <ul class="kv" style="margin-top:1.3rem">
          <div><dt>Daraja</dt><dd>${esc(c.level)}</dd></div>
          <div><dt>Davomiylik</dt><dd>${esc(c.durationHours)} soat</dd></div>
          <div><dt>Darslar</dt><dd>${esc(c.lessons)} ta</dd></div>
          <div><dt>Tur</dt><dd>${c.premium ? 'Premium' : 'Oddiy'}</dd></div>
        </ul>
        ${c.tags.length ? `<div class="chips" style="margin-top:1rem">${c.tags.map((t) => `<span class="chip static">${esc(t)}</span>`).join('')}</div>` : ''}
      </div>
      ${c.mentor ? `
      <div class="box">
        <h2 style="font-size:1.1rem">Mentor</h2>
        <a class="mentor-mini" href="#/mentors/${esc(c.mentor.id)}">${mentorImg(c.mentor.avatarKey, 60)}<div><h3>${esc(c.mentor.name)}</h3><small>${esc(c.mentor.title)}</small></div></a>
      </div>` : ''}
    </aside>
  </div>`;
}

/* =====================================================================
   Mentorlar
   ===================================================================== */
async function mentorsView() {
  await loadMentors();
  return `
  <div class="wrap">
    <div class="page-head">
      <h1 style="font-size:clamp(2.2rem,4.5vw,3.4rem)">Mentorlar</h1>
      <p>EduNova mentorlari — o'z sohasida yillar davomida ishlagan amaliyotchilar.</p>
    </div>
    <div class="mentor-grid big">${state.mentors.map((m) => `
      <a class="mentor-card" href="#/mentors/${esc(m.id)}">
        ${mentorImg(m.avatarKey, 84)}
        <h3>${esc(m.name)}</h3>
        <small class="muted">${esc(m.title)}</small>
        <p class="clamp" style="margin-top:.6rem">${esc(m.bio)}</p>
        <div class="row between" style="margin-top:1rem;font-size:.85rem" class="muted">
          <span>${ic('layers')} ${m.courseCount} kurs</span><span>${ic('users')} ${m.studentCount} o'quvchi</span>
        </div>
      </a>`).join('') || '<p class="muted">Hozircha mentorlar qo\'shilmagan.</p>'}</div>
  </div>`;
}

async function mentorDetailView(params) {
  let d;
  try { d = await api(`/mentors/${encodeURIComponent(params.id)}`, { auth: false }); }
  catch { return notFound(); }
  const m = d.mentor;
  return `
  <div class="wrap">
    <div class="mentor-head">
      ${mentorImg(m.avatarKey, 120)}
      <div>
        <h1 style="font-size:clamp(1.8rem,3.5vw,2.6rem)">${esc(m.name)}</h1>
        <p class="muted" style="margin-top:.3rem">${esc(m.title)}${m.specialty ? ` • ${esc(m.specialty)}` : ''}</p>
        <div class="row" style="gap:1.4rem;margin-top:.8rem;flex-wrap:wrap">
          ${m.rating ? `<span>${stars(m.rating)} <span class="muted">(${m.reviewCount})</span></span>` : ''}
          <span class="muted">${ic('layers')} ${m.courseCount} kurs</span>
          <span class="muted">${ic('users')} ${m.studentCount} o'quvchi</span>
        </div>
      </div>
    </div>
    <div class="grid-2" style="align-items:start">
      <div>
        <section class="box"><h2>Biografiya</h2><p class="muted">${esc(m.bio)}</p></section>
        ${d.courses.length ? `<section class="box"><h2>Mentor kurslari</h2><div class="course-grid" style="padding-bottom:0">${d.courses.map(courseCard).join('')}</div></section>` : ''}
      </div>
      <div>
        ${m.achievements.length ? `<section class="box"><h2>Yutuqlar</h2><ul class="check-list">${m.achievements.map((a) => `<li>${ic('award')}<span>${esc(a)}</span></li>`).join('')}</ul></section>` : ''}
      </div>
    </div>
  </div>`;
}

/* =====================================================================
   Kirish / Ro'yxatdan o'tish / Tasdiqlash
   ===================================================================== */
const asideHtml = (title, items) => `
  <aside class="aside">
    <svg class="mark" style="width:56px;height:56px;margin-bottom:1.6rem"><use href="#logo-mark"/></svg>
    <h2>${title}</h2>
    <ul>${items.map((t) => `<li>${ic('check')}<span>${t}</span></li>`).join('')}</ul>
  </aside>`;

const passField = (name, label, ac, extra = '') => `
  <div class="field">
    <label for="${name}">${label}</label>
    <div class="input-wrap">
      <input id="${name}" name="${name}" type="password" autocomplete="${ac}" required ${extra}>
      <button type="button" class="toggle" data-action="toggle-pass" aria-label="Parolni ko'rsatish">${ic('eye')}</button>
    </div>
  </div>`;

async function loginView() {
  if (session.user) return redirect(session.user.onboarded || session.user.role !== 'user' ? '/profile' : '/onboarding');
  return `
  <div class="auth">
    <div class="auth-form"><div class="auth-card">
      <h1>Qaytganingiz bilan!</h1>
      <p>Hisobingizga kirib, o'qishni davom ettiring.</p>
      <form data-form="login" novalidate>
        <div class="form-error" role="alert"></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email" placeholder="sizning@emailingiz.uz" required></div>
        ${passField('password', 'Parol', 'current-password')}
        <button class="btn primary block" type="submit">Kirish</button>
      </form>
      <p class="auth-alt">Hisobingiz yo'qmi? <a href="#/register">Ro'yxatdan o'ting</a></p>
    </div></div>
    ${asideHtml("Davom eting, siz to'xtagan joyingizdan", ['Kurslaringiz va jarayoningiz saqlanadi', 'Sessiya xavfsiz tokenlar bilan himoyalangan', 'Yangi kurslar va mentorlar sizni kutmoqda'])}
  </div>`;
}

async function registerView() {
  if (session.user) return redirect('/profile');
  return `
  <div class="auth">
    <div class="auth-form"><div class="auth-card">
      <h1>Hisob yarating</h1>
      <p>Bir daqiqada ro'yxatdan o'ting va kurslarga yoziling.</p>
      <form data-form="register" novalidate>
        <div class="form-error" role="alert"></div>
        <div class="field"><label for="name">Ism va familiya</label><input id="name" name="name" type="text" autocomplete="name" placeholder="Masalan, Aziza Karimova" required minlength="2" maxlength="60"></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email" placeholder="sizning@emailingiz.uz" required></div>
        ${passField('password', 'Parol', 'new-password', 'minlength="8" maxlength="72" data-strength')}
        <div class="field" style="margin-top:-.5rem"><div class="meter"><i id="meter"></i></div><span class="meter-label" id="meter-label">Kamida 8 ta belgi, harf va raqam</span></div>
        <button class="btn primary block" type="submit">Ro'yxatdan o'tish</button>
      </form>
      <p class="auth-alt">Hisobingiz bormi? <a href="#/login">Kirish</a></p>
    </div></div>
    ${asideHtml("O'qishni bugun boshlang", ['Emailingizga 6 xonali tasdiqlash kodi yuboriladi', 'Parolingiz bcrypt bilan shifrlanadi', 'Ro\'yxatdan so\'ng sizga mos kurslar tavsiya qilinadi'])}
  </div>`;
}

async function verifyView() {
  if (session.user) return redirect('/profile');
  const email = sessionStorage.getItem('pendingEmail') || '';
  const mode = sessionStorage.getItem('pendingMode') === 'login' ? 'login' : 'register';
  return `
  <div class="auth">
    <div class="auth-form"><div class="auth-card">
      <h1>${mode === 'login' ? 'Kirishni tasdiqlang' : 'Emailni tasdiqlang'}</h1>
      <p>${email ? `<b style="color:var(--paper)">${esc(email)}</b> manziliga 6 xonali kod yubordik. Uni quyiga kiriting${mode === 'login' ? ' — kodsiz kirib bo\'lmaydi' : ''}.` : 'Emailingizni va unga kelgan 6 xonali kodni kiriting.'}</p>
      <form data-form="verify" novalidate>
        <div class="form-error" role="alert"></div>
        ${email ? `<input type="hidden" name="email" value="${esc(email)}">` : `<div class="field"><label for="email">Email</label><input id="email" name="email" type="email" required></div>`}
        <div class="otp" role="group" aria-label="6 xonali kod">
          ${[0, 1, 2, 3, 4, 5].map((i) => `<input data-otp inputmode="numeric" autocomplete="${i === 0 ? 'one-time-code' : 'off'}" maxlength="1" aria-label="${i + 1}-raqam">`).join('')}
        </div>
        <button class="btn primary block" type="submit">Tasdiqlash</button>
      </form>
      <p class="auth-alt"><button class="link-btn" data-action="resend" data-countdown="resend" disabled>Kodni qayta yuborish</button></p>
      <p class="auth-alt">${mode === 'login' ? '<a href="#/login">Boshqa hisob bilan kirish</a>' : '<a href="#/register">Boshqa email bilan ro\'yxatdan o\'tish</a>'}</p>
    </div></div>
    ${asideHtml('Deyarli tayyor!', ['Kod 10 daqiqa amal qiladi', "5 tagacha noto'g'ri urinishga ruxsat beriladi", 'Tasdiqlangach qisqa so\'rovnoma kutmoqda'])}
  </div>`;
}

/* =====================================================================
   Onboarding — qiziqish, maqsad va haftalik vaqtni aniqlash
   ===================================================================== */
async function onboardingView() {
  if (!session.user) return redirect('/login', true);
  const u = session.user;
  const today = new Date().toISOString().slice(0, 10);
  return `
  <div class="wrap" style="max-width:760px">
    <div class="page-head">
      <span class="tag">Shaxsiylashtirish</span>
      <h1 style="margin-top:.6rem">Sizni yaxshiroq tanishtiring</h1>
      <p>Shu qisqa so'rovnoma asosida sizga eng mos kurslarni va haftalik o'quv rejasini tuzib beramiz.</p>
    </div>
    <form data-form="onboarding" class="box" novalidate>
      <div class="form-error" role="alert"></div>

      <label class="field-label">Qaysi yo'nalishlar qiziqtiradi? <span class="muted">(eng ko'pi 5 ta)</span></label>
      <div class="chips" id="ob-interests" style="margin-bottom:1.4rem">
        ${Object.keys(CATS).map((k) => `<button type="button" class="chip" data-action="ob-interest" data-val="${esc(k)}" aria-pressed="${(u.interests || []).includes(k)}">${esc(k)}</button>`).join('')}
      </div>

      <label class="field-label">Asosiy maqsadingiz</label>
      <div class="goal-grid" id="ob-goal" style="margin-bottom:1.4rem">
        ${GOALS.map((g) => `<button type="button" class="goal-card ${u.goal === g.id ? 'sel' : ''}" data-action="ob-goal" data-val="${g.id}">${ic(g.icon)}<span>${g.label}</span></button>`).join('')}
      </div>

      <div class="form-grid">
        <div class="field"><label for="ob-level">Hozirgi darajangiz</label>
          <select id="ob-level" name="level">${LEVELS.map((l) => `<option ${u.level === l ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>
        </div>
        <div class="field"><label for="ob-hours">Haftasiga necha soat ajrata olasiz?</label>
          <input id="ob-hours" name="weeklyHours" type="number" min="1" max="40" value="${u.weeklyHours || 6}" required>
        </div>
        <div class="field full"><label for="ob-start">Qachondan boshlamoqchisiz?</label>
          <input id="ob-start" name="startDate" type="date" value="${u.startDate || today}" min="${today}">
        </div>
      </div>
      <input type="hidden" name="interests" value="${esc((u.interests || []).join(','))}">
      <input type="hidden" name="goal" value="${esc(u.goal || '')}">
      <button class="btn primary block" type="submit" style="margin-top:.6rem">Tavsiyalarni ko'rish</button>
    </form>
  </div>`;
}

/* =====================================================================
   Yordam / Aloqa (adminga xabar yuborish)
   ===================================================================== */
async function helpView() {
  const u = session.user;
  return `
  <div class="wrap" style="max-width:760px">
    <div class="page-head">
      <h1 style="font-size:clamp(2rem,4vw,2.8rem)">Yordam kerakmi?</h1>
      <p>Savolingiz yoki taklifingiz bo'lsa, quyidagi forma orqali administratsiyaga to'g'ridan-to'g'ri xabar yuboring. Odatda 24 soat ichida javob beramiz.</p>
    </div>

    <form data-form="cert-lookup" class="box" style="margin-bottom:1.5rem" novalidate>
      <div class="form-error" role="alert"></div>
      <h2 style="font-size:1.1rem;margin-bottom:.8rem">${ic('award')} Sertifikatni tekshirish</h2>
      <div class="row" style="gap:.6rem">
        <input name="code" placeholder="Masalan: EDU-AB12-CD34" style="flex:1" required>
        <button class="btn primary sm" type="submit">Tekshirish</button>
      </div>
    </form>

    <form data-form="contact" class="box" novalidate>
      <div class="form-error" role="alert"></div>
      <div class="form-grid">
        <div class="field"><label for="c-name">Ismingiz</label><input id="c-name" name="name" required minlength="2" maxlength="60" value="${esc(u?.name || '')}"></div>
        <div class="field"><label for="c-email">Email</label><input id="c-email" name="email" type="email" required value="${esc(u?.email || '')}"></div>
        <div class="field full"><label for="c-subj">Mavzu</label><input id="c-subj" name="subject" required minlength="3" maxlength="100" placeholder="Masalan: To'lov bo'yicha savol"></div>
        <div class="field full"><label for="c-text">Xabar</label><textarea id="c-text" name="text" required minlength="10" maxlength="1000" placeholder="Savolingizni batafsil yozing..."></textarea></div>
      </div>
      <button class="btn primary" type="submit">${ic('send')}Yuborish</button>
    </form>
  </div>`;
}

/* =====================================================================
   Sertifikat — tekshirish va ko'rsatish
   ===================================================================== */
async function certificatePageView(params) {
  let d;
  try { d = await api(`/certificates/verify/${encodeURIComponent(params.code)}`, { auth: false }); }
  catch (e) {
    return `<div class="wrap forbidden"><h1>Sertifikat topilmadi</h1><p class="muted">"${esc(params.code)}" kodi bilan sertifikat mavjud emas. Kodni tekshirib qayta urinib ko'ring.</p><a class="btn primary" href="#/">Bosh sahifaga qaytish</a></div>`;
  }
  const c = d.certificate;
  return `
  <div class="wrap cert-wrap">
    <div class="no-print row between" style="margin-bottom:1.2rem">
      <span class="badge green">${ic('check')}Tasdiqlangan sertifikat</span>
      <button class="btn ghost sm" data-action="print">${ic('download')}Chop etish / PDF saqlash</button>
    </div>
    <div class="certificate" id="cert-card">
      <div class="cert-border">
        <svg class="cert-mark" viewBox="0 0 48 48"><use href="#logo-mark"/></svg>
        <div class="cert-brand">EduNova</div>
        <div class="cert-kicker">Yakunlash sertifikati</div>
        <div class="cert-name">${esc(c.fullName)}</div>
        <p class="cert-line">quyidagi kursni muvaffaqiyatli yakunladi</p>
        <div class="cert-course">${esc(c.courseTitle)}</div>
        <div class="cert-meta">
          <div><span>Davomiylik</span><b>${esc(c.durationHours)} soat</b></div>
          <div><span>Sana</span><b>${fmtDateLong(c.issuedAt)}</b></div>
          <div><span>Kod</span><b>${esc(c.code)}</b></div>
        </div>
        ${c.mentor ? `<div class="cert-sign"><div class="sign-line"></div><span>${esc(c.mentor.name)}</span><small>${esc(c.mentor.title)}</small></div>` : ''}
        <svg class="cert-seal" viewBox="0 0 120 120" aria-hidden="true">
          <defs><path id="cs" d="M60 60 m-43 0 a43 43 0 1 1 86 0 a43 43 0 1 1 -86 0"/></defs>
          <circle cx="60" cy="60" r="58" fill="#E9B44C"/>
          <circle cx="60" cy="60" r="52" fill="none" stroke="#0D1230" stroke-width="1.4" stroke-dasharray="2 3"/>
          <text font-size="9.5" font-weight="700" fill="#0D1230" font-family="Hanken Grotesk, sans-serif"><textPath href="#cs" textLength="262" lengthAdjust="spacing">EduNova sertifikati • Tasdiqlangan •</textPath></text>
          <g transform="translate(42 42)" stroke="#0D1230" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path transform="scale(1.5)" d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.2 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/></g>
        </svg>
      </div>
    </div>
    <p class="muted no-print" style="text-align:center;margin-top:1.2rem">Ushbu sertifikatni istalgan vaqt <b>${location.origin}/#/certificate/${esc(c.code)}</b> manzili orqali tekshirish mumkin.</p>
  </div>`;
}

/* =====================================================================
   Profil
   ===================================================================== */
function weeklyPlanHtml(plan) {
  if (!plan) return `<p class="muted">Hozircha faol kursingiz yo'q. Bir kursga yozilib, haftalik rejangizni oling.</p>`;
  return `
  <p class="muted" style="margin-bottom:1rem">Kurs: <b style="color:var(--paper)">${esc(plan.courseTitle)}</b> • Haftasiga ${esc(plan.weeklyHours)} soat</p>
  <div class="plan-grid">
    ${plan.days.map((d) => `
      <div class="plan-day ${d.rest ? 'rest' : ''} ${d.lessons ? 'active' : ''}">
        <b>${esc(d.day)}</b>
        ${d.rest ? `<span class="muted">Dam olish</span>` : d.lessons ? `<span>${d.from === d.to ? `${d.from}-dars` : `${d.from}–${d.to}-darslar`}</span><small class="muted">${d.hours} soat</small>` : `<span class="muted">${d.done ? "Yakunlangan" : 'Erkin'}</span>`}
      </div>`).join('')}
  </div>`;
}

function certCardHtml(c) {
  return `<a class="cert-mini" href="#/certificate/${esc(c.code)}">
    ${ic('award')}
    <div><b>${esc(c.courseTitle)}</b><small class="muted">${fmtDate(c.issuedAt)} • ${esc(c.code)}</small></div>
  </a>`;
}

async function profileView() {
  if (!session.user) return redirect('/login', true);
  const [p, certs] = await Promise.all([
    api('/profile'),
    api('/certificates/mine').catch(() => ({ certificates: [] })),
  ]);
  let recs = { onboarded: false, recommended: [], plan: null, goal: null };
  if (session.user.role === 'user') recs = await api('/profile/recommendations').catch(() => recs);

  const u = p.user;
  session.user = u;
  renderNav();
  const mine = p.courses;
  const certificates = certs.certificates;
  const certByCourse = new Map(certificates.map((c) => [c.courseId, c]));

  return `
  <div class="wrap">
    ${u.birthdayBonusActive ? `<div class="bday-banner">${ic('gift')}<div><b>Tug'ilgan kuningiz bilan!</b><span>Sizga bugun uchun 1 kunlik Premium taqdim etildi.</span></div></div>` : ''}
    ${u.role === 'user' && !u.onboarded ? `<div class="onb-banner"><div><b>Sizga mos kurslarni bilib olmoqchimisiz?</b><span>30 soniyalik so'rovnomani to'ldiring — biz siz uchun kurs va haftalik reja tayyorlaymiz.</span></div><a class="btn primary sm" href="#/onboarding">Boshlash</a></div>` : ''}

    <div class="profile-head">
      <div class="avatar-edit-wrap">
        ${avatarImg(u.avatar, u.name, 84, u.frame)}
        <button class="icon-btn av-edit-btn" data-action="avatar-edit" aria-label="Rasmni o'zgartirish">${ic('edit')}</button>
      </div>
      <div>
        <h1 style="font-size:clamp(1.8rem,3.5vw,2.6rem)">${esc(u.name)}</h1>
        <div class="muted">${esc(u.email)}</div>
        <div class="badges">
          <span class="badge ${u.role === 'admin' ? 'gold' : ''}">${ic(u.role === 'admin' ? 'shield' : u.role === 'mentor' ? 'award' : 'user')}${u.role === 'admin' ? 'Admin' : u.role === 'mentor' ? 'Mentor' : 'Foydalanuvchi'}</span>
          <span class="badge ${u.verified ? 'green' : 'red'}">${ic(u.verified ? 'check' : 'x')}${u.verified ? 'Email tasdiqlangan' : 'Tasdiqlanmagan'}</span>
          <a class="gem-pill" href="#/shop" style="font-size:.9rem">${ic('gem')}${u.diamonds || 0} almaz</a>
          <a href="#/ranks">${rankBadge(u.rank)}</a> <span class="muted" style="font-size:.85rem">${u.xp || 0} ball${u.rank && u.rank.next ? ` · ${u.rank.next.name} gacha ${u.rank.next.min - (u.xp || 0)}` : ' · eng yuqori rank!'}</span>
          ${u.isPremium ? `<span class="badge gold">${ic('star')}Premium <span data-countdown="premium" data-until="${u.premiumUntil}"></span></span>` : ''}
        </div>
      </div>
      ${u.role === 'admin' ? `<a class="btn primary" style="margin-left:auto" href="#/admin">Admin panelga o'tish</a>` : ''}
      ${u.role === 'mentor' ? `<a class="btn ghost" style="margin-left:auto" href="#/mentors/${esc(u.id)}">Ommaviy profilim</a>` : ''}
    </div>

    <div class="grid-2">
      <div>
        <section class="box">
          <h2>Mening kurslarim</h2>
          ${mine.length ? `<ul class="mine">${mine.map((c) => {
            const cert = certByCourse.get(c.id);
            return `
            <li>
              <div class="mini-cover cover ${catOf(c).key}">${ic(catOf(c).icon)}</div>
              <div>
                <h3><a href="#/courses/${esc(c.id)}">${esc(c.title)}</a></h3>
                <small class="muted">${esc(c.mentor ? c.mentor.name : c.instructor)}, ${esc(c.lessons)} dars</small>
                ${c.completed ? `<div class="badge green sm" style="margin-top:.4rem">${ic('check')}Yakunlangan</div>` : `<div class="bar-h" style="height:6px;margin-top:.5rem;max-width:220px"><i style="width:${c.progress}%"></i></div>`}
              </div>
              <div class="row" style="gap:.4rem">
                ${!c.completed ? (c.hasLessons ? `<a class="btn primary sm" href="#/learn/${esc(c.id)}">${ic('play')}Davom etish</a>` : `<button class="btn ghost sm" data-action="mark-complete" data-id="${esc(c.id)}">Yakunlash</button>`) : cert ? `<a class="btn ok sm" href="#/certificate/${esc(cert.code)}">${ic('award')}Sertifikat</a>` : `<button class="btn primary sm" data-action="get-cert" data-id="${esc(c.id)}">${ic('award')}Sertifikat</button>`}
                <button class="btn ghost sm" data-action="unenroll" data-id="${esc(c.id)}" data-title="${esc(c.title)}" aria-label="Bekor qilish">${ic('x')}</button>
              </div>
            </li>`;
          }).join('')}</ul>`
            : `<div class="empty"><h3>Hali kursga yozilmagansiz</h3><p>Yo'nalishni tanlang va birinchi kursingizni boshlang.</p><a class="btn primary" href="#/courses">Kurslarni ko'rish</a></div>`}
        </section>

        ${u.role === 'user' ? `
        <section class="box">
          <h2>Sizga tavsiya etamiz</h2>
          ${!recs.onboarded
            ? `<div class="empty"><p>Tavsiyalar olish uchun qisqa so'rovnomani to'ldiring.</p><a class="btn primary" href="#/onboarding">So'rovnomani boshlash</a></div>`
            : recs.recommended.length ? `
              <p class="muted" style="margin-bottom:1rem">Maqsad: <b style="color:var(--paper)">${recs.goal ? esc(recs.goal.label) : ''}</b></p>
              <div class="course-grid" style="padding-bottom:0">${recs.recommended.slice(0, 4).map(courseCard).join('')}</div>`
              : `<p class="muted">Hozircha mos kurs topilmadi, tez orada yangi kurslar qo'shiladi.</p>`}
        </section>
        ${recs.onboarded ? `
        <section class="box">
          <h2>Haftalik reja</h2>
          ${weeklyPlanHtml(recs.plan)}
        </section>` : ''}
        ` : ''}

        <section class="box">
          <h2>Sertifikatlarim</h2>
          ${certificates.length ? `<div class="cert-mini-list">${certificates.map(certCardHtml).join('')}</div>` : `<p class="muted">Hali sertifikatingiz yo'q. Kursni yakunlab, birinchi sertifikatingizni oling.</p>`}
        </section>

        <section class="box">
          <h2>Ma'lumotlarni tahrirlash</h2>
          <form data-form="profile" novalidate>
            <div class="form-error" role="alert"></div>
            <div class="form-grid">
              <div class="field"><label for="pname">Ism va familiya</label><input id="pname" name="name" value="${esc(u.name)}" required minlength="2" maxlength="60"></div>
              <div class="field"><label for="pbday">Tug'ilgan sana</label><input id="pbday" name="birthday" type="date" value="${esc(u.birthday || '')}"></div>
            </div>
            <button class="btn primary" type="submit">Saqlash</button>
            ${u.role === 'user' ? `<a class="btn ghost" href="#/onboarding" style="margin-left:.5rem">Qiziqishlarni qayta belgilash</a>` : ''}
          </form>
        </section>
      </div>
      <div>
        <section class="box">
          <h2>Sessiya</h2>
          <p class="muted" style="font-size:.9rem">Access token qolgan vaqti</p>
          <div class="token-time" data-countdown="token">--:--</div>
          <p class="muted" style="font-size:.85rem;margin-bottom:1.1rem">Muddati tugagach, token refresh orqali avtomatik yangilanadi.</p>
          <button class="btn ghost sm block" data-action="refresh-token">${ic('refresh')}Tokenni hozir yangilash</button>
          <dl class="kv" style="margin-top:1.4rem">
            <div><dt>Access token</dt><dd>15 daqiqa</dd></div>
            <div><dt>Refresh token</dt><dd>7 kun (httpOnly)</dd></div>
            <div><dt>Ro'yxatdan o'tgan</dt><dd>${fmtDate(u.createdAt)}</dd></div>
          </dl>
        </section>
      </div>
    </div>
  </div>`;
}

function openAvatarModal() {
  const u = session.user;
  openModal(`
  <div class="modal-body">
    <button class="modal-x" data-action="close" aria-label="Yopish">${ic('x')}</button>
    <h3>Profil rasmi</h3>
    <div class="row" style="gap:1rem;align-items:center;margin:1rem 0">${avatarImg(u.avatar, u.name, 72, u.frame)}<button class="link-btn" data-action="avatar-clear">Rasmni olib tashlash</button></div>
    <div class="tabs" role="tablist" style="margin-bottom:1rem;flex-wrap:wrap">
      <button class="tab" data-action="avatar-tab" data-tab="preset" aria-selected="true">${ic('star')} Tayyor avatarlar</button>
      <button class="tab" data-action="avatar-tab" data-tab="url" aria-selected="false">${ic('link')} Havola (URL)</button>
      <button class="tab" data-action="avatar-tab" data-tab="upload" aria-selected="false">${ic('upload')} Rasm yuklash</button>
    </div>
    <div id="avatar-tab-preset">
      <p class="muted" style="margin-bottom:.9rem;font-size:.88rem">Istalgan avatarni tanlang — darhol saqlanadi.</p>
      <div class="preset-grid">${PRESET_AVATARS.map((p) => `
        <button type="button" class="preset-opt" data-action="avatar-preset" data-val="${p.key}" title="${esc(p.label)}" aria-label="${esc(p.label)}">
          ${presetImg(p.key, 64)}<span>${esc(p.label)}</span>
        </button>`).join('')}</div>
    </div>
    <form data-form="avatar-url" id="avatar-tab-url" style="display:none">
      <div class="form-error" role="alert"></div>
      <div class="field"><label for="av-url">Rasm manzili (https://)</label><input id="av-url" name="url" type="url" placeholder="https://..." required></div>
      <button class="btn primary block" type="submit">Saqlash</button>
    </form>
    <form data-form="avatar-upload" id="avatar-tab-upload" style="display:none">
      <div class="form-error" role="alert"></div>
      <div class="field"><label for="av-file">Kompyuteringizdan rasm tanlang (PNG/JPEG/WEBP, 190 KB gacha)</label><input id="av-file" name="file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" required></div>
      <button class="btn primary block" type="submit">Yuklash</button>
    </form>
  </div>`, 'sm');
}

/* =====================================================================
   Admin panel
   ===================================================================== */
const WEEKDAYS = ['Yak', 'Dush', 'Sesh', 'Chor', 'Pay', 'Jum', 'Shan'];

function kpi(v, l) { return `<div class="kpi"><b>${esc(v)}</b><span>${esc(l)}</span></div>`; }

function adminCoursesTab() {
  return `
    <div class="toolbar"><h2 style="font-size:1.4rem">Kurslarni boshqarish</h2><button class="btn primary sm" data-action="course-new">${ic('plus')}Yangi kurs</button></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Kurs</th><th>Mentor</th><th>Daraja</th><th>Narx</th><th>O'quvchilar</th><th></th></tr></thead>
      <tbody>${state.courses.map((c) => `
        <tr>
          <td><b>${esc(c.title)}</b><small>${esc(c.category)}${c.premium ? ' • Premium' : ''}</small></td>
          <td>${c.mentor ? esc(c.mentor.name) : `<span class="muted">${esc(c.instructor)}</span>`}</td>
          <td>${esc(c.level)}</td>
          <td>${esc(price(c.price))}</td>
          <td>${esc(c.students)}</td>
          <td><div class="actions">
            <button class="icon-btn" data-action="course-edit" data-id="${esc(c.id)}" aria-label="Tahrirlash">${ic('edit')}</button>
            <button class="icon-btn del" data-action="course-del" data-id="${esc(c.id)}" data-title="${esc(c.title)}" aria-label="O'chirish">${ic('trash')}</button>
          </div></td>
        </tr>`).join('') || `<tr><td colspan="6"><div class="empty"><h3>Kurslar yo'q</h3><p>Birinchi kursni qo'shing.</p></div></td></tr>`}</tbody>
    </table></div>`;
}

function adminUsersTab() {
  return `
    <div class="toolbar"><h2 style="font-size:1.4rem">Foydalanuvchilar</h2></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Foydalanuvchi</th><th>Rol</th><th>Holat</th><th>Kurslar</th><th>Sana</th><th></th></tr></thead>
      <tbody>${(state.admin.users || []).map((u) => {
        const me = u.id === session.user.id;
        return `<tr>
          <td><div class="row" style="gap:.6rem;align-items:center">${avatarImg(u.avatar, u.name, 32)}<div><b>${esc(u.name)}</b><small>${esc(u.email)}</small></div></div></td>
          <td><select class="role-sel" data-change="role" data-id="${esc(u.id)}" ${me ? 'disabled' : ''} aria-label="Rol">
            <option value="user" ${u.role === 'user' ? 'selected' : ''}>user</option>
            <option value="mentor" ${u.role === 'mentor' ? 'selected' : ''}>mentor</option>
            <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>admin</option></select></td>
          <td><span class="badge ${u.verified ? 'green' : 'red'}">${u.verified ? 'Tasdiqlangan' : 'Kutilmoqda'}</span>${u.isPremium ? `<span class="badge gold" style="margin-left:.3rem">${ic('star')}</span>` : ''}</td>
          <td>${esc(u.enrollments)}</td>
          <td>${fmtDate(u.createdAt)}</td>
          <td><div class="actions">${me ? '' : `<button class="icon-btn del" data-action="user-del" data-id="${esc(u.id)}" data-title="${esc(u.name)}" aria-label="O'chirish">${ic('trash')}</button>`}</div></td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
}

function adminMentorsTab() {
  const list = state.admin.mentors || [];
  return `
    <div class="toolbar"><h2 style="font-size:1.4rem">Mentorlar</h2><button class="btn primary sm" data-action="mentor-new">${ic('plus')}Yangi mentor</button></div>
    <div class="mentor-grid big">${list.map((m) => `
      <div class="mentor-card">
        ${mentorImg(m.avatarKey, 72)}
        <h3>${esc(m.name)}</h3><small class="muted">${esc(m.title)}</small>
        <p class="clamp" style="margin-top:.5rem">${esc(m.bio)}</p>
        <div class="row between" style="margin-top:1rem"><small class="muted">${m.courseCount} kurs • ${m.studentCount} o'quvchi</small>
          <button class="icon-btn" data-action="mentor-edit" data-id="${esc(m.id)}" aria-label="Tahrirlash">${ic('edit')}</button>
        </div>
      </div>`).join('') || '<p class="muted">Hali mentor yo\'q.</p>'}</div>`;
}

function adminMessagesTab() {
  const list = state.admin.messages || [];
  const f = state.admin.msgFilter;
  return `
    <div class="toolbar">
      <h2 style="font-size:1.4rem">Murojaatlar</h2>
      <div class="chips">
        <button class="chip" data-action="msg-filter" data-val="open" aria-pressed="${f === 'open'}">Ochiq</button>
        <button class="chip" data-action="msg-filter" data-val="answered" aria-pressed="${f === 'answered'}">Javob berilgan</button>
        <button class="chip" data-action="msg-filter" data-val="all" aria-pressed="${f === 'all'}">Barchasi</button>
      </div>
    </div>
    <div class="msg-list">${list.length ? list.map((m) => `
      <div class="msg-card ${m.status}">
        <div class="row between" style="align-items:flex-start">
          <div><b>${esc(m.subject)}</b><small class="muted"> — ${esc(m.name)} (${esc(m.email)})</small></div>
          <div class="row" style="gap:.4rem"><span class="badge ${m.status === 'open' ? 'red' : 'green'}">${m.status === 'open' ? 'Ochiq' : 'Javob berilgan'}</span>
            <button class="icon-btn del" data-action="msg-del" data-id="${esc(m.id)}" aria-label="O'chirish">${ic('trash')}</button></div>
        </div>
        <p style="margin-top:.6rem">${esc(m.text)}</p>
        <small class="muted">${fmtDate(m.createdAt)}</small>
        ${m.reply ? `<div class="msg-reply"><b>Javob:</b> ${esc(m.reply)}</div>` : `
        <form data-form="msg-reply" data-id="${esc(m.id)}" class="row" style="margin-top:.8rem;gap:.5rem">
          <input name="reply" placeholder="Javobingizni yozing..." required minlength="2" maxlength="1000" style="flex:1">
          <button class="btn primary sm" type="submit">Yuborish</button>
        </form>`}
      </div>`).join('') : '<p class="muted">Xabarlar yo\'q.</p>'}</div>`;
}

function adminHtml() {
  const d = state.admin.data;
  const s = d.stats;
  const maxSign = Math.max(1, ...d.signups.map((x) => x.count));
  const maxStud = Math.max(1, ...d.popular.map((x) => x.students));
  const tab = state.admin.tab;
  const tabs = { courses: adminCoursesTab, users: adminUsersTab, mentors: adminMentorsTab, messages: adminMessagesTab };

  return `
  <div class="wrap">
    <div class="page-head">
      <h1 style="font-size:clamp(2rem,4vw,3rem)">Admin panel</h1>
      <p>Platformaning umumiy holati, kurslar, mentorlar, foydalanuvchilar va murojaatlarni boshqarish.</p>
    </div>
    <div class="kpis">
      ${kpi(s.users, 'foydalanuvchi')}${kpi(s.mentors, 'mentor')}${kpi(s.courses, 'kurs')}${kpi(s.enrollments, 'yozilish')}${kpi(s.certificates, 'sertifikat')}${kpi(price(s.revenue), 'summasi')}
    </div>
    <div class="kpis sm">
      ${kpi(s.premiumUsers, 'premium foydalanuvchi')}${kpi(s.premiumCourses, 'premium kurs')}${kpi(s.completions, 'yakunlangan kurs')}${kpi(s.reviews, 'sharh')}${kpi(s.openMessages, 'ochiq murojaat')}
    </div>
    <div class="admin-grid">
      <section class="box">
        <h2>So'nggi 7 kunda ro'yxatdan o'tganlar</h2>
        <div class="chart" role="img" aria-label="Kunlik ro'yxatdan o'tishlar grafigi">
          ${d.signups.map((x) => `<div class="bar"><i style="--h:${Math.round((x.count / maxSign) * 100)}%"></i><span>${x.count}</span><small>${WEEKDAYS[new Date(`${x.date}T00:00:00Z`).getUTCDay()]}</small></div>`).join('')}
        </div>
      </section>
      <section class="box">
        <h2>Ommabop kurslar</h2>
        <ol class="ranked" style="padding-left:0">${d.popular.map((c) => `
          <li><div class="row-top"><span>${esc(c.title)}</span><b>${esc(c.students)}</b></div><div class="bar-h"><i style="width:${Math.round((c.students / maxStud) * 100)}%"></i></div></li>`).join('')}</ol>
      </section>
    </div>
    <div class="tabs" role="tablist">
      <button class="tab" role="tab" data-action="tab" data-tab="courses" aria-selected="${tab === 'courses'}">Kurslar</button>
      <button class="tab" role="tab" data-action="tab" data-tab="users" aria-selected="${tab === 'users'}">Foydalanuvchilar</button>
      <button class="tab" role="tab" data-action="tab" data-tab="mentors" aria-selected="${tab === 'mentors'}">Mentorlar</button>
      <button class="tab" role="tab" data-action="tab" data-tab="messages" aria-selected="${tab === 'messages'}">Murojaatlar ${s.openMessages ? `<span class="pip">${s.openMessages}</span>` : ''}</button>
    </div>
    <div id="admin-tab-body">${tabs[tab]()}</div>
  </div>`;
}

async function adminView() {
  if (!session.user) return redirect('/login', true);
  if (session.user.role !== 'admin') {
    return `<div class="wrap forbidden"><h1>403: ruxsat yo'q</h1><p>Bu sahifa faqat administratorlar uchun. Agar bu xato deb hisoblasangiz, admin bilan bog'laning.</p><a class="btn primary" href="#/">Bosh sahifaga qaytish</a></div>`;
  }
  await reloadAdmin(false);
  return adminHtml();
}

async function reloadAdmin(render = true) {
  const [dash, list] = await Promise.all([api('/admin/dashboard'), api('/courses', { auth: false })]);
  state.admin.data = dash;
  state.courses = list.courses;
  if (state.admin.tab === 'users') state.admin.users = (await api('/admin/users')).users;
  if (state.admin.tab === 'mentors') state.admin.mentors = (await api('/admin/mentors')).mentors;
  if (state.admin.tab === 'messages') {
    const q = state.admin.msgFilter === 'all' ? '' : `?status=${state.admin.msgFilter}`;
    state.admin.messages = (await api(`/admin/messages${q}`)).messages;
  }
  if (render && currentPath() === '/admin') view.innerHTML = adminHtml();
}

async function switchAdminTab(tab) {
  state.admin.tab = tab;
  if (tab === 'users' && !state.admin.users) state.admin.users = (await api('/admin/users')).users;
  if (tab === 'mentors' && !state.admin.mentors) state.admin.mentors = (await api('/admin/mentors')).mentors;
  if (tab === 'messages') {
    const q = state.admin.msgFilter === 'all' ? '' : `?status=${state.admin.msgFilter}`;
    state.admin.messages = (await api(`/admin/messages${q}`)).messages;
  }
  view.innerHTML = adminHtml();
}

function parseLines(text) { return String(text || '').split('\n').map((l) => l.trim()).filter(Boolean); }
function parseSyllabusText(text) {
  return parseLines(text).map((line) => {
    const [title, topicsRaw] = line.split('::');
    return { title: (title || '').trim(), topics: (topicsRaw || '').split(',').map((t) => t.trim()).filter(Boolean) };
  }).filter((w) => w.title);
}
function syllabusToText(syllabus) {
  return (syllabus || []).map((w) => `${w.title}${w.topics.length ? ' :: ' + w.topics.join(', ') : ''}`).join('\n');
}

function openCourseForm(id) {
  const c = id ? state.courses.find((x) => x.id === id) : null;
  const mentors = state.admin.mentors || [];
  const v = (k, d = '') => esc(c ? c[k] : d);
  openModal(`
    <div class="modal-body">
      <button class="modal-x" data-action="close" aria-label="Yopish">${ic('x')}</button>
      <h3>${c ? 'Kursni tahrirlash' : "Yangi kurs qo'shish"}</h3>
      <form data-form="course" novalidate>
        <div class="form-error" role="alert"></div>
        <input type="hidden" name="id" value="${c ? esc(c.id) : ''}">
        <div class="form-grid">
          <div class="field full"><label for="c-title">Kurs nomi</label><input id="c-title" name="title" value="${v('title')}" required maxlength="80"></div>
          <div class="field full"><label for="c-desc">Tavsif</label><textarea id="c-desc" name="description" required maxlength="600">${v('description')}</textarea></div>
          <div class="field"><label for="c-cat">Yo'nalish</label><select id="c-cat" name="category">${Object.keys(CATS).map((k) => `<option ${c && c.category === k ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select></div>
          <div class="field"><label for="c-lvl">Daraja</label><select id="c-lvl" name="level">${LEVELS.map((k) => `<option ${c && c.level === k ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select></div>
          <div class="field"><label for="c-mentor">Mentor</label><select id="c-mentor" name="mentorId"><option value="">— tanlanmagan —</option>${mentors.map((m) => `<option value="${esc(m.id)}" ${c && c.mentor && c.mentor.id === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></div>
          <div class="field"><label for="c-price">Narx (so'm)</label><input id="c-price" name="price" type="number" min="0" step="1000" value="${v('price', 0)}" required></div>
          <div class="field"><label for="c-dur">Davomiylik (soat)</label><input id="c-dur" name="durationHours" type="number" min="1" max="500" value="${v('durationHours', 20)}" required></div>
          <div class="field"><label for="c-les">Darslar soni</label><input id="c-les" name="lessons" type="number" min="1" max="500" value="${v('lessons', 20)}" required></div>
          <div class="field"><label for="c-ins">Mentor ismi (agar ro'yxatda yo'q bo'lsa)</label><input id="c-ins" name="instructor" value="${v('instructor')}" required maxlength="60"></div>
          <div class="field full"><label class="row" style="gap:.5rem;align-items:center"><input type="checkbox" name="premium" style="width:auto" ${c && c.premium ? 'checked' : ''}> <span>Premium kurs</span></label></div>
          <div class="field full"><label for="c-tags">Teglar (vergul bilan)</label><input id="c-tags" name="tags" value="${esc((c?.tags || []).join(', '))}" placeholder="nodejs, api, backend"></div>
          <div class="field full"><label for="c-wyl">Nimalarni o'rganasiz (har qatorda bitta)</label><textarea id="c-wyl" name="whatYouWillLearn" placeholder="Har qatorga bitta band">${esc((c?.whatYouWillLearn || []).join('\n'))}</textarea></div>
          <div class="field full"><label for="c-req">Talablar (har qatorda bitta)</label><textarea id="c-req" name="requirements">${esc((c?.requirements || []).join('\n'))}</textarea></div>
          <div class="field full"><label for="c-syl">Kurs dasturi (har qatorda: Sarlavha :: mavzu1, mavzu2)</label><textarea id="c-syl" name="syllabus" rows="4" placeholder="Node.js asoslari :: Event loop, Modullar, NPM">${esc(syllabusToText(c?.syllabus))}</textarea></div>
        </div>
        <div class="row end" style="margin-top:.4rem"><button type="button" class="btn ghost" data-action="close">Bekor qilish</button><button class="btn primary" type="submit">${c ? 'Saqlash' : "Qo'shish"}</button></div>
      </form>
    </div>`);
}

function openMentorForm(id) {
  const m = id ? (state.admin.mentors || []).find((x) => x.id === id) : null;
  openModal(`
    <div class="modal-body">
      <button class="modal-x" data-action="close" aria-label="Yopish">${ic('x')}</button>
      <h3>${m ? 'Mentorni tahrirlash' : "Yangi mentor qo'shish"}</h3>
      <form data-form="mentor" novalidate>
        <div class="form-error" role="alert"></div>
        <input type="hidden" name="id" value="${m ? esc(m.id) : ''}">
        <div class="form-grid">
          ${!m ? `
          <div class="field"><label for="m-name">Ism va familiya</label><input id="m-name" name="name" required maxlength="60"></div>
          <div class="field"><label for="m-email">Email</label><input id="m-email" name="email" type="email" required></div>
          ` : `<div class="field full"><label for="m-name">Ism va familiya</label><input id="m-name" name="name" value="${esc(m.name)}" required maxlength="60"></div>`}
          <div class="field full"><label for="m-title">Lavozim</label><input id="m-title" name="title" value="${m ? esc(m.title) : ''}" required maxlength="80" placeholder="Masalan: Backend arxitektor"></div>
          <div class="field full"><label for="m-spec">Mutaxassislik</label><input id="m-spec" name="specialty" value="${m ? esc(m.specialty) : ''}" maxlength="80"></div>
          <div class="field full"><label for="m-bio">Bio</label><textarea id="m-bio" name="bio" required minlength="20" maxlength="600">${m ? esc(m.bio) : ''}</textarea></div>
          <div class="field full"><label for="m-ach">Yutuqlar (har qatorda bitta)</label><textarea id="m-ach" name="achievements">${m ? esc((m.achievements || []).join('\n')) : ''}</textarea></div>
          <div class="field full"><label>Avatar</label><div class="avatar-pick">${MENTOR_AVATARS.map((k) => `<button type="button" class="avatar-opt ${(m ? m.avatarKey : 'm-jasur') === k ? 'sel' : ''}" data-action="pick-mentor-avatar" data-val="${k}">${mentorImg(k, 48)}</button>`).join('')}</div>
          <input type="hidden" name="avatarKey" value="${m ? esc(m.avatarKey) : 'm-jasur'}"></div>
        </div>
        <div class="row end" style="margin-top:.4rem"><button type="button" class="btn ghost" data-action="close">Bekor qilish</button><button class="btn primary" type="submit">${m ? 'Saqlash' : "Qo'shish"}</button></div>
      </form>
    </div>`);
}

/* =====================================================================
   404 / xato
   ===================================================================== */
async function notFound() {
  return `<div class="wrap forbidden"><h1>404: sahifa topilmadi</h1><p>Siz izlagan sahifa mavjud emas yoki ko'chirilgan.</p><a class="btn primary" href="#/">Bosh sahifaga qaytish</a></div>`;
}
const errorView = (e) => `<div class="wrap forbidden"><h1>Xatolik yuz berdi</h1><p>${esc(e.message || "Noma'lum xatolik")}</p><button class="btn primary" data-action="retry">Qayta urinish</button></div>`;


/* =====================================================================
   Darslar (o'quv maydoni) va Almaz do'koni
   ===================================================================== */
async function refreshUser() {
  const p = await api('/profile');
  session.user = p.user;
  renderNav();
  return p.user;
}

function lessonTextHtml(text) {
  return String(text).split('~~~').map((part, i) => {
    if (i % 2) return `<pre class="code"><code>${esc(part.replace(/^\n+|\n+$/g, ''))}</code></pre>`;
    return part.split(/\n{2,}/).map((b) => b.trim()).filter(Boolean).map((b) => {
      const lines = b.split('\n');
      const bullets = lines.filter((l) => l.startsWith('- '));
      if (bullets.length && bullets.length >= lines.length - 1) {
        const head = lines[0].startsWith('- ') ? '' : `<p>${esc(lines[0])}</p>`;
        return `${head}<ul>${bullets.map((l) => `<li>${esc(l.slice(2))}</li>`).join('')}</ul>`;
      }
      return `<p>${lines.map(esc).join('<br>')}</p>`;
    }).join('');
  }).join('');
}

function deckHtml(slides) {
  const labels = { topic: 'Mavzu', info: "Ma'lumot", phrases: 'Muhim iboralar va qo\'llanilishi', example: 'Kichik misol' };
  const body = (sl) => {
    if (sl.k === 'topic') return `<h2>${esc(sl.title)}</h2><p>${esc(sl.text)}</p>`;
    if (sl.k === 'info') return `<h2>Asosiy ma'lumotlar</h2><ul>${sl.items.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>`;
    if (sl.k === 'phrases') return `<h2>Qanday ishlatiladi</h2><div class="phr">${sl.items.map(([a, b]) => `<div class="phr-row"><code>${esc(a)}</code><span>${esc(b)}</span></div>`).join('')}</div>`;
    return `<h2>Amalda ko'ramiz</h2>${sl.code ? `<pre class="code"><code>${esc(sl.code)}</code></pre>` : `<div class="ex-text">${esc(sl.text)}</div>`}${sl.note ? `<div class="ex-note"><span>💡</span><span>${esc(sl.note)}</span></div>` : ''}`;
  };
  return `<div class="deck" data-deck data-cur="0" data-total="${slides.length}">
    <div class="deck-stage">${slides.map((sl, i) => `<section class="slide slide-${sl.k} ${i === 0 ? 'active' : ''}" data-i="${i}"><span class="slide-tag">${labels[sl.k]} · ${i + 1}/${slides.length}</span>${body(sl)}</section>`).join('')}</div>
    <div class="deck-bar">
      <button type="button" class="btn ghost sm" data-action="slide-prev" disabled>← Orqaga</button>
      <div class="deck-dots">${slides.map((_, i) => `<b data-action="slide-go" data-i="${i}" class="${i === 0 ? 'on' : ''}"></b>`).join('')}</div>
      <button type="button" class="btn primary sm" data-action="slide-next">Keyingisi →</button>
    </div>
  </div>`;
}

function setSlide(deck, i) {
  const total = Number(deck.dataset.total);
  i = Math.max(0, Math.min(total - 1, i));
  deck.dataset.cur = i;
  $$('.slide', deck).forEach((el, k) => { el.classList.toggle('active', k === i); el.classList.toggle('past', k < i); });
  $$('.deck-dots b', deck).forEach((b, k) => b.classList.toggle('on', k === i));
  $('[data-action="slide-prev"]', deck).disabled = i === 0;
  const next = $('[data-action="slide-next"]', deck);
  next.textContent = i === total - 1 ? "Uy ishiga o'tish ↓" : 'Keyingisi →';
  if (i === total - 1) $('#hw')?.classList.remove('is-hidden');
}

function questionHtml(q) {
  const fb = q.answered
    ? (q.correct ? `<span class="ok-t">To'g'ri! +${q.reward} 💎</span>` : `<span class="bad-t">Noto'g'ri.</span>`) + (q.explain ? ` <span class="muted">${esc(q.explain)}</span>` : '')
    : '';
  return `
  <div class="q-card" data-q="${q.i}">
    <div class="q-top"><span class="q-diff ${q.hard ? 'hard' : 'easy'}">${q.hard ? 'Qiyin' : 'Oddiy'}</span>${gem(`+${q.reward}`)}</div>
    <div class="q-text">${q.i + 1}. ${esc(q.q)}</div>
    ${q.options.map((o, j) => `<button type="button" class="opt ${q.answered ? (j === q.answer ? 'right' : (j === q.choice ? 'wrong' : '')) : ''}" data-action="answer" data-q="${q.i}" data-choice="${j}" ${q.answered ? 'disabled' : ''}>${esc(o)}</button>`).join('')}
    <div class="q-feedback">${fb}</div>
  </div>`;
}

function lessonEndHtml(cid, next, isPractical, completed, bonus = 0) {
  if (isPractical || (completed && next === '')) {
    return `<div class="done-banner"><b>🎉 Kurs yakunlandi!</b><p class="muted" style="margin:.4rem 0 .9rem">${bonus ? `Amaliy ish uchun +${bonus} almaz qo'shildi! ` : ''}Endi sertifikat olishingiz va sharh qoldirishingiz mumkin.</p><a class="btn primary" href="#/courses/${esc(cid)}">${ic('award')}Sertifikatga o'tish</a></div>`;
  }
  if (next === '') return '';
  return `<div class="lesson-foot"><span class="muted">Uy ishi bajarildi ✔</span><a class="btn primary" href="#/learn/${esc(cid)}/${next}">${next === 'p' ? "Amaliy ishga o'tish" : 'Keyingi dars'} →</a></div>`;
}

async function learnView(params) {
  if (!session.user) return redirect('/login', true);
  const cid = params.id;
  let o;
  try { o = await api(`/learn/${enc(cid)}`); }
  catch (e) {
    if (e.code === 'NOT_ENROLLED' || e.code === 'NO_LESSONS') { toast(e.message, 'err'); return redirect(`/courses/${cid}`); }
    throw e;
  }
  if (params.n === undefined) {
    const nextL = o.lessons.find((l) => !l.done && !l.locked);
    const target = nextL ? nextL.n : (o.practical && !o.practical.done && !o.practical.locked ? 'p' : 0);
    location.hash = `#/learn/${enc(cid)}/${target}`;
    return null;
  }
  let d;
  try { d = await api(`/learn/${enc(cid)}/lessons/${enc(params.n)}`); }
  catch (e) {
    if (e.code === 'LOCKED') { toast(e.message, 'err'); return redirect(`/learn/${cid}`); }
    throw e;
  }
  const L = d.lesson;
  const nextKey = d.nav.next === null ? '' : String(d.nav.next);
  const showHw = d.done || d.lesson.questions.some((q) => q.answered);
  const cur = String(L.n);
  const item = (key, label, st, icon) => {
    const inner = `<span class="les-num ${st.done ? 'done' : ''} ${key === 'p' ? 'prac' : ''}">${st.done ? ic('check') : st.locked ? ic('lock') : key === 'p' ? ic('award') : Number(key) + 1}</span><span>${esc(label)}</span>`;
    const act = cur === String(key) ? 'active' : '';
    return st.locked ? `<div class="lesson-item locked ${act}">${inner}</div>` : `<a class="lesson-item ${act}" href="#/learn/${esc(cid)}/${key}">${inner}</a>`;
  };
  return `
  <div class="wrap learn-grid">
    <aside class="lesson-nav">
      <a class="muted" href="#/courses/${esc(cid)}" style="font-size:.85rem">← Kurs sahifasi</a>
      <h3>${esc(o.course.title)}</h3>
      <div class="bar-h" style="height:6px;margin:.5rem 0 .2rem"><i style="width:${o.progress}%"></i></div>
      <small class="muted">${o.progress}% bajarildi</small>
      <div style="margin-top:.8rem">
        ${o.lessons.map((l) => item(l.n, l.title, l)).join('')}
        ${o.practical ? item('p', o.practical.title, o.practical) : ''}
      </div>
    </aside>
    <section class="lesson-main" data-course="${esc(cid)}" data-n="${esc(cur)}" data-next="${esc(nextKey)}" data-practical="${L.isPractical ? 1 : 0}">
      <span class="tag light">${L.isPractical ? 'Amaliy ish' : `${Number(L.n) + 1}-dars`}</span>
      <h1>${esc(L.title)}</h1>
      ${L.slides ? deckHtml(L.slides) : `<div class="lesson-body">${lessonTextHtml(L.text)}</div>`}
      <div id="hw" class="hw-wrap ${L.slides && !showHw ? 'is-hidden' : ''}">
      <div class="hw-head"><h2>${L.isPractical ? 'Amaliy ish savollari' : 'Uy ishi'}</h2><span class="muted">Har savolga bir marta javob beriladi</span></div>
      ${L.questions.map(questionHtml).join('')}
      </div>
      <div id="lesson-end">${d.done ? lessonEndHtml(cid, nextKey, L.isPractical, o.completed) : ''}</div>
      <div class="lesson-foot">${d.nav.prev !== null ? `<a class="btn ghost sm" href="#/learn/${esc(cid)}/${d.nav.prev}">← Oldingi dars</a>` : '<span></span>'}</div>
    </section>
  </div>`;
}

async function shopView() {
  if (!session.user) return redirect('/login', true);
  const s = await api('/shop');
  session.user.diamonds = s.diamonds;
  renderNav();
  const u = session.user;
  const btn = (type, it) => it.owned
    ? (it.equipped ? `<span class="badge green">${ic('check')}Kiyilgan</span>` : `<button class="btn primary sm" data-action="equip" data-type="${type}" data-key="${it.key}">Kiyish</button>`)
    : `<button class="btn ghost sm" data-action="buy" data-type="${type}" data-key="${it.key}" data-name="${esc(it.name)}" data-price="${it.price}"><span class="price-gem">${ic('gem')}${it.price}</span> Sotib olish</button>`;
  return `
  <div class="wrap">
    <div class="shop-top">
      <div><h1 style="font-size:clamp(1.8rem,4vw,2.8rem)">Almazlar do'koni</h1>
        <p class="muted" style="margin-top:.4rem">Uy ishlariga to'g'ri javob bering: oddiy savol +${s.reward.easy}, qiyin savol +${s.reward.hard}, kurs amaliy ishi uchun +${s.reward.practicalBonus}.</p></div>
      <div class="gem-pill shop-bal">${ic('gem')}${s.diamonds}</div>
    </div>

    <section class="box">
      <h2>Premium kursni almazga oching</h2>
      <p class="muted" style="margin-bottom:1rem">${s.isPremium ? 'Sizda premium status bor — premium kurslarga bepul yozilasiz.' : `Bitta premium kurs narxi: ${s.unlockPrice} almaz.`}</p>
      <div class="unlock-list">${s.premiumCourses.map((c) => `
        <div class="unlock-row"><div class="grow"><b>${esc(c.title)}</b><div class="muted" style="font-size:.85rem">${esc(c.category)} · ${esc(c.level)} · ${c.lessons} dars</div></div>
        ${c.enrolled ? `<a class="btn ok sm" href="#/courses/${esc(c.id)}">Kursga o'tish</a>`
          : (c.unlocked || s.isPremium) ? `<a class="btn primary sm" href="#/courses/${esc(c.id)}">Yozilish</a>`
          : `<button class="btn ghost sm" data-action="unlock-course" data-id="${esc(c.id)}" data-title="${esc(c.title)}" data-price="${s.unlockPrice}"><span class="price-gem">${ic('gem')}${s.unlockPrice}</span> Ochish</button>`}</div>`).join('')}</div>
    </section>

    <section class="box">
      <div class="row between" style="align-items:center"><h2>Avatar ramkalari</h2>${u.frame ? `<button class="btn ghost sm" data-action="equip" data-type="frame" data-key="">Ramkani olib tashlash</button>` : ''}</div>
      <div class="shop-grid" style="margin-top:1rem">${s.frames.map((f) => `
        <div class="shop-item ${f.equipped ? 'eq' : ''}"><div class="prev">${avatarImg(u.avatar, u.name, 72, f.key)}</div><h3>${esc(f.name)}</h3><small>${esc(f.desc)}</small>${btn('frame', f)}</div>`).join('')}</div>
    </section>

    <section class="box">
      <h2>Premium avatarlar</h2>
      <p class="muted" style="margin-bottom:1rem">Harakatli effektlar bilan. Har biri ${s.avatars[0]?.price} almaz.</p>
      <div class="shop-grid">${s.avatars.map((a) => `
        <div class="shop-item ${a.equipped ? 'eq' : ''}"><div class="prev">${avatarImg(`/img/premium/${a.key}.svg`, a.name, 80, u.frame)}</div><h3>${esc(a.name)}</h3><small>${esc(a.desc)}</small>${btn('avatar', a)}</div>`).join('')}</div>
    </section>
  </div>`;
}


async function rankView() {
  const d = await api('/ranks');
  const me = d.me;
  const ladder = d.ranks;
  const curLv = me ? me.rank.level : 0;
  const top3 = d.top.slice(0, 3);
  const rest = d.top.slice(3);
  const medals = ['🥇', '🥈', '🥉'];
  const person = (t, size) => `<span class="who">${avatarImg(t.avatar, t.name, size, t.frame)}</span>`;
  return `
  <div class="wrap">
    <div class="rank-hero"><h1 style="font-size:clamp(1.8rem,4vw,2.8rem)">Reyting</h1>
      <p class="muted" style="margin-top:.4rem">Uy ishiga to'g'ri javob (+10/+15), dars va amaliy ish yakunlari uchun ball beriladi. Ball oshgan sari rank ko'tariladi.</p></div>

    ${me ? `<div class="rank-me">
      ${avatarImg(session.user.avatar, session.user.name, 64, session.user.frame)}
      <div class="grow"><div>${rankBadge(me.rank)} <b style="margin-left:.4rem">${me.xp} ball</b>${me.place ? ` <span class="muted">· ${me.place}-o'rin (${me.total} kishidan)</span>` : ''}</div>
        <div class="xp-bar" style="margin:.7rem 0 .3rem"><i style="width:${me.rank.next ? Math.min(100, Math.round(((me.xp - me.rank.min) / (me.rank.next.min - me.rank.min)) * 100)) : 100}%"></i></div>
        <small class="muted">${me.rank.next ? `${me.rank.next.name} rankigacha yana ${me.rank.next.min - me.xp} ball` : 'Siz eng yuqori ranktasiz!'} · ${me.lessons} ta dars bajarilgan</small></div>
    </div>` : `<div class="rank-me"><div class="grow">Reytingda o'z o'rningizni ko'rish uchun <a href="#/login"><b>tizimga kiring</b></a>.</div></div>`}

    <h2 style="margin-bottom:.8rem">6 ta rank</h2>
    <div class="ladder">${ladder.map((r) => `<div class="ladder-step ${r.level === curLv ? 'cur' : ''}"><span class="ico">${r.icon}</span>${rankBadge(r.level)}<small class="muted">${r.min}+ ball</small></div>`).join('')}</div>

    <h2 style="margin-bottom:.4rem">Top o'quvchilar</h2>
    ${d.top.length ? `
    <div class="podium">${top3.map((t, i) => `<div class="pod p${i + 1}"><span class="medal">${medals[i]}</span>${person(t, i === 0 ? 84 : 68)}<b>${esc(t.name)}</b>${rankBadge(t.rank)}<span class="price-gem" style="color:#9ff0e0">${t.xp} ball</span></div>`).join('')}</div>
    ${rest.length ? `<table class="rank-table"><tbody>${rest.map((t) => `<tr class="${session.user && session.user.id === t.id ? 'me' : ''}"><td class="pl">${t.place}</td><td><span class="who">${avatarImg(t.avatar, t.name, 40, t.frame)}<b>${esc(t.name)}</b> ${rankBadge(t.rank, true)}</span></td><td class="meta">${t.lessons} dars · ${t.courses} kurs</td><td class="xp">${t.xp}</td></tr>`).join('')}</tbody></table>` : ''}`
    : `<div class="box"><p class="muted">Hali hech kim ball to'plamagan. Birinchi bo'ling — darsni boshlang!</p></div>`}
  </div>`;
}

/* =====================================================================
   Router (dinamik parametrlar bilan)
   ===================================================================== */
const routeDefs = [
  { path: '/', view: home },
  { path: '/courses', view: coursesView },
  { path: '/courses/:id', view: courseDetailView },
  { path: '/mentors', view: mentorsView },
  { path: '/mentors/:id', view: mentorDetailView },
  { path: '/login', view: loginView },
  { path: '/register', view: registerView },
  { path: '/verify', view: verifyView },
  { path: '/onboarding', view: onboardingView },
  { path: '/profile', view: profileView },
  { path: '/certificate/:code', view: certificatePageView },
  { path: '/help', view: helpView },
  { path: '/learn/:id', view: learnView },
  { path: '/learn/:id/:n', view: learnView },
  { path: '/shop', view: shopView },
  { path: '/ranks', view: rankView },
  { path: '/admin', view: adminView },
];

function matchRoute(path) {
  const segs = path.split('/').filter(Boolean);
  for (const r of routeDefs) {
    const parts = r.path.split('/').filter(Boolean);
    if (parts.length !== segs.length) continue;
    const params = {};
    let ok = true;
    parts.forEach((p, i) => {
      if (p.startsWith(':')) params[p.slice(1)] = decodeURIComponent(segs[i]);
      else if (p !== segs[i]) ok = false;
    });
    if (ok) return { view: r.view, params };
  }
  return null;
}

let routeSeq = 0;
async function router() {
  const seq = ++routeSeq;
  clearTimers();
  closeModal();
  $('#nav').classList.remove('open');
  renderNav();
  view.innerHTML = '<div class="wrap"><div class="skeleton"></div></div>';
  const match = matchRoute(currentPath());
  let html;
  try {
    html = match ? await match.view(match.params || {}) : await notFound();
  } catch (e) {
    console.error(e);
    if (e.status === 401) return redirect('/login', true);
    html = errorView(e);
  }
  if (seq !== routeSeq || html == null) return;
  view.innerHTML = html;
  window.scrollTo(0, 0);
  view.focus({ preventScroll: true });
  startTimers();
  initStarInputs(view);
}

function initStarInputs(root) {
  $$('.star-input', root).forEach((wrap) => {
    const input = wrap.parentElement.querySelector('input[name="rating"]');
    const val = Number(input?.value || 0);
    if (val) $$('.star-btn', wrap).forEach((b, i) => b.classList.toggle('on', i < val));
  });
}

/* =====================================================================
   Amallar
   ===================================================================== */
function afterAuth() {
  const back = sessionStorage.getItem('returnTo');
  sessionStorage.removeItem('returnTo');
  ['pendingEmail', 'pendingMode', 'devCode', 'resendAt'].forEach((k) => sessionStorage.removeItem(k));
  let target = '#/profile';
  if (session.user.role === 'admin') target = '#/admin';
  else if (session.user.role === 'user' && !session.user.onboarded) target = '#/onboarding';
  else if (back && !['#/login', '#/register'].includes(back)) target = back;
  if (location.hash === target) router(); else location.hash = target;
}

function requireLogin() {
  if (session.user) return true;
  toast("Avval tizimga kiring yoki ro'yxatdan o'ting", 'err');
  redirect('/login', true);
  return false;
}

let avatarTab = 'preset';

const actions = {
  'toggle-menu'(el) {
    const open = $('#nav').classList.toggle('open');
    el.setAttribute('aria-expanded', String(open));
  },
  close: () => closeModal(),
  retry: () => router(),
  print: () => window.print(),


  'slide-next'(el) {
    const deck = el.closest('[data-deck]');
    const cur = Number(deck.dataset.cur), total = Number(deck.dataset.total);
    if (cur >= total - 1) { $('#hw')?.classList.remove('is-hidden'); $('#hw')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    setSlide(deck, cur + 1);
  },
  'slide-prev'(el) { const deck = el.closest('[data-deck]'); setSlide(deck, Number(deck.dataset.cur) - 1); },
  'slide-go'(el) { setSlide(el.closest('[data-deck]'), Number(el.dataset.i)); },

  async answer(el) {
    const main = el.closest('[data-course]');
    const card = el.closest('.q-card');
    const opts = $$('.opt', card);
    opts.forEach((b) => { b.disabled = true; });
    let r;
    try {
      r = await api(`/learn/${enc(main.dataset.course)}/lessons/${enc(main.dataset.n)}/answer`, { method: 'POST', body: { q: Number(el.dataset.q), choice: Number(el.dataset.choice) } });
    } catch (e) { opts.forEach((b) => { b.disabled = false; }); throw e; }
    opts.forEach((b, j) => { if (j === r.answer) b.classList.add('right'); else if (b === el) b.classList.add('wrong'); });
    $('.q-feedback', card).innerHTML = (r.correct ? `<span class="ok-t">To'g'ri! +${r.gained} 💎 · +${r.gained} ball</span>` : `<span class="bad-t">Noto'g'ri.</span>`) + (r.explain ? ` <span class="muted">${esc(r.explain)}</span>` : '');
    if (r.correct) { card.insertAdjacentHTML('beforeend', `<span class="gem-pop">+${r.gained} 💎</span>`); setTimeout(() => $('.gem-pop', card)?.remove(), 1500); }
    session.user.diamonds = r.diamonds;
    session.user.xp = r.totalXp; session.user.rank = r.rank;
    const g = $('#nav-gems'); if (g) g.textContent = r.diamonds;
    if (r.rankUp) { toast(`🎉 Yangi rank: ${r.rankUp.icon} ${r.rankUp.name}!`); renderNav(); }
    if (r.done) {
      $('#lesson-end').innerHTML = lessonEndHtml(main.dataset.course, main.dataset.next, main.dataset.practical === '1', r.courseCompleted, r.bonus);
      const num = $('.lesson-item.active .les-num');
      if (num) { num.classList.add('done'); num.innerHTML = ic('check'); }
      if (r.courseCompleted) toast(r.bonus ? `Kurs yakunlandi! +${r.bonus} almaz bonus 🎉` : 'Kurs yakunlandi! 🎉');
      else toast(`Uy ishi bajarildi ✔  Bu darsdan jami +${r.xp} ball`);
      $('#lesson-end').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  },

  async buy(el) {
    const ok = await confirmBox('Sotib olasizmi?', `"${el.dataset.name}" — ${el.dataset.price} almaz.`, 'Ha, sotib olish');
    if (!ok) return;
    await api('/shop/buy', { method: 'POST', body: { type: el.dataset.type, key: el.dataset.key } });
    toast('Sotib olindi! 🎉');
    await refreshUser();
    router();
  },

  async equip(el) {
    await api('/shop/equip', { method: 'POST', body: { type: el.dataset.type, key: el.dataset.key || null } });
    await refreshUser();
    toast('Saqlandi');
    router();
  },

  async 'unlock-course'(el) {
    if (!requireLogin()) return;
    const ok = await confirmBox('Premium kursni ochasizmi?', `"${el.dataset.title}" kursini ochish uchun ${el.dataset.price} almaz sarflanadi va siz kursga yozilasiz.`, 'Ha, ochish');
    if (!ok) return;
    await api('/shop/unlock-course', { method: 'POST', body: { courseId: el.dataset.id } });
    toast('Kurs ochildi va siz yozildingiz 🎉');
    await refreshUser();
    location.hash = `#/courses/${enc(el.dataset.id)}`;
    if (currentPath() === `/courses/${el.dataset.id}`) router();
  },

  async logout() {
    await api('/auth/logout', { method: 'POST', auth: false }).catch(() => {});
    setSession(null);
    state.enrolledMap = new Map();
    toast('Tizimdan chiqdingiz');
    if (currentPath() === '/') router(); else location.hash = '#/';
  },

  async enroll(el) {
    if (!requireLogin()) return;
    const id = el.dataset.id;
    el.disabled = true;
    try {
      await api(`/courses/${encodeURIComponent(id)}/enroll`, { method: 'POST' });
      toast('Kursga muvaffaqiyatli yozildingiz');
    } catch (e) {
      el.disabled = false;
      if (e.code === 'PREMIUM_REQUIRED') { toast(e.message, 'err'); return; }
      if (e.status !== 409) throw e;
    }
    router();
  },

  async unenroll(el) {
    const ok = await confirmBox('Kursdan chiqasizmi?', `"${el.dataset.title}" kursiga yozilishni bekor qilmoqchimisiz?`, 'Ha, bekor qilish');
    if (!ok) return;
    await api(`/courses/${encodeURIComponent(el.dataset.id)}/enroll`, { method: 'DELETE' });
    toast('Kursdan chiqdingiz');
    router();
  },

  async 'mark-complete'(el) {
    await api(`/courses/${encodeURIComponent(el.dataset.id)}/enroll/complete`, { method: 'POST' });
    toast('Tabriklaymiz! Kurs yakunlandi 🎉');
    router();
  },

  async 'get-cert'(el) {
    const name = await promptCertName();
    if (!name) return;
    const d = await api('/certificates', { method: 'POST', body: { courseId: el.dataset.id, fullName: name } });
    toast('Sertifikat tayyor!');
    location.hash = `#/certificate/${d.certificate.code}`;
  },

  'chip'(el) { state.filters.cat = el.dataset.cat; renderGrid(); },
  'chip-premium'(el) { state.filters.premium = el.dataset.premium; renderGrid(); },
  'reset-filters'() {
    state.filters = { q: '', cat: 'Hammasi', level: 'Hammasi', premium: 'Hammasi' };
    router();
  },

  'toggle-pass'(el) {
    const input = el.parentElement.querySelector('input');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    el.innerHTML = ic(show ? 'eye-off' : 'eye');
    el.setAttribute('aria-label', show ? 'Parolni yashirish' : "Parolni ko'rsatish");
  },


  async resend(el) {
    const email = sessionStorage.getItem('pendingEmail');
    if (!email) { toast("Avval ro'yxatdan o'ting", 'err'); return; }
    el.disabled = true;
    const isLogin = sessionStorage.getItem('pendingMode') === 'login';
    await api(isLogin ? '/auth/login/resend' : '/auth/resend', { method: 'POST', body: { email }, auth: false });
    sessionStorage.setItem('resendAt', String(Date.now() + 60000));
    toast('Yangi kod emailingizga yuborildi');
    router();
  },

  async 'refresh-token'() {
    await refresh();
    toast('Access token yangilandi');
  },

  'ob-interest'(el) {
    const active = el.getAttribute('aria-pressed') === 'true';
    const selected = $$('#ob-interests .chip[aria-pressed="true"]');
    if (!active && selected.length >= 5) { toast("Eng ko'pi 5 ta yo'nalish tanlang", 'err'); return; }
    el.setAttribute('aria-pressed', String(!active));
    const vals = $$('#ob-interests .chip[aria-pressed="true"]').map((b) => b.dataset.val);
    $('input[name="interests"]').value = vals.join(',');
  },
  'ob-goal'(el) {
    $$('#ob-goal .goal-card').forEach((b) => b.classList.remove('sel'));
    el.classList.add('sel');
    $('input[name="goal"]').value = el.dataset.val;
  },

  'avatar-edit': () => openAvatarModal(),
  'avatar-tab'(el) {
    avatarTab = el.dataset.tab;
    $$('.tab[data-action="avatar-tab"]').forEach((b) => b.setAttribute('aria-selected', String(b === el)));
    $('#avatar-tab-preset').style.display = avatarTab === 'preset' ? '' : 'none';
    $('#avatar-tab-url').style.display = avatarTab === 'url' ? '' : 'none';
    $('#avatar-tab-upload').style.display = avatarTab === 'upload' ? '' : 'none';
  },
  async 'avatar-preset'(el) {
    el.disabled = true;
    const d = await api('/profile/avatar', { method: 'PUT', body: { mode: 'preset', value: el.dataset.val } });
    session.user = d.user;
    closeModal();
    toast('Avatar yangilandi');
    router();
  },
  async 'avatar-clear'() {
    const d = await api('/profile/avatar', { method: 'PUT', body: { mode: 'clear' } });
    session.user = d.user;
    closeModal();
    toast('Rasm olib tashlandi');
    router();
  },

  'course-new': async (el) => { el.disabled = true; if (!state.admin.mentors) state.admin.mentors = (await api('/admin/mentors')).mentors; el.disabled = false; openCourseForm(); },
  'course-edit': async (el) => { if (!state.admin.mentors) state.admin.mentors = (await api('/admin/mentors')).mentors; openCourseForm(el.dataset.id); },
  async 'course-del'(el) {
    const ok = await confirmBox("Kursni o'chirasizmi?", `"${el.dataset.title}" kursi va unga yozilganlar ro'yxati o'chiriladi.`);
    if (!ok) return;
    await api(`/courses/${encodeURIComponent(el.dataset.id)}`, { method: 'DELETE' });
    toast("Kurs o'chirildi");
    await reloadAdmin();
  },
  async 'user-del'(el) {
    const ok = await confirmBox("Foydalanuvchini o'chirasizmi?", `${el.dataset.title} hisobi butunlay o'chiriladi.`);
    if (!ok) return;
    await api(`/admin/users/${encodeURIComponent(el.dataset.id)}`, { method: 'DELETE' });
    toast("Foydalanuvchi o'chirildi");
    state.admin.users = null;
    await switchAdminTab('users');
  },
  'mentor-new': () => openMentorForm(),
  'mentor-edit': (el) => openMentorForm(el.dataset.id),
  'pick-mentor-avatar'(el) {
    $$('.avatar-opt').forEach((b) => b.classList.remove('sel'));
    el.classList.add('sel');
    el.closest('form').querySelector('input[name="avatarKey"]').value = el.dataset.val;
  },

  async tab(el) { await switchAdminTab(el.dataset.tab); },
  async 'msg-filter'(el) {
    state.admin.msgFilter = el.dataset.val;
    state.admin.messages = null;
    await switchAdminTab('messages');
  },
  async 'msg-del'(el) {
    const ok = await confirmBox('Xabarni o\'chirasizmi?', "Bu amalni qaytarib bo'lmaydi.");
    if (!ok) return;
    await api(`/admin/messages/${encodeURIComponent(el.dataset.id)}`, { method: 'DELETE' });
    toast("Xabar o'chirildi");
    state.admin.messages = null;
    await switchAdminTab('messages');
  },
};

document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-action]');
  if (!el || !actions[el.dataset.action]) return;
  try {
    await actions[el.dataset.action](el, e);
  } catch (err) {
    if (err.status === 401) { toast('Sessiya tugagan. Qayta kiring.', 'err'); redirect('/login', true); } else toast(err.message, 'err');
  }
});

document.addEventListener('click', (e) => {
  const star = e.target.closest('.star-btn');
  if (!star) return;
  const wrap = star.closest('.star-input');
  const val = Number(star.dataset.val);
  wrap.dataset.stars = val;
  $$('.star-btn', wrap).forEach((b, i) => b.classList.toggle('on', i < val));
  wrap.parentElement.querySelector('input[name="rating"]').value = val;
});

/* =====================================================================
   Formalar
   ===================================================================== */
function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error('Faylni o\'qib bo\'lmadi'));
    r.readAsDataURL(file);
  });
}

const forms = {
  async login(f) {
    const body = { email: f.email.value.trim(), password: f.password.value };
    try {
      const d = await api('/auth/login', { method: 'POST', body, auth: false });
      // Admin: server darhol sessiya beradi (kod kerak emas)
      if (d.accessToken) {
        setSession(d);
        toast(`Xush kelibsiz, ${d.user.name.split(' ')[0]}!`);
        await loadEnrolled().catch(() => {});
        afterAuth();
        return;
      }
      // Oddiy foydalanuvchi: kod emailga yuborildi, uni kiritmaguncha kirib bo'lmaydi
      sessionStorage.setItem('pendingEmail', d.email);
      sessionStorage.setItem('pendingMode', 'login');
      sessionStorage.setItem('resendAt', String(Date.now() + 60000));
      toast('Kod emailingizga yuborildi');
      location.hash = '#/verify';
    } catch (e) {
      if (e.code === 'EMAIL_NOT_VERIFIED') {
        sessionStorage.setItem('pendingEmail', body.email.toLowerCase());
        sessionStorage.setItem('pendingMode', 'register');
        sessionStorage.setItem('resendAt', String(Date.now() + 60000));
        toast(e.message, 'err');
        location.hash = '#/verify';
        return;
      }
      throw e;
    }
  },

  async register(f) {
    const body = { name: f.name.value, email: f.email.value.trim(), password: f.password.value };
    const d = await api('/auth/register', { method: 'POST', body, auth: false });
    sessionStorage.setItem('pendingEmail', d.email);
    sessionStorage.setItem('pendingMode', 'register');
    sessionStorage.setItem('resendAt', String(Date.now() + 60000));
    toast('Tasdiqlash kodi emailingizga yuborildi');
    location.hash = '#/verify';
  },

  async verify(f) {
    const code = $$('[data-otp]', f).map((i) => i.value).join('');
    if (code.length !== 6) throw new Error("6 xonali kodni to'liq kiriting");
    const email = f.email.value.trim();
    const isLogin = sessionStorage.getItem('pendingMode') === 'login';
    const d = await api(isLogin ? '/auth/login/verify' : '/auth/verify', { method: 'POST', body: { email, code }, auth: false });
    setSession(d);
    toast(isLogin ? `Xush kelibsiz, ${d.user.name.split(' ')[0]}!` : 'Email tasdiqlandi. Xush kelibsiz!');
    await loadEnrolled().catch(() => {});
    afterAuth();
  },

  async onboarding(f) {
    const interests = f.interests.value.split(',').filter(Boolean);
    const goal = f.goal.value;
    if (!interests.length) throw new Error("Kamida bitta yo'nalishni tanlang");
    if (!goal) throw new Error('Maqsadingizni tanlang');
    const body = { interests, goal, level: f.level.value, weeklyHours: Number(f.weeklyHours.value), startDate: f.startDate.value };
    const d = await api('/profile/onboarding', { method: 'PUT', body });
    session.user = d.user;
    toast('Tavsiyalar tayyor!');
    location.hash = '#/profile';
    if (currentPath() === '/profile') router();
  },

  'cert-lookup'(f) {
    const code = f.code.value.trim().toUpperCase();
    if (!code) throw new Error('Kodni kiriting');
    location.hash = `#/certificate/${encodeURIComponent(code)}`;
  },

  async contact(f) {
    const body = { name: f.name.value, email: f.email.value, subject: f.subject.value, text: f.text.value };
    await api('/messages', { method: 'POST', body, optionalAuth: true, auth: false });
    toast('Xabaringiz yuborildi. Tez orada javob beramiz.');
    f.reset();
    if (session.user) { f.name.value = session.user.name; f.email.value = session.user.email; }
  },

  async profile(f) {
    const d = await api('/profile', { method: 'PATCH', body: { name: f.name.value, birthday: f.birthday.value } });
    session.user = d.user;
    renderNav();
    toast("Ma'lumotlar saqlandi");
    router();
  },

  async 'avatar-url'(f) {
    const d = await api('/profile/avatar', { method: 'PUT', body: { mode: 'url', value: f.url.value.trim() } });
    session.user = d.user;
    closeModal();
    toast('Profil rasmi yangilandi');
    router();
  },

  async 'avatar-upload'(f) {
    const file = f.file.files[0];
    if (!file) throw new Error('Faylni tanlang');
    if (file.size > 190_000) throw new Error("Rasm hajmi 190 KB dan kichik bo'lsin");
    const dataUrl = await readFileAsDataUrl(file);
    const d = await api('/profile/avatar', { method: 'PUT', body: { mode: 'upload', value: dataUrl } });
    session.user = d.user;
    closeModal();
    toast('Profil rasmi yuklandi');
    router();
  },

  'cert-name'(f) {
    const fullName = f.fullName.value.trim();
    if (fullName.length < 3) throw new Error("Ism-familiya kamida 3 ta belgidan iborat bo'lsin");
    modal._certFinish?.(fullName);
    closeModal();
  },

  async review(f) {
    const courseId = f.dataset.course;
    const rating = Number(f.rating.value);
    if (!rating) throw new Error('Bahoni tanlang');
    await api(`/courses/${encodeURIComponent(courseId)}/reviews`, { method: 'POST', body: { rating, text: f.text.value } });
    toast('Sharhingiz uchun rahmat!');
    router();
  },

  async course(f) {
    const d = Object.fromEntries(new FormData(f));
    const id = d.id;
    delete d.id;
    ['price', 'durationHours', 'lessons'].forEach((k) => { d[k] = Number(d[k]); });
    d.premium = d.premium === 'on';
    d.tags = d.tags.split(',').map((t) => t.trim()).filter(Boolean);
    d.whatYouWillLearn = parseLines(d.whatYouWillLearn);
    d.requirements = parseLines(d.requirements);
    d.syllabus = parseSyllabusText(d.syllabus);
    if (id) await api(`/courses/${encodeURIComponent(id)}`, { method: 'PUT', body: d });
    else await api('/courses', { method: 'POST', body: d });
    closeModal();
    toast(id ? 'Kurs yangilandi' : "Kurs qo'shildi");
    state.admin.data = null;
    await reloadAdmin();
  },

  async mentor(f) {
    const d = Object.fromEntries(new FormData(f));
    const id = d.id;
    delete d.id;
    d.achievements = parseLines(d.achievements);
    if (id) await api(`/admin/mentors/${encodeURIComponent(id)}`, { method: 'PATCH', body: d });
    else {
      const r = await api('/admin/mentors', { method: 'POST', body: d });
      if (r.tempPassword) toast(`Mentor yaratildi. Vaqtinchalik parol: ${r.tempPassword}`);
    }
    closeModal();
    toast(id ? 'Mentor yangilandi' : "Mentor qo'shildi");
    state.admin.mentors = null;
    await switchAdminTab('mentors');
  },

  async 'msg-reply'(f) {
    await api(`/admin/messages/${encodeURIComponent(f.dataset.id)}`, { method: 'PATCH', body: { reply: f.reply.value } });
    toast('Javob yuborildi');
    state.admin.messages = null;
    await switchAdminTab('messages');
  },
};

function setBusy(btn, on) {
  if (!btn) return;
  if (on) { btn.dataset.html = btn.innerHTML; btn.disabled = true; btn.innerHTML = `<span class="spin"></span>${btn.textContent}`; }
  else if (btn.dataset.html) { btn.innerHTML = btn.dataset.html; btn.disabled = false; delete btn.dataset.html; }
}

document.addEventListener('submit', async (e) => {
  const f = e.target.closest('form[data-form]');
  if (!f) return;
  e.preventDefault();
  const err = $('.form-error', f);
  err?.classList.remove('show');
  const btn = $('button[type="submit"]', f);
  if (btn?.disabled) return;
  setBusy(btn, true);
  try {
    await forms[f.dataset.form](f);
  } catch (ex) {
    if (err) { err.textContent = ex.message; err.classList.add('show'); } else toast(ex.message, 'err');
  } finally {
    setBusy(btn, false);
  }
});

/* =====================================================================
   Input hodisalari
   ===================================================================== */
document.addEventListener('input', (e) => {
  const t = e.target;

  if (t.matches('[data-filter]')) {
    state.filters[t.dataset.filter] = t.value;
    renderGrid();
    return;
  }

  if (t.matches('[data-strength]')) {
    const v = t.value;
    let score = 0;
    if (v.length >= 8) score++;
    if (/[A-Z]/.test(v) && /[a-z]/.test(v)) score++;
    if (/\d/.test(v)) score++;
    if (/[^A-Za-z0-9]/.test(v) || v.length >= 12) score++;
    const labels = ['Kamida 8 ta belgi, harf va raqam', 'Zaif parol', "O'rtacha parol", 'Yaxshi parol', 'Kuchli parol'];
    const colors = ['var(--rose)', 'var(--rose)', 'var(--gold)', 'var(--teal)', 'var(--ok)'];
    const s = v ? score : 0;
    const m = $('#meter');
    m.style.width = `${(s / 4) * 100}%`;
    m.style.background = colors[s];
    $('#meter-label').textContent = labels[s];
    return;
  }

  if (t.matches('[data-otp]')) {
    t.value = t.value.replace(/\D/g, '').slice(-1);
    if (t.value) {
      const next = t.nextElementSibling;
      if (next) next.focus();
      else if ($$('[data-otp]').every((i) => i.value)) t.form?.requestSubmit();
    }
  }
});

document.addEventListener('keydown', (e) => {
  const t = e.target;
  if (!t.matches || !t.matches('[data-otp]')) return;
  if (e.key === 'Backspace' && !t.value && t.previousElementSibling) {
    t.previousElementSibling.value = '';
    t.previousElementSibling.focus();
  } else if (e.key === 'ArrowLeft') t.previousElementSibling?.focus();
  else if (e.key === 'ArrowRight') t.nextElementSibling?.focus();
});

document.addEventListener('paste', (e) => {
  const t = e.target;
  if (!t.matches || !t.matches('[data-otp]')) return;
  const digits = (e.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 6);
  if (!digits) return;
  e.preventDefault();
  const boxes = $$('[data-otp]');
  digits.split('').forEach((d, i) => { boxes[i].value = d; });
  boxes[Math.min(digits.length, 6) - 1].focus();
  if (digits.length === 6) t.form?.requestSubmit();
});

document.addEventListener('change', async (e) => {
  const t = e.target;
  if (!t.matches || !t.matches('[data-change="role"]')) return;
  try {
    await api(`/admin/users/${encodeURIComponent(t.dataset.id)}/role`, { method: 'PATCH', body: { role: t.value } });
    toast(`Rol "${t.value}" ga o'zgartirildi`);
    state.admin.users = null;
    await switchAdminTab('users');
  } catch (err) {
    toast(err.message, 'err');
    state.admin.users = null;
    await switchAdminTab('users');
  }
});

/* =====================================================================
   Ishga tushirish
   ===================================================================== */
onAuthChange(() => renderNav());
window.addEventListener('hashchange', router);

(async function boot() {
  $('#year').textContent = new Date().getFullYear();
  try { await refresh(); } catch { /* mehmon foydalanuvchi */ }
  await router();
})();

// Slayd darslarda ← → tugmalari bilan almashtirish
document.addEventListener('keydown', (e) => {
  const deck = document.querySelector('[data-deck]');
  if (!deck || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
  if (e.key === 'ArrowRight') { document.querySelector('[data-action="slide-next"]')?.click(); }
  else if (e.key === 'ArrowLeft') { document.querySelector('[data-action="slide-prev"]')?.click(); }
});
