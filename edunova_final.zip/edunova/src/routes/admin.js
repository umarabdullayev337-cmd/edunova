const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../db');
const config = require('../config');
const { authenticate, requireRole } = require('../middleware/auth');
const { wrap, publicUser, courseView, mentorView, messageView, isPremiumActive } = require('../utils/helpers');

const router = express.Router();
const AVAILABLE_AVATARS = ['m-jasur', 'm-dilnoza', 'm-sardor', 'm-madina', 'm-bekzod', 'm-nigora', 'm-otabek', 'm-malika', 'm-sherzod', 'm-aziza', 'm-ulugbek', 'm-kamola', 'm-rustam'];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// ---------- 2) Role-Based Authorization: bu yerdagi hamma yo'l faqat admin uchun ----------
router.use(authenticate, requireRole('admin'));

// ---------- Dashboard ----------
router.get('/dashboard', wrap(async (req, res) => {
  const { users, courses, enrollments, reviews, messages, certificates } = db.data;

  const revenue = enrollments.reduce((sum, e) => {
    const c = courses.find((x) => x.id === e.courseId);
    return sum + (c ? c.price : 0);
  }, 0);

  const signups = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setUTCHours(0, 0, 0, 0);
    d.setUTCDate(d.getUTCDate() - i);
    const start = d.getTime();
    signups.push({
      date: d.toISOString().slice(0, 10),
      count: users.filter((u) => u.createdAt >= start && u.createdAt < start + 864e5).length,
    });
  }

  const popular = courses.map(courseView).sort((a, b) => b.students - a.students).slice(0, 5);
  const recentUsers = [...users].sort((a, b) => b.createdAt - a.createdAt).slice(0, 5).map(publicUser);
  const recentMessages = [...messages].sort((a, b) => b.createdAt - a.createdAt).slice(0, 5).map(messageView);

  res.json({
    stats: {
      users: users.filter((u) => u.role === 'user').length,
      verifiedUsers: users.filter((u) => u.verified).length,
      premiumUsers: users.filter((u) => isPremiumActive(u)).length,
      mentors: users.filter((u) => u.role === 'mentor').length,
      admins: users.filter((u) => u.role === 'admin').length,
      courses: courses.length,
      premiumCourses: courses.filter((c) => c.premium).length,
      enrollments: enrollments.length,
      completions: enrollments.filter((e) => e.completed).length,
      certificates: certificates.length,
      reviews: reviews.length,
      openMessages: messages.filter((m) => m.status === 'open').length,
      revenue,
    },
    signups,
    popular,
    recentUsers,
    recentMessages,
  });
}));

// ---------- Foydalanuvchilar ----------
router.get('/users', wrap(async (req, res) => {
  const list = [...db.data.users].sort((a, b) => b.createdAt - a.createdAt).map((u) => ({
    ...publicUser(u),
    enrollments: db.data.enrollments.filter((e) => e.userId === u.id).length,
  }));
  res.json({ users: list });
}));

router.patch('/users/:id/role', wrap(async (req, res) => {
  const role = req.body?.role;
  if (!['user', 'admin', 'mentor'].includes(role)) return res.status(400).json({ error: "Rol 'user', 'admin' yoki 'mentor' bo'lishi kerak" });
  const user = db.findUser(req.params.id);
  if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
  if (user.id === req.user.id) return res.status(400).json({ error: "O'z rolingizni o'zgartira olmaysiz" });
  user.role = role;
  if (role === 'mentor' && !user.mAvatarKey) user.mAvatarKey = AVAILABLE_AVATARS[Math.floor(Math.random() * AVAILABLE_AVATARS.length)];
  db.save();
  res.json({ user: publicUser(user) });
}));

router.delete('/users/:id', wrap(async (req, res) => {
  const user = db.findUser(req.params.id);
  if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
  if (user.id === req.user.id) return res.status(400).json({ error: "O'zingizni o'chira olmaysiz" });
  if (db.data.courses.some((c) => c.mentorId === user.id)) {
    return res.status(400).json({ error: "Bu mentorga biriktirilgan kurslar bor. Avval kurslarni boshqa mentorga o'tkazing." });
  }
  db.data.users = db.data.users.filter((u) => u.id !== user.id);
  db.data.enrollments = db.data.enrollments.filter((e) => e.userId !== user.id);
  db.data.refreshTokens = db.data.refreshTokens.filter((t) => t.userId !== user.id);
  db.data.reviews = db.data.reviews.filter((r) => r.userId !== user.id);
  db.save();
  res.json({ message: "Foydalanuvchi o'chirildi" });
}));

// ---------- Mentorlar ----------
router.get('/mentors', wrap(async (req, res) => {
  res.json({ mentors: db.data.users.filter((u) => u.role === 'mentor').map(mentorView), avatars: AVAILABLE_AVATARS });
}));

function parseMentorFields(b = {}) {
  const errors = [];
  const title = String(b.title ?? '').trim().slice(0, 80);
  const bio = String(b.bio ?? '').trim().slice(0, 600);
  const specialty = String(b.specialty ?? '').trim().slice(0, 80);
  const avatarKey = AVAILABLE_AVATARS.includes(b.avatarKey) ? b.avatarKey : AVAILABLE_AVATARS[0];
  const achievements = (Array.isArray(b.achievements) ? b.achievements : [])
    .map((x) => String(x ?? '').trim().slice(0, 120)).filter(Boolean).slice(0, 8);
  if (title.length < 2) errors.push('Lavozim kiritilishi kerak');
  if (bio.length < 20) errors.push("Bio kamida 20 ta belgidan iborat bo'lishi kerak");
  return { errors, value: { mTitle: title, mBio: bio, mSpecialty: specialty, mAvatarKey: avatarKey, mAchievements: achievements } };
}

// Yangi mentor hisobini to'g'ridan-to'g'ri yaratish
router.post('/mentors', wrap(async (req, res) => {
  const name = String(req.body?.name || '').trim().replace(/\s+/g, ' ');
  const email = String(req.body?.email || '').trim().toLowerCase();
  if (name.length < 2 || name.length > 60) return res.status(400).json({ error: "Ism 2–60 ta belgidan iborat bo'lishi kerak" });
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: "Email noto'g'ri" });
  if (db.findUserByEmail(email)) return res.status(409).json({ error: 'Bu email allaqachon band' });

  const { errors, value } = parseMentorFields(req.body);
  if (errors.length) return res.status(400).json({ error: errors[0], errors });

  const tempPassword = req.body?.password && String(req.body.password).length >= 8 ? String(req.body.password) : crypto.randomBytes(6).toString('hex');
  const user = {
    id: db.id(), name, email,
    passwordHash: bcrypt.hashSync(tempPassword, config.bcryptRounds),
    role: 'mentor', verified: true, ...value, createdAt: Date.now(),
  };
  db.data.users.push(user);
  db.save();
  res.status(201).json({ mentor: mentorView(user), tempPassword });
}));

router.patch('/mentors/:id', wrap(async (req, res) => {
  const m = db.findMentor(req.params.id);
  if (!m) return res.status(404).json({ error: 'Mentor topilmadi' });
  const { errors, value } = parseMentorFields({ ...m, title: m.mTitle, bio: m.mBio, specialty: m.mSpecialty, avatarKey: m.mAvatarKey, achievements: m.mAchievements, ...req.body });
  if (errors.length) return res.status(400).json({ error: errors[0], errors });
  Object.assign(m, value);
  if (req.body?.name) m.name = String(req.body.name).trim().replace(/\s+/g, ' ').slice(0, 60);
  db.save();
  res.json({ mentor: mentorView(m) });
}));

// ---------- Kurslarga bog'liq: adminning kurslar ro'yxati (mentor ma'lumoti bilan) ----------
router.get('/courses', wrap(async (req, res) => {
  res.json({ courses: [...db.data.courses].sort((a, b) => b.createdAt - a.createdAt).map(courseView) });
}));

// ---------- Murojaatlar (Yordam xabarlari) ----------
router.get('/messages', wrap(async (req, res) => {
  const status = req.query.status;
  let list = [...db.data.messages];
  if (status && ['open', 'answered'].includes(status)) list = list.filter((m) => m.status === status);
  res.json({ messages: list.sort((a, b) => b.createdAt - a.createdAt).map(messageView) });
}));

router.patch('/messages/:id', wrap(async (req, res) => {
  const m = db.data.messages.find((x) => x.id === req.params.id);
  if (!m) return res.status(404).json({ error: 'Xabar topilmadi' });
  if (req.body?.reply !== undefined) {
    const reply = String(req.body.reply).trim();
    if (reply.length < 2 || reply.length > 1000) return res.status(400).json({ error: "Javob 2–1000 ta belgidan iborat bo'lishi kerak" });
    m.reply = reply;
    m.repliedAt = Date.now();
    m.status = 'answered';
  } else if (req.body?.status && ['open', 'answered'].includes(req.body.status)) {
    m.status = req.body.status;
  }
  db.save();
  res.json({ item: messageView(m) });
}));

router.delete('/messages/:id', wrap(async (req, res) => {
  const before = db.data.messages.length;
  db.data.messages = db.data.messages.filter((m) => m.id !== req.params.id);
  if (db.data.messages.length === before) return res.status(404).json({ error: 'Xabar topilmadi' });
  db.save();
  res.json({ message: "Xabar o'chirildi" });
}));

module.exports = router;
