// Dars kontenti: har bir kurs nomi bo'yicha. Savol formati:
//   [savol, [variantlar], to'g'ri_indeks, qiyin(1)/oddiy(0), izoh]
// Dars: [sarlavha, matn, [savollar]]; amaliy ish: [sarlavha, topshiriq, [savollar]]
const fs = require('fs');
const path = require('path');
const db = require('../db');
const { REWARD } = require('../shop');

const RAW = {};
for (const f of fs.readdirSync(__dirname)) {
  if (f === 'index.js' || !f.endsWith('.js')) continue;
  Object.assign(RAW, require(path.join(__dirname, f)));
}

// Variantlar tartibini savol matniga asoslab doimiy (deterministik) aralashtiramiz,
// shunda to'g'ri javob doim bir xil joyda bo'lib qolmaydi.
function shuffled(text, opts, ans) {
  if (opts.some((x) => /^(Ikkalasi|Hech |Hech$|Barchasi)/i.test(x))) return { o: opts, a: ans };
  let h = 2166136261;
  for (const ch of text) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  const rnd = () => { h = (Math.imul(h, 1664525) + 1013904223) >>> 0; return h / 4294967296; };
  const idx = opts.map((_, i) => i);
  for (let i = idx.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
  return { o: idx.map((i) => opts[i]), a: idx.indexOf(ans) };
}
// Slayd kontenti (src/lessons/slides/*.js): har kursda tanlangan 5 ta dars slaydlarga aylantiriladi
const SLIDES = {};
const sdir = path.join(__dirname, 'slides');
if (fs.existsSync(sdir)) for (const f of fs.readdirSync(sdir)) if (f.endsWith('.js')) Object.assign(SLIDES, require(path.join(sdir, f)));

function buildSlides(src, e) {
  const parts = String(src[1]).split('~~~');
  const code = e[5] ? '' : (parts.length >= 3 ? parts[1].replace(/^\n+|\n+$/g, '') : '');
  return [
    { k: 'topic', title: src[0], text: e[1] },
    { k: 'info', items: e[2] },
    { k: 'phrases', items: e[3] },
    { k: 'example', code, text: e[5] || '', note: e[4] || '' },
  ];
}

const normQ = (q, hardForce) => {
  const s = shuffled(q[0], q[1], q[2]);
  return { q: q[0], o: s.o, a: s.a, h: hardForce || !!q[3], e: q[4] || '' };
};

const CACHE = new Map();
function getContent(course) {
  if (!course) return null;
  if (CACHE.has(course.title)) return CACHE.get(course.title);
  const raw = RAW[course.title];
  let out = null;
  if (raw && raw.lessons?.length) {
    const sl = SLIDES[course.title];
    out = {
      lessons: sl
        ? sl.map((e) => { const src = raw.lessons[e[0]]; return { title: src[0], slides: buildSlides(src, e), text: '', qs: src[2].map((q) => normQ(q)) }; })
        : raw.lessons.map((l) => ({ title: l[0], text: l[1], slides: null, qs: l[2].map((q) => normQ(q)) })),
      practical: raw.practical ? { title: raw.practical[0], text: raw.practical[1], qs: raw.practical[2].map((q) => normQ(q, true)) } : null,
    };
  }
  CACHE.set(course.title, out);
  return out;
}

const rewardOf = (q) => (q.h ? REWARD.hard : REWARD.easy);

function getProgress(userId, courseId, create = false) {
  let p = db.data.progress.find((x) => x.userId === userId && x.courseId === courseId);
  if (!p && create) { p = { id: db.id(), userId, courseId, answers: {} }; db.data.progress.push(p); }
  return p || null;
}
const answeredCount = (prog, key, qs) => qs.reduce((n, _, i) => n + (prog?.answers[`${key}:${i}`] ? 1 : 0), 0);
const lessonDone = (prog, key, qs) => answeredCount(prog, key, qs) === qs.length;
const correctCount = (prog, key, qs) => qs.reduce((n, _, i) => n + (prog?.answers[`${key}:${i}`]?.ok ? 1 : 0), 0);

function progressPercent(userId, course, enrollment) {
  const c = getContent(course);
  if (!c) return null;
  if (enrollment?.completed) return 100;
  const prog = getProgress(userId, course.id);
  let done = c.lessons.filter((l, i) => lessonDone(prog, i, l.qs)).length;
  const total = c.lessons.length + (c.practical ? 1 : 0);
  if (c.practical && lessonDone(prog, 'p', c.practical.qs)) done += 1;
  return Math.round((done / total) * 100);
}

// Kurs soni va davomiyligini haqiqiy dars soniga moslash
function syncCourse(course) {
  const c = getContent(course);
  if (!c) return false;
  const n = c.lessons.length + (c.practical ? 1 : 0);
  const hours = Math.max(1, Math.round(n * 0.75));
  if (course.lessons !== n || course.durationHours !== hours) { course.lessons = n; course.durationHours = hours; return true; }
  return false;
}
function syncAll() {
  let changed = false;
  for (const c of db.data.courses) changed = syncCourse(c) || changed;
  if (changed) db.save();
}

function lessonsDoneCount(userId) {
  let n = 0;
  for (const p of db.data.progress) {
    if (p.userId !== userId) continue;
    const c = getContent(db.findCourse(p.courseId));
    if (!c) continue;
    n += c.lessons.filter((l, i) => lessonDone(p, i, l.qs)).length;
    if (c.practical && lessonDone(p, 'p', c.practical.qs)) n += 1;
  }
  return n;
}

// Eski hisoblar uchun: xp hali yo'q bo'lsa, mavjud javoblardan hisoblab qo'yamiz
function backfillXp() {
  const { XP } = require('../rank');
  let changed = false;
  for (const u of db.data.users) {
    if (u.xp !== undefined) continue;
    let xp = 0;
    for (const p of db.data.progress.filter((x) => x.userId === u.id)) {
      const c = getContent(db.findCourse(p.courseId));
      if (!c) continue;
      const items = [...c.lessons.map((l, i) => [i, l.qs]), ...(c.practical ? [['p', c.practical.qs]] : [])];
      for (const [k, qs] of items) {
        qs.forEach((q, i) => { if (p.answers[`${k}:${i}`]?.ok) xp += rewardOf(q); });
        if (lessonDone(p, k, qs)) {
          const all = correctCount(p, k, qs) === qs.length;
          if (k === 'p') { if (correctCount(p, k, qs) * 2 >= qs.length) xp += XP.practicalDone; } else xp += XP.lessonDone;
          if (all) xp += XP.perfectBonus;
        }
      }
    }
    if (xp > 0) { u.xp = xp; changed = true; }
  }
  if (changed) db.save();
}

module.exports = { lessonsDoneCount, backfillXp, getContent, rewardOf, getProgress, answeredCount, lessonDone, correctCount, progressPercent, syncCourse, syncAll };
