const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { authenticate } = require('../middleware/auth');
const { wrap, certificateView } = require('../utils/helpers');

const router = express.Router();

function genCode() {
  // Odam o'qishi va tekshirishi qulay bo'lgan kod: EDUNOVA-XXXX-XXXX
  const part = () => crypto.randomBytes(3).toString('hex').toUpperCase();
  return `EDU-${part()}-${part()}`;
}

// Foydalanuvchining barcha sertifikatlari
router.get('/mine', authenticate, wrap(async (req, res) => {
  const list = db.data.certificates.filter((c) => c.userId === req.user.id).sort((a, b) => b.issuedAt - a.issuedAt).map(certificateView);
  res.json({ certificates: list });
}));

// Kursni yakunlagan foydalanuvchi sertifikat so'raydi (ism u yozadi, dizayn tizim tomonidan)
router.post('/', authenticate, wrap(async (req, res) => {
  const courseId = String(req.body?.courseId || '');
  const fullName = String(req.body?.fullName || '').trim().replace(/\s+/g, ' ');
  const course = db.findCourse(courseId);
  if (!course) return res.status(404).json({ error: 'Kurs topilmadi' });
  const e = db.findEnrollment(req.user.id, courseId);
  if (!e || !e.completed) return res.status(403).json({ error: 'Sertifikat olish uchun avval kursni yakunlang', code: 'NOT_COMPLETED' });
  if (fullName.length < 3 || fullName.length > 80) return res.status(400).json({ error: "Ism-familiya 3–80 ta belgidan iborat bo'lishi kerak" });

  let cert = db.data.certificates.find((c) => c.userId === req.user.id && c.courseId === courseId);
  if (!cert) {
    cert = {
      id: db.id(),
      code: genCode(),
      userId: req.user.id,
      courseId,
      fullName,
      courseTitleSnapshot: course.title,
      durationHoursSnapshot: course.durationHours,
      issuedAt: Date.now(),
    };
    db.data.certificates.push(cert);
    db.save();
  } else if (cert.fullName !== fullName) {
    cert.fullName = fullName; // ism to'g'rilansa yangilanadi
    db.save();
  }
  res.status(201).json({ certificate: certificateView(cert) });
}));

// Sertifikatni kod orqali tekshirish — hamma uchun ochiq (ish beruvchilar tasdiqlashi uchun)
router.get('/verify/:code', wrap(async (req, res) => {
  const cert = db.data.certificates.find((c) => c.code === req.params.code.toUpperCase());
  if (!cert) return res.status(404).json({ error: 'Bunday kod bilan sertifikat topilmadi', valid: false });
  res.json({ valid: true, certificate: certificateView(cert) });
}));

module.exports = router;
