// Ma'lumotlar kurslari: Python, Machine Learning, SQL
module.exports = {
"Python: noldan ma'lumotlar tahliligacha": { lessons: [
['Python bilan tanishuv', `Python — o'qishga oson, universal dasturlash tili. Veb, avtomatlashtirish, ma'lumotlar tahlili va sun'iy intellektda keng ishlatiladi.

~~~
ism = "Ali"
yosh = 20
print("Salom,", ism)
print(type(yosh))   # <class 'int'>
~~~

Python'da o'zgaruvchi turi avtomatik aniqlanadi (dinamik tur). Bloklar jingalak qavs bilan emas, bo'sh joy (indentatsiya) bilan ajratiladi — odatda 4 ta probel.`,
 [['Python\'da bloklar qanday ajratiladi?', ['Jingalak qavs bilan','Indentatsiya (bo\'sh joy) bilan','Nuqta-vergul bilan','begin/end bilan'],1,0,'Indentatsiya sintaksisning bir qismi.'],
  ['print(type(5)) nimani chiqaradi?', ['<class \'int\'>','<class \'str\'>','5','number'],0,0,'5 — butun son.'],
  ['Python qanday tur tizimiga ega?', ['Statik','Dinamik','Turlarsiz','Faqat raqamli'],1,1,'Tur ish vaqtida aniqlanadi.']]],
['Ma\'lumot turlari va satrlar', `Asosiy turlar: int, float, str, bool, list, dict, tuple, set.

~~~
ism = "Vali"
print(f"Salom, {ism}!")       # f-string
print(ism.upper(), len(ism))  # VALI 4
print(ism[0], ism[-1])        # V i
print(7 / 2, 7 // 2, 7 % 2)   # 3.5 3 1
~~~

Indekslash 0 dan boshlanadi, manfiy indeks oxiridan sanaydi. / — haqiqiy bo'lish, // — butun bo'lish, % — qoldiq. Satrlar o'zgarmas (immutable).`,
 [['7 // 2 natijasi?', ['3.5','3','4','1'],1,0,'Butun bo\'lish.'],
  ['"Python"[-1] nima beradi?', ['P','n','o','Xato'],1,0,'Oxirgi belgi.'],
  ['f"{2+3}" natijasi?', ['2+3','5','"5"','Xato'],1,1,'Ifoda hisoblanadi: "5" matni (konsolda 5).']]],
['Shartlar va sikllar', `~~~
yosh = 17
if yosh >= 18:
    print("Katta")
elif yosh >= 13:
    print("O'smir")
else:
    print("Bola")

for i in range(3):      # 0, 1, 2
    print(i)

n = 0
while n < 3:
    n += 1
~~~

range(3) — 0,1,2 (oxirgi son kirmaydi). break siklni to'xtatadi, continue keyingi qadamga o'tadi. == taqqoslaydi, = tayinlaydi.`,
 [['range(3) qaysi sonlarni beradi?', ['1,2,3','0,1,2','0,1,2,3','3'],1,0,'Oxirgi kirmaydi.'],
  ['"elif" nimani bildiradi?', ['else if','end if','else for','element if'],0,0,'Qo\'shimcha shart.'],
  ['for i in range(1, 10, 3) qaysi qiymatlarni beradi?', ['1,4,7','1,3,6,9','1,4,7,10','3,6,9'],0,1,'Boshlanish 1, qadam 3, 10 kirmaydi.']]],
['Funksiyalar', `~~~
def yuza(a, b=1):
    """To'rtburchak yuzasi"""
    return a * b

print(yuza(3, 4))   # 12
print(yuza(5))      # 5
print(yuza(b=2, a=3))
~~~

def bilan funksiya e'lon qilinadi. Standart qiymatli parametr (b=1) ixtiyoriy bo'ladi. Funksiya ichida e'lon qilingan o'zgaruvchi lokal. Docstring (""" """) funksiyani tasvirlaydi.`,
 [['Funksiya e\'lon qilish kalit so\'zi?', ['function','def','fun','func'],1,0,'def.'],
  ['yuza(5) natijasi (yuqoridagi funksiya)?', ['5','1','Xato','None'],0,0,'b=1 standart.'],
  ['Funksiya return yozmasa nima qaytaradi?', ['0','None','""','Xato'],1,1,'None.']]],
['list, dict va comprehension', `~~~
sonlar = [3, 1, 2]
sonlar.append(5); sonlar.sort()
kvadrat = [x**2 for x in sonlar if x > 1]   # list comprehension

talaba = {"ism": "Ali", "ball": 90}
print(talaba["ism"], talaba.get("yosh", 0))
for k, v in talaba.items():
    print(k, v)
~~~

list — tartiblangan o'zgaruvchan ro'yxat, dict — kalit-qiymat. dict.get() kalit bo'lmasa xato bermaydi, standart qiymat qaytaradi. Comprehension — qisqa va tezkor yozuv.`,
 [['dict qiymatini xavfsiz olish usuli?', ['d[key] har doim','d.get(key, default)','d.find(key)','d.value(key)'],1,0,'KeyError bermaydi.'],
  ['[x*2 for x in [1,2,3]] natijasi?', ['[1,2,3]','[2,4,6]','[2,3,4]','(2,4,6)'],1,0,'Har biri 2 ga ko\'paytiriladi.'],
  ['[x for x in range(6) if x % 2 == 0] natijasi?', ['[1,3,5]','[0,2,4]','[0,2,4,6]','[2,4]'],1,1,'Juft sonlar, 6 kirmaydi.']]],
['Fayl va xatolar bilan ishlash', `~~~
try:
    with open("data.txt", encoding="utf-8") as f:
        matn = f.read()
except FileNotFoundError:
    print("Fayl topilmadi")
except ValueError as e:
    print("Qiymat xatosi:", e)
finally:
    print("Tugadi")
~~~

with bloki faylni avtomatik yopadi. try/except xatolarni ushlaydi; faqat kerakli xato turini ushlang, bo'sh except yozmang — xatolar yashirinib qoladi. CSV va JSON uchun csv va json modullari bor.`,
 [['Faylni xavfsiz ochib yopish uchun nima ishlatiladi?', ['with open(...)','open() faqat','file.begin()','read()'],0,0,'Context manager.'],
  ['finally bloki qachon bajariladi?', ['Faqat xato bo\'lsa','Faqat xato bo\'lmasa','Har doim','Hech qachon'],2,0,'Xatodan qat\'i nazar.'],
  ['Bo\'sh "except:" nega yomon amaliyot?', ['Sekin','Barcha xatolarni (hatto kutilmaganlarini) yashiradi','Python ruxsat bermaydi','Yaxshi amaliyot'],1,1,'Xatolar topilmay qoladi.']]],
['pandas bilan ma\'lumot tahlili', `pandas — jadval ma'lumotlari (DataFrame) uchun asosiy kutubxona.

~~~
import pandas as pd
df = pd.read_csv("sotuv.csv")
print(df.head())
print(df.describe())
katta = df[df["summa"] > 1000]
guruh = df.groupby("shahar")["summa"].sum()
df["narx_soliq"] = df["summa"] * 1.12
~~~

head() — dastlabki qatorlar, describe() — statistika, df[shart] — filtrlash, groupby — guruhlab hisoblash. Yo'qolgan qiymatlar (NaN) uchun isna(), fillna(), dropna() ishlatiladi.`,
 [['pandas\'da jadval ob\'ekti nomi?', ['DataFrame','Table','Sheet','Matrix'],0,0,'DataFrame.'],
  ['Shahar bo\'yicha summani yig\'ish uchun?', ['df.sum("shahar")','df.groupby("shahar")["summa"].sum()','df.sort("shahar")','df.merge()'],1,0,'groupby + sum.'],
  ['df.dropna() nima qiladi?', ['NaN bor qatorlarni olib tashlaydi','NaN ni 0 qiladi','Ustunni o\'chiradi','Jadvalni saralaydi'],0,1,'Yo\'qolgan qiymatli qatorlarni o\'chiradi.']]],
['Vizualizatsiya: matplotlib', `Grafik — ma'lumotdagi qonuniyatni tez ko'rsatadi.

~~~
import matplotlib.pyplot as plt
oylar = ["Yan", "Fev", "Mar"]
sotuv = [120, 150, 90]
plt.bar(oylar, sotuv, color="#e9b44c")
plt.title("Oylik sotuv")
plt.xlabel("Oy"); plt.ylabel("Soni")
plt.show()
~~~

Grafik turini maqsadga qarab tanlang: chiziqli (plot) — vaqt bo'yicha o'zgarish, ustunli (bar) — taqqoslash, gistogramma (hist) — taqsimot, scatter — ikki o'zgaruvchi bog'liqligi. Har doim sarlavha va o'q nomlarini yozing.`,
 [['Vaqt bo\'yicha o\'zgarishni ko\'rsatishga eng mos grafik?', ['Chiziqli','Doira','Faqat jadval','Scatter faqat'],0,0,'Chiziqli grafik trendni ko\'rsatadi.'],
  ['Qiymatlar taqsimotini ko\'rish uchun?', ['hist','bar','pie','title'],0,0,'Gistogramma.'],
  ['Grafikda nima uchun o\'q nomlari va sarlavha kerak?', ['Chiroyli','O\'quvchi nima ko\'rayotganini va o\'lchov birligini tushunishi uchun','Majburiy emas','Tezlik uchun'],1,1,'Aniqlik.']]],
], practical: ['Amaliy ish: Sotuv ma\'lumotlari tahlili', `sotuv.csv (sana, shahar, mahsulot, summa) fayli bilan:
1) pandas bilan yuklang, df.info() va describe() ko'ring.
2) NaN qiymatlarni aniqlang va qayta ishlang.
3) Shahar bo'yicha jami summani toping, eng yaxshi 3 shaharni chiqaring.
4) Oylik sotuv dinamikasini chiziqli grafikda ko'rsating.
5) 3 ta xulosa yozing.
Tayyor bo'lgach savollarga javob bering.`,
 [['Sanani oyga ajratish uchun avval nima qilinadi?', ['pd.to_datetime bilan sana turiga o\'tkaziladi','Hech narsa','Ustun o\'chiriladi','CSV qayta yoziladi'],0,1,'Sana ustuni datetime bo\'lishi kerak.'],
  ['Eng yaxshi 3 shaharni olish uchun?', ['.nlargest(3) yoki saralab .head(3)','.min(3)','.drop(3)','.tail(3) saralamay'],0,1,'nlargest.'],
  ['NaN\'ni o\'rtacha bilan to\'ldirish qanday?', ['df["x"].fillna(df["x"].mean())','df.drop("x")','df["x"].sum()','df.NaN()'],0,1,'fillna + mean.']] ] },

'Machine Learning asoslari': { lessons: [
['Machine Learning nima?', `Machine Learning (ML) — kompyuter qoidalar bilan emas, ma'lumotdan o'rganadigan yondashuv. Uch asosiy tur:
- Nazoratli o'rganish (supervised): javoblari ma'lum ma'lumot bilan — narx bashorati, spam aniqlash.
- Nazoratsiz (unsupervised): javobsiz ma'lumotdan tuzilma topish — mijozlarni guruhlash.
- Mustahkamlovchi (reinforcement): mukofot orqali o'rganish — o'yin botlari.

Regressiya — son bashorat qiladi (uy narxi), klassifikatsiya — sinf bashorat qiladi (spam / spam emas).`,
 [['Uy narxini bashorat qilish qaysi masala?', ['Klassifikatsiya','Regressiya','Klasterlash','Mustahkamlash'],1,0,'Uzluksiz son.'],
  ['Email spam yoki yo\'qligini aniqlash?', ['Klassifikatsiya','Regressiya','Faqat klasterlash','Optimallashtirish'],0,0,'Sinf bashorati.'],
  ['Javoblari (teglari) yo\'q ma\'lumotdan guruhlar topish qaysi tur?', ['Nazoratli','Nazoratsiz','Mustahkamlash','Regressiya'],1,1,'Klasterlash — nazoratsiz.']]],
['Ma\'lumotni tayyorlash', `Model sifati ma'lumot sifatiga bog'liq ("garbage in, garbage out"). Bosqichlar: tozalash (yo'qolgan qiymat, takrorlar), kodlash (kategoriyani songa), masshtablash (belgilar o'lchamini tenglash).

Ma'lumot uch qismga bo'linadi: train (o'rganish), validation (sozlash), test (yakuniy baholash). Test ma'lumotini o'qitish paytida ko'rmaslik shart.

~~~
from sklearn.model_selection import train_test_split
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)
~~~`,
 [['Train/test bo\'lish nima uchun kerak?', ['Tezlik uchun','Modelni ko\'rilmagan ma\'lumotda halol baholash uchun','Xotira tejash','Dizayn'],1,0,'Umumlashtirishni tekshirish.'],
  ['random_state=42 vazifasi?', ['Aniqlikni oshiradi','Bo\'linishni takrorlanadigan qiladi','Ma\'lumotni o\'chiradi','Modelni tezlashtiradi'],1,0,'Natija har safar bir xil.'],
  ['Test ma\'lumoti statistikasi (masalan o\'rtacha) bo\'yicha masshtablash nega xato?', ['Hech xato yo\'q','Ma\'lumot sizib o\'tadi (data leakage), baho sun\'iy yaxshi chiqadi','Sekin','Python rad etadi'],1,1,'Masshtabni faqat train\'da o\'rgatib, test\'ga qo\'llang.']]],
['Chiziqli regressiya', `Eng sodda model: y = w·x + b. Model xatoni (loss) minimallashtiradigan w va b ni topadi. Odatda MSE (o'rtacha kvadratik xato) ishlatiladi.

~~~
from sklearn.linear_model import LinearRegression
model = LinearRegression().fit(X_tr, y_tr)
bashorat = model.predict(X_te)
print(model.coef_, model.intercept_)
~~~

Baholash: MAE, MSE, R². R² 1 ga yaqin bo'lsa, model ma'lumotni yaxshi tushuntiradi. Natijani tekshirishda chiziq ma'lumotga mos kelishini grafikda ko'ring.`,
 [['Regressiyada keng ishlatiladigan xato o\'lchovi?', ['MSE','Accuracy','F1','Recall'],0,0,'Mean Squared Error.'],
  ['fit() nima qiladi?', ['Bashorat qiladi','Modelni ma\'lumotda o\'qitadi','Ma\'lumotni yuklaydi','Grafik chizadi'],1,0,'O\'qitish.'],
  ['R² = 0.02 bo\'lsa, bu nimani anglatadi?', ['Model juda yaxshi','Model ma\'lumot o\'zgaruvchanligini deyarli tushuntirmaydi','Model mukammal','Xato yo\'q'],1,1,'0 ga yaqin R² — yomon moslik.']]],
['Klassifikatsiya va logistik regressiya', `Logistik regressiya sinf ehtimolini (0 dan 1 gacha) beradi; odatda 0.5 chegaradan yuqori bo'lsa "ha" deb qaraladi.

~~~
from sklearn.linear_model import LogisticRegression
clf = LogisticRegression().fit(X_tr, y_tr)
print(clf.predict_proba(X_te)[:3])
~~~

Confusion matrix to'rt qiymatni ko'rsatadi: TP, TN, FP, FN. Precision = TP/(TP+FP) — "ha" deganlarimizning qanchasi to'g'ri. Recall = TP/(TP+FN) — haqiqiy "ha"larning qanchasini topdik. Saraton tashxisida Recall muhim: kasalni o'tkazib yubormaslik kerak.`,
 [['Precision nimani o\'lchaydi?', ['"Ha" deb aytganlarimizdan qanchasi haqiqatan ha','Barcha ha\'lardan nechtasini topdik','Umumiy xatoni','Tezlikni'],0,0,'TP/(TP+FP).'],
  ['Recall nimani o\'lchaydi?', ['Haqiqiy "ha"larning qanchasi topildi','Modelning tezligi','Umumiy aniqlik','Xotira'],0,0,'TP/(TP+FN).'],
  ['Kasallikni aniqlashda eng muhim ko\'rsatkich odatda qaysi?', ['Recall (kasalni o\'tkazib yubormaslik)','Faqat tezlik','Precision faqat','Hajm'],0,1,'FN xavfliroq.']]],
['Overfitting va underfitting', `Overfitting — model o'qitish ma'lumotini yodlab oladi, yangi ma'lumotda yomon ishlaydi (train xatosi kichik, test xatosi katta). Underfitting — model juda sodda, hatto train'da ham yomon.

Overfitting'ga qarshi: ko'proq ma'lumot, soddaroq model, regulyarizatsiya (L1/L2), cross-validation, erta to'xtatish.

~~~
from sklearn.model_selection import cross_val_score
print(cross_val_score(model, X, y, cv=5).mean())
~~~

Cross-validation ma'lumotni k bo'lakka bo'lib, modelni k marta baholaydi — natija barqarorroq.`,
 [['Train\'da juda yaxshi, test\'da yomon natija nimani bildiradi?', ['Underfitting','Overfitting','Mukammal model','Xato yo\'q'],1,0,'Yodlab olish.'],
  ['Cross-validation nima?', ['Ma\'lumotni k marta bo\'lib baholash','Ma\'lumotni o\'chirish','Faqat grafik','Tezlatish'],0,0,'k-fold.'],
  ['Quyidagilardan qaysi biri overfitting\'ga qarshi vosita EMAS?', ['Regulyarizatsiya','Ko\'proq ma\'lumot','Modelni ancha murakkablashtirish','Erta to\'xtatish'],2,1,'Murakkablik overfitting\'ni kuchaytiradi.']]],
['Qaror daraxtlari va Random Forest', `Qaror daraxti savollar ketma-ketligi orqali qaror qiladi ("yosh > 30?"). Tushunarli va masshtablashni talab qilmaydi, lekin oson overfit bo'ladi.

Random Forest — ko'p daraxtlar to'plami; har biri ma'lumotning tasodifiy qismida o'qitiladi, natija ovoz berish bilan chiqadi. Bu ansambl yondashuvi yakka daraxtdan barqaror.

~~~
from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(n_estimators=200, random_state=0).fit(X_tr, y_tr)
print(rf.feature_importances_)
~~~

feature_importances_ qaysi belgi bashoratga ko'proq ta'sir qilganini ko'rsatadi.`,
 [['Random Forest nima?', ['Bitta katta daraxt','Ko\'p daraxtlar ansambli','Neyron tarmoq','Klasterlash'],1,0,'Ansambl.'],
  ['Qaror daraxtining asosiy zaifligi?', ['Tushunib bo\'lmaydi','Osongina overfit bo\'ladi','Raqam qabul qilmaydi','Sekin bashorat'],1,0,'Chuqur daraxt yodlab oladi.'],
  ['Random Forest nega yakka daraxtdan barqarorroq?', ['Ko\'p modelning o\'rtacha/ovozi xatolarni silliqlaydi','Tezroq','Kamroq ma\'lumot','Hech qanday sabab'],0,1,'Dispersiya kamayadi.']]],
['Klasterlash: K-Means', `K-Means — javobsiz ma'lumotni k ta guruhga ajratadi: markazlarni tasodifiy tanlaydi, har nuqtani eng yaqin markazga biriktiradi, markazlarni yangilaydi va barqarorlashguncha takrorlaydi.

~~~
from sklearn.cluster import KMeans
km = KMeans(n_clusters=3, n_init=10, random_state=0).fit(X)
print(km.labels_[:10])
~~~

k ni tanlash: "tirsak usuli" (inertia grafigi) yoki silhouette ko'rsatkichi. Masofa asosida ishlagani uchun belgilarni masshtablash shart. Qo'llanilishi: mijozlar segmentatsiyasi, tavsiya tizimlari.`,
 [['K-Means qaysi tur o\'rganish?', ['Nazoratsiz','Nazoratli','Mustahkamlash','Regressiya'],0,0,'Teglar yo\'q.'],
  ['K-Means\'da k nima?', ['Guruhlar soni','Takrorlar soni','Belgilar soni','Tezlik'],0,0,'n_clusters.'],
  ['K-Means oldidan belgilarni masshtablash nega muhim?', ['Masofa asosida ishlaydi — katta masshtabli belgi natijaga haddan ortiq ta\'sir qiladi','Python talab qiladi','Estetik','Muhim emas'],0,1,'Euklid masofasi.']]],
['Neyron tarmoqlar va etika', `Neyron tarmoq qatlamlardan iborat: kirish, yashirin, chiqish. Har neyron kirishlarni vazn bilan ko'paytirib yig'adi va aktivatsiya funksiyasidan o'tkazadi. Vaznlar backpropagation va gradient descent bilan yangilanadi.

Chuqur o'rganish katta ma'lumot va hisoblash quvvatini talab qiladi, lekin rasm, matn va nutqda eng yaxshi natijani beradi.

Etika: ma'lumotdagi tarafkashlik (bias) modelda ham paydo bo'ladi. Shaxsiy ma'lumotni himoyalang, modelning qarorlarini tushuntira olishga harakat qiling, qaror odamlarga ta'sir qilsa — inson nazoratini saqlang.`,
 [['Neyron tarmoq vaznlari qanday yangilanadi?', ['Qo\'lda','Gradient descent / backpropagation bilan','Tasodifiy','Yangilanmaydi'],1,0,'Xato gradienti bo\'yicha.'],
  ['Aktivatsiya funksiyasi nima uchun kerak?', ['Chiziqli bo\'lmaganlikni qo\'shish uchun','Xotira uchun','Rasm uchun','Tezlik uchun'],0,0,'Aks holda tarmoq bitta chiziqli model bo\'lib qoladi.'],
  ['Ishga qabul qilish modeli tarixiy tarafkash ma\'lumotda o\'qitilsa, nima xavf bor?', ['Hech narsa','Model tarafkashlikni takrorlab, adolatsiz qaror chiqarishi mumkin','Tezlashadi','Aniqroq bo\'ladi'],1,1,'Bias ma\'lumotdan modelga o\'tadi.']]],
], practical: ['Amaliy ish: Mijoz ketishini bashorat qilish', `Telekom mijozlari ma'lumoti (churn: 0/1) bilan:
1) Ma'lumotni tozalang, kategoriyalarni kodlang.
2) 80/20 train/test bo'ling (random_state belgilang).
3) LogisticRegression va RandomForest'ni o'qiting.
4) Precision, Recall va confusion matrix bilan taqqoslang.
5) Qaysi model va nega tanlanishini yozing.
Tayyor bo'lgach savollarga javob bering.`,
 [['Ketayotgan mijozlar 5% bo\'lsa, "hamma qoladi" deydigan model accuracy\'si?', ['Taxminan 95% — lekin foydasiz','5%','0%','50%'],0,1,'Nomutanosib sinflarda accuracy aldamchi.'],
  ['Mijozni yo\'qotmaslik muhim bo\'lsa, qaysi ko\'rsatkichga e\'tibor beriladi?', ['Recall','Faqat tezlik','Xotira','Sarlavha'],0,1,'Ketuvchilarni o\'tkazib yubormaslik.'],
  ['Modelni tanlash uchun yakuniy baho qaysi ma\'lumotda olinadi?', ['Train','Test (ko\'rilmagan) ma\'lumot','Hammasida','Tasodifiy 3 qator'],1,1,'Halol baho.']] ] },

"SQL va ma'lumotlar bazalari": { lessons: [
['Ma\'lumotlar bazasi va SQL nima', `Ma'lumotlar bazasi — tartibli saqlanadigan ma'lumotlar. Relyatsion bazada ma'lumot jadvallarda (qator va ustun) saqlanadi. SQL (Structured Query Language) — shu jadvallar bilan ishlash tili.

Jadval ustuni — maydon (tur bilan), qator — bitta yozuv. Primary key (birlamchi kalit) har qatorni noyob aniqlaydi. MySQL, PostgreSQL, SQLite — mashhur relyatsion bazalar.`,
 [['Relyatsion bazada ma\'lumot qanday saqlanadi?', ['Jadvallarda','Rasmlarda','Faqat fayllarda matn','Grafikda'],0,0,'Jadvallar.'],
  ['Primary key vazifasi?', ['Qatorni noyob aniqlash','Parol','Tartiblash','Rasm'],0,0,'Noyob identifikator.'],
  ['Primary key qiymati takrorlanishi mumkinmi?', ['Ha','Yo\'q, noyob bo\'lishi va NULL bo\'lmasligi kerak','Faqat son bo\'lsa','Ba\'zan'],1,1,'Noyob va NULL emas.']]],
['SELECT, WHERE, ORDER BY', `~~~
SELECT ism, narx FROM kurslar
WHERE narx < 500000 AND daraja = 'Boshlang''ich'
ORDER BY narx DESC
LIMIT 5;
~~~

SELECT — ustunlarni tanlash, FROM — jadval, WHERE — filtr, ORDER BY — saralash (ASC o'sish, DESC kamayish), LIMIT — qatorlar soni. Satr qiymatlari bitta tirnoqda yoziladi. Hamma ustun uchun * ishlatiladi, lekin productionda kerakli ustunlarni yozing.`,
 [['Qatorlarni filtrlash qaysi kalit so\'z bilan?', ['WHERE','FILTER','HAVING faqat','FIND'],0,0,'WHERE.'],
  ['ORDER BY narx DESC nima qiladi?', ['Narx bo\'yicha o\'sish tartibida','Narx bo\'yicha kamayish tartibida saralaydi','O\'chiradi','Guruhlaydi'],1,0,'DESC — kamayish.'],
  ['Eng qimmat 3 kursni olish uchun?', ['ORDER BY narx DESC LIMIT 3','ORDER BY narx LIMIT 3','LIMIT 3 WHERE narx','SELECT MAX(3)'],0,1,'Kamayish + LIMIT.']]],
['INSERT, UPDATE, DELETE', `~~~
INSERT INTO kurslar (ism, narx) VALUES ('SQL', 420000);
UPDATE kurslar SET narx = 450000 WHERE id = 7;
DELETE FROM kurslar WHERE id = 7;
~~~

UPDATE va DELETE'da WHERE'ni unutish — butun jadvalni o'zgartirish/o'chirish demak! Avval xuddi shu WHERE bilan SELECT qilib tekshiring. Muhim o'zgarishlarni tranzaksiya (BEGIN ... COMMIT) ichida bajaring, xato bo'lsa ROLLBACK.`,
 [['Yangi qator qo\'shish buyrug\'i?', ['INSERT INTO','ADD ROW','NEW','APPEND'],0,0,'INSERT INTO.'],
  ['WHERE'+' siz DELETE FROM kurslar; nima qiladi?', ['Hech narsa','Jadvaldagi barcha qatorlarni o\'chiradi','Birinchi qatorni','Xato'],1,0,'Hammasini o\'chiradi.'],
  ['ROLLBACK nima qiladi?', ['O\'zgarishlarni bekor qiladi (tranzaksiya)','Saqlaydi','Jadval yaratadi','Indeks qo\'shadi'],0,1,'Tranzaksiyani bekor qilish.']]],
['Agregat funksiyalar va GROUP BY', `~~~
SELECT daraja, COUNT(*) AS soni, AVG(narx) AS ortacha
FROM kurslar
GROUP BY daraja
HAVING COUNT(*) > 2
ORDER BY ortacha DESC;
~~~

COUNT, SUM, AVG, MIN, MAX — agregat funksiyalar. GROUP BY qatorlarni guruhlaydi. WHERE guruhlashdan OLDIN qatorlarni filtrlaydi, HAVING esa guruhlashdan KEYIN guruhlarni filtrlaydi.`,
 [['O\'rtacha qiymat funksiyasi?', ['AVG','MID','MEAN','AVERAGE'],0,0,'AVG.'],
  ['Qatorlar sonini sanash?', ['COUNT(*)','SUM(*)','LEN(*)','NUM()'],0,0,'COUNT.'],
  ['WHERE va HAVING farqi?', ['Farqi yo\'q','WHERE guruhlashdan oldin qatorlarni, HAVING guruhlashdan keyin guruhlarni filtrlaydi','HAVING oldin ishlaydi','WHERE faqat sonlarga'],1,1,'Ishlash tartibi.']]],
['Jadvallarni bog\'lash: JOIN', `Ma'lumot takrorlanmasligi uchun alohida jadvallarda saqlanadi va foreign key (tashqi kalit) bilan bog'lanadi.

~~~
SELECT k.ism AS kurs, m.ism AS mentor
FROM kurslar k
INNER JOIN mentorlar m ON m.id = k.mentor_id;

SELECT m.ism, COUNT(k.id)
FROM mentorlar m
LEFT JOIN kurslar k ON k.mentor_id = m.id
GROUP BY m.ism;
~~~

INNER JOIN — ikkala jadvalda mos kelganlarni oladi. LEFT JOIN — chap jadvalning barcha qatorlarini oladi, mos kelmasa o'ng tomon NULL bo'ladi (kursi yo'q mentorlar ham chiqadi).`,
 [['Faqat ikkala jadvalda mos keluvchi qatorlarni olish uchun?', ['INNER JOIN','LEFT JOIN','CROSS','UNION'],0,0,'INNER JOIN.'],
  ['Foreign key nima?', ['Boshqa jadvalning kalitiga ishora qiluvchi ustun','Parol','Indeks','Jadval nomi'],0,0,'Bog\'lanish.'],
  ['Kursi yo\'q mentorlarni ham ko\'rsatish uchun qaysi JOIN?', ['INNER','LEFT (mentorlar chapda)','RIGHT (mentorlar chapda)','Hech biri'],1,1,'LEFT chap jadvalni to\'liq saqlaydi.']]],
['Jadval yaratish va normalizatsiya', `~~~
CREATE TABLE kurslar (
  id INTEGER PRIMARY KEY,
  ism TEXT NOT NULL,
  narx INTEGER CHECK (narx >= 0),
  mentor_id INTEGER REFERENCES mentorlar(id)
);
~~~

Cheklovlar: NOT NULL, UNIQUE, CHECK, FOREIGN KEY ma'lumot to'g'riligini baza darajasida ta'minlaydi. Normalizatsiya — takrorlanishni kamaytirish: mentor ismini har kursda yozmasdan, alohida jadvalda saqlab, id orqali bog'lash. Shunda ism o'zgarsa, bitta joyda o'zgartiriladi.`,
 [['Ustun bo\'sh bo\'lmasligini ta\'minlovchi cheklov?', ['NOT NULL','UNIQUE','CHECK','DEFAULT'],0,0,'NOT NULL.'],
  ['Normalizatsiya maqsadi?', ['Ma\'lumot takrorlanishini kamaytirish','Jadvalni kattalashtirish','Tezlikni pasaytirish','Rasm saqlash'],0,0,'Takrorlanish va nomuvofiqlikni kamaytirish.'],
  ['Mentor ismini har kurs qatorida takrorlab yozishning kamchiligi?', ['Ism o\'zgarsa ko\'p joyda yangilash kerak va nomuvofiqlik chiqadi','Hech qanday','Tezroq','Kamroq joy'],0,1,'Update anomaly.']]],
['Indekslar va tezlik', `Indeks — kitob mundarijasiga o'xshaydi: ustun bo'yicha qidiruvni tezlashtiradi. Indekssiz baza jadvalning har qatorini ko'rib chiqadi.

~~~
CREATE INDEX idx_kurslar_mentor ON kurslar(mentor_id);
EXPLAIN SELECT * FROM kurslar WHERE mentor_id = 5;
~~~

Indeks tez-tez WHERE, JOIN va ORDER BY'da ishlatiladigan ustunlarga qo'yiladi. Lekin har indeks joy egallaydi va INSERT/UPDATE'ni sekinlashtiradi — hamma ustunga qo'ymang. EXPLAIN so'rov rejasini ko'rsatadi.`,
 [['Indeksning asosiy vazifasi?', ['Qidiruvni tezlashtirish','Ma\'lumotni o\'chirish','Shifrlash','Jadval yaratish'],0,0,'Qidiruv tezligi.'],
  ['Indeksning kamchiligi?', ['Yozish amallarini sekinlashtiradi va joy egallaydi','Qidiruvni sekinlashtiradi','Hech qanday','Xato beradi'],0,0,'Narx bor.'],
  ['EXPLAIN nima uchun?', ['So\'rov qanday bajarilishini (reja) ko\'rish uchun','Jadval o\'chirish','Parol','Zaxira'],0,1,'Optimallashtirish vositasi.']]],
['Xavfsizlik: SQL injection va zaxira', `SQL injection — foydalanuvchi kiritgan matn so'rovga qo'shilib, hujumchi so'rovni o'zgartirishi.

~~~
// XAVFLI: "SELECT * FROM users WHERE email = '" + email + "'"
// XAVFSIZ (parametrli so'rov):
db.query('SELECT * FROM users WHERE email = ?', [email]);
~~~

Parametrli so'rovlar (prepared statements) ma'lumotni kod sifatida emas, qiymat sifatida uzatadi. Qo'shimcha: ilova uchun minimal huquqli baza foydalanuvchisi, parollarni hashlash, muntazam zaxira nusxa (backup) va uni tiklashni sinab ko'rish.`,
 [['SQL injection\'dan eng yaxshi himoya?', ['Parametrli so\'rovlar','Matnni birlashtirish','Hech narsa','Katta harf'],0,0,'Prepared statements.'],
  ['Zaxira nusxa nima uchun muhim?', ['Ma\'lumot yo\'qolsa tiklash uchun','Tezlik uchun','Dizayn','Majburiy emas'],0,0,'Tiklash imkoniyati.'],
  ['Zaxira nusxaning ishlashiga qachon ishonch hosil qilinadi?', ['Nusxa olingan zahoti','Uni haqiqatan tiklab sinab ko\'rilganda','Hech qachon','Fayl hajmiga qarab'],1,1,'Tiklanmagan zaxira — noma\'lum.']]],
], practical: ['Amaliy ish: Onlayn do\'kon bazasi', `Do'kon uchun baza loyihalang:
1) Jadvallar: mijozlar, mahsulotlar, buyurtmalar, buyurtma_elementlari (kalitlar va cheklovlar bilan).
2) 5 ta mijoz, 8 ta mahsulot, 10 ta buyurtma qo'shing.
3) So'rov: har mijozning jami xarajati (JOIN + GROUP BY).
4) So'rov: hech narsa sotib olmagan mijozlar (LEFT JOIN).
5) Tez-tez qidiriladigan ustunga indeks qo'shing.
Tayyor bo'lgach savollarga javob bering.`,
 [['Hech buyurtma bermagan mijozlarni topish uchun qaysi yondashuv?', ['LEFT JOIN va buyurtma NULL bo\'lganini olish','INNER JOIN','GROUP BY faqat','ORDER BY'],0,1,'LEFT JOIN ... WHERE b.id IS NULL.'],
  ['Mijoz jami xarajatini hisoblashda qaysi birikma kerak?', ['JOIN + SUM + GROUP BY','Faqat WHERE','DELETE','CREATE'],0,1,'Agregat va guruhlash.'],
  ['buyurtma_elementlari jadvali nima uchun alohida?', ['Bir buyurtmada ko\'p mahsulot bo\'lishi mumkin (ko\'p-ko\'pga bog\'lanish)','Chiroyli','Majburiy emas','Tezlik'],0,1,'Normalizatsiya.']] ] },
};
