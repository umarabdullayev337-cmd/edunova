// API klient: access token faqat xotirada (localStorage'da EMAS) saqlanadi,
// refresh token esa httpOnly cookie'da — JavaScript unga umuman kira olmaydi.

let accessToken = null;
let refreshing = null; // bir vaqtda bitta refresh so'rovi (single-flight)
const listeners = new Set();

export const session = { user: null, expiresAt: 0 };

export class ApiError extends Error {
  constructor(message, status, code, data) {
    super(message);
    this.status = status;
    this.code = code;
    this.data = data;
  }
}

export function onAuthChange(fn) { listeners.add(fn); }

export function setSession(data) {
  if (data && data.accessToken) {
    accessToken = data.accessToken;
    session.expiresAt = Date.now() + (data.expiresIn || 900) * 1000;
    if (data.user) session.user = data.user;
  } else {
    accessToken = null;
    session.user = null;
    session.expiresAt = 0;
  }
  listeners.forEach((fn) => fn(session.user));
}

async function raw(path, { method = 'GET', body, auth = true, optionalAuth = false } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if ((auth || optionalAuth) && accessToken) headers.Authorization = `Bearer ${accessToken}`;
  let res;
  try {
    res = await fetch(path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      credentials: 'same-origin',
    });
  } catch {
    throw new ApiError("Serverga ulanib bo'lmadi. Internetni tekshiring.", 0, 'NETWORK');
  }
  let data = null;
  try { data = await res.json(); } catch { /* bo'sh javob */ }
  return { res, data };
}

// POST /auth/refresh — yangi access token oladi (cookie avtomatik yuboriladi)
export function refresh() {
  if (!refreshing) {
    refreshing = (async () => {
      const { res, data } = await raw('/auth/refresh', { method: 'POST', auth: false });
      if (!res.ok) {
        setSession(null);
        throw new ApiError(data?.error || 'Sessiya tugagan', res.status, data?.code, data);
      }
      setSession(data);
      return data;
    })().finally(() => { refreshing = null; });
  }
  return refreshing;
}

export async function api(path, opts = {}) {
  let { res, data } = await raw(path, opts);

  // Access token tugagan bo'lsa — refresh qilib, so'rovni qayta yuboramiz
  if (res.status === 401 && opts.auth !== false && ['TOKEN_EXPIRED', 'NO_TOKEN'].includes(data?.code)) {
    try {
      await refresh();
      ({ res, data } = await raw(path, opts));
    } catch { /* pastda xato qaytariladi */ }
  }

  if (!res.ok) throw new ApiError(data?.error || 'Xatolik yuz berdi', res.status, data?.code, data);
  return data;
}
