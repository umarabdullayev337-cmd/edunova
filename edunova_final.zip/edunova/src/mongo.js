// MongoDB (Compass'da ko'rinadigan) saqlash qatlami.
// .env da MONGODB_URI berilsa yoqiladi; berilmasa sayt avvalgidek data/db.json bilan ishlaydi.
//
// Ishlash tartibi:
//   1) Ishga tushganda MongoDB'dagi ma'lumot xotiraga o'qiladi (bo'sh bo'lsa, db.json + seed ma'lumoti yuboriladi).
//   2) Har db.save() dan keyin FAQAT o'zgargan yozuvlar MongoDB'ga yoziladi (upsert/delete).
//   3) O'chirishda (Ctrl+C) oxirgi o'zgarishlar yozib bo'lingach to'xtaydi.
const enabled = !!process.env.MONGODB_URI;
const DB_NAME = process.env.MONGODB_DB || 'edunova';
const COLLECTIONS = ['users', 'courses', 'enrollments', 'refreshTokens', 'reviews', 'messages', 'certificates', 'progress'];

let client = null;
let mdb = null;
const last = {}; // collection -> Map(key -> JSON)
let chain = Promise.resolve();
let timer = null;

const keyOf = (doc) => doc.id ?? doc.jti ?? doc.code ?? doc._id;

async function connect() {
  const { MongoClient } = require('mongodb');
  client = new MongoClient(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 6000 });
  try {
    await client.connect();
  } catch (e) {
    console.error(`\n[mongo] MongoDB'ga ulanib bo'lmadi: ${e.message}`);
    console.error('[mongo] MongoDB ishlab turibdimi? .env dagi MONGODB_URI to\'g\'rimi? (masalan: mongodb://localhost:27017)\n');
    process.exit(1);
  }
  mdb = client.db(DB_NAME);
}

// MongoDB'dagi ma'lumotni xotiraga o'qiydi. Qaytaradi: MongoDB'da ma'lumot bor edimi.
async function loadInto(data) {
  let any = false;
  for (const name of COLLECTIONS) {
    const docs = await mdb.collection(name).find({}).toArray();
    last[name] = new Map();
    if (!docs.length) continue;
    any = true;
    const clean = docs.map(({ _id, ...rest }) => ({ ...rest, ...(rest.id === undefined && rest.jti === undefined && rest.code === undefined ? { id: _id } : {}) }));
    data[name].length = 0; // massiv obyektini almashtirmaymiz — boshqa modullar unga havola olgan
    data[name].push(...clean);
    for (const d of clean) last[name].set(String(keyOf(d)), JSON.stringify(d));
  }
  return any;
}

async function syncNow(data) {
  for (const name of COLLECTIONS) {
    const prev = last[name] || (last[name] = new Map());
    const cur = new Map();
    const ops = [];
    for (const doc of data[name] || []) {
      const key = String(keyOf(doc));
      const json = JSON.stringify(doc);
      cur.set(key, json);
      if (prev.get(key) !== json) ops.push({ replaceOne: { filter: { _id: key }, replacement: { ...doc, _id: key }, upsert: true } });
    }
    for (const key of prev.keys()) if (!cur.has(key)) ops.push({ deleteOne: { filter: { _id: key } } });
    if (ops.length) {
      await mdb.collection(name).bulkWrite(ops, { ordered: false });
      last[name] = cur;
    }
  }
}

function schedule(data) {
  clearTimeout(timer);
  timer = setTimeout(() => {
    chain = chain.then(() => syncNow(data)).catch((e) => console.error('[mongo] yozishda xato:', e.message));
  }, 250);
}

// db.save() ni kengaytiramiz va birinchi sinxronizatsiyani bajaramiz
async function attach(db) {
  const origSave = db.save;
  db.save = () => { origSave(); schedule(db.data); };
  await syncNow(db.data);
  const stop = async () => {
    clearTimeout(timer);
    try { await chain; await syncNow(db.data); await client.close(); } catch (e) { console.error('[mongo]', e.message); }
    process.exit(0);
  };
  process.once('SIGINT', stop);
  process.once('SIGTERM', stop);
  console.log(`[mongo] Ulandi: baza "${DB_NAME}" — Compass'da ko'rinadi`);
}

module.exports = { enabled, connect, loadInto, attach };
